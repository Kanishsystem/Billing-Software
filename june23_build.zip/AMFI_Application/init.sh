#!/bin/bash
set -xe

npm install \
    && npm start