const crypto = require('crypto');
const CryptoJS = require("crypto-js");
const envConfig = require("../config/env.config")
// require('dotenv').config();

const algorithm = envConfig.AMFI_APPLICATION_ALGORITHM;
const key = envConfig.AMFI_APPLICATION_KEY;
const ivCiphertext = Buffer.from(envConfig.AMFI_APPLICATION_IV, 'hex');


// const algorithm = "aes-256-cbc";
// const key = "my_secret_password_for_test_1234";
// const ivCiphertext = Buffer.from('FB391CAAE5CD8FF47C55211ED8636D213C95F233B615D4E56CB7CD6B051D01DF356E1C45ED7AABAB5F9BCBB9EED6355B', 'hex');

const iv = ivCiphertext.slice(0, 16);
module.exports = {

    encrypt1: function (text) {
        let cipher = crypto.createCipheriv(algorithm, Buffer.from(key), iv);
        let encrypted = cipher.update(text);
        encrypted = Buffer.concat([encrypted, cipher.final()]);
        let jsonObj = { iv: iv.toString('hex'), encryptedData: encrypted.toString('hex') };
        return jsonObj.encryptedData;
    },

    decrypt1: function (text) {
        let d_iv = Buffer.from(iv, 'hex');
        let encryptedText = Buffer.from(text, 'hex');
        let decipher = crypto.createDecipheriv(algorithm, Buffer.from(key), d_iv);
        let decrypted = decipher.update(encryptedText);
        decrypted = Buffer.concat([decrypted, decipher.final()]);
        return decrypted.toString();
    },

    encryptdata: function (message = '') {
        var message = CryptoJS.AES.encrypt(message, key);
        return message.toString();
    },
    decrypt: function (message = '') {
        var code = CryptoJS.AES.decrypt(message, key);
        var decryptedMessage = code.toString(CryptoJS.enc.Utf8);
        return decryptedMessage;
    },
    encrypt: function (message = '') {
        return { 'encryptedRequestResponse': this.encryptdata(message) }
    }
}

