const { PDFDocument } = require('pdf-lib');
var fs = require('fs');


mergeSinglePdf = async (blobArrayList) => {
    try {
        const doc = await PDFDocument.create();

        for (const element of blobArrayList) {
            var pages = await PDFDocument.load(element);
            const contentPages1 = await doc.copyPages(pages, pages.getPageIndices());
            for (const page of contentPages1) {
                doc.addPage(page);
            }
        }
        let base64 = await doc.saveAsBase64();
        return base64;
    }
    catch (error) {
        console.log(error);
        return null;

    }

}

module.exports = {
    mergeSinglePdf
}
