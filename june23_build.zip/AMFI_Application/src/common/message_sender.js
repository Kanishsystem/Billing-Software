

module.exports = {

    sendMessage: function (textToSend, phoneNo) {
 
        //send msg 
    }
}