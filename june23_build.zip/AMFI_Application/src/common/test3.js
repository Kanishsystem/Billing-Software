const pool = require('../config/db');
const merge = require('../common/file_merge')

// run().catch(err => console.log(err));

// async function run() {
//     let res = await pool.query(`select image from amfi_file where "id" =3647`)

//     let blob1 = res['rows'][0]['image'];


//     let res2 = await pool.query(`select image from amfi_file where "id" =3648`)

//     let blob2 = res2['rows'][0]['image'];

//     let arr = [];
//     arr.push(blob1)
//     arr.push(blob2)
//     await merge.mergeSinglePdf(arr);

// }