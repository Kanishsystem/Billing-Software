const envObj = require('../config/env.config');

const jwt = require('jsonwebtoken');


generateAuthToken = async (user_id, user_name, pan_no) => {
  const token = jwt.sign(
    {
      user_id: user_id,
      user_name: user_name,
      pan_no: pan_no
    },
    'ahbsjkfbasjkfbjkas',
    {
      expiresIn: "2h",
    }
  );
  return token;
},
  verifyToken = async (token) => {
    if (!token) {
      return { auth: false, message: 'A token is required for authentication' };
    }
    try {
      const decoded = await jwt.verify(token, 'ahbsjkfbasjkfbjkas');
      return { auth: true, message: 'Sucess', data: decoded };
    } catch (err) {
      return { status: 401, auth: false, message: 'Invalid token' };
    }
  }




module.exports = {
  verifyToken,
  generateAuthToken
}