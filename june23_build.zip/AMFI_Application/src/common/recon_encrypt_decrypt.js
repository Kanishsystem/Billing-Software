const _crypto = require('crypto');
// require('dotenv').config();
const envObj = require("../config/env.config");
const phrase = "who let the dogs out";

const ENC_KEY = envObj.RECON_ENC_DEC_KEY;
const IV = envObj.RECON_ENC_DEC_IV;


module.exports = {
  // encrypt: function (val) {
  //   let cipher = _crypto.createCipheriv('aes-256-cbc', ENC_KEY, IV);
  //   let encrypted = cipher.update(val, 'utf8', 'base64');
  //   encrypted += cipher.final('base64');
  //   return encrypted;
  // },

  // decrypt: function (encrypted) {
  //   let decipher = _crypto.createDecipheriv('aes-256-cbc', ENC_KEY, IV);
  //   let decrypted = decipher.update(encrypted, 'base64', 'utf8');
  //   return (decrypted + decipher.final('utf8'));
  // },

  EncryptionandDecryption: function (Mode, InputString = "") {
    let key;
    let hash;
    let hashstring;
    let Dencryptedinput = "";
    let iven;
    let cipher;
    let decipher;
    let encrypted = "";
    let decrypted = "";
    try {
      if (InputString != "") {
        key = ENC_KEY
        hash = _crypto.createHash(envObj.RECON_ENC_DEC_ALGORITHM).update(key).digest();
        hashstring = hash.toString('hex');
        hashstring = hashstring.substring(0, 32);

        iven = IV;
        iven = Buffer.from(iven);

        if (Mode == 'E') {
          cipher = _crypto.createCipheriv('aes-256-cbc', hashstring, iven);

          encrypted = cipher.update(InputString, 'utf8', 'base64') + cipher.final('base64');
          cipher = null;

          encrypted = encrypted.split('+').join('-');
          encrypted = encrypted.split('/').join('_');
          return encrypted;
        }
        else if (Mode == 'D') {
          Dencryptedinput = InputString.split('-').join('+');
          Dencryptedinput = Dencryptedinput.split('_').join('/');

          decipher = _crypto.createDecipheriv('aes-256-cbc', hashstring, iven);
          decrypted = decipher.update(Dencryptedinput, 'base64', 'utf8') + decipher.final('utf8');
          decipher = null;

          return decrypted;
        }
      }
      else {
        return "";
      }
    }
    catch (error) {
      //console.log(error);
      return "";
    }
    finally {
      key = null;
      hash = null;
      hashstring = null;
      Dencryptedinput = null;
      iven = null;
      cipher = null;
      decipher = null;
      encrypted = null;
      decrypted = null;
      InputString = null;
      Mode = null;
    }
  }


}



