
var nodemailer = require('nodemailer');
var helperService = require('../api/services/helper.service');
const envObj = require('../config/env.config');
var smtpTransport = require('nodemailer-smtp-transport');


var transport = nodemailer.createTransport(smtpTransport({
    service: 'gmail',
    host: envObj.email_host,
    port: envObj.email_port,
    auth: {
        user: envObj.email_id,
        pass: envObj.email_password
    }
}));

// var transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//         user: envObj.email_id,
//         pass: envObj.email_password
//     }
// });


module.exports = {

    sendEmail: function (subject, mailBody, recipentEmail) {

        //send email code

        var mailOptions = {
            from: envObj.email_id,
            // from: 'roshan.shetty@tthconsulting.com',
            to: recipentEmail,
            subject: subject,
            html: mailBody
        };

        // transporter.sendMail(mailOptions, function (error, info) {
        //     if (error) {
        //         helperService.saveAuditLogs(error, '', 'sendMail');
        //         console.log(error);
        //     } else {
        //         helperService.saveAuditLogs(info.response, '', 'sendMail');
        //         console.log('Email sent: ' + info.response);
        //     }
        // });

        transport.sendMail(mailOptions, function (err, info) {
            if (err) {
                helperService.saveAuditLogs(error, '', 'sendMail')
                console.log(err)
            } else {
                helperService.saveAuditLogs(info.response, '', 'sendMail');

                console.log(info);
            }
        });
    }
}


