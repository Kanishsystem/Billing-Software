
function initiator(routerApp, app) {
    require('../routes/registration.routes.js')(routerApp, app);
    require('../routes/offlineregister.routes.js')(routerApp, app);
    require('../routes/helper.routes.js')(routerApp, app);
    require('../routes/arnprofile.routes')(routerApp, app);
    require('../routes/euinprofile.routes')(routerApp, app);
    require('../routes/greivance.routes')(routerApp, app);
    require('../routes/gst.routes')(routerApp, app);
    require('../routes/ekyc.routes')(routerApp, app);
    require('../routes/payment.routes')(routerApp, app);
    require('../routes/admin.routes')(routerApp, app);


}

module.exports = initiator;

