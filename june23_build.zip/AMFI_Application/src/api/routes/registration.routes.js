
function initiator(routerApp, app) {
    app.use('/registration', routerApp)
    const registrationController = require("../controllers/registration.controller.js");
    const encryptionDecryption = require('../../common/encrypt_decrypt')
    const helperService = require('../services/helper.service')

    routerApp.get('/', async function (req, res) {
        try {
            res.send("Registration API's");
        }
        catch (error) {
            console.log(error)
        }

    });
    routerApp.post('/getDistributerPendingDataById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getDistributerPendingDataById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);

    });

    routerApp.post('/getARNCategoryDropdwn', async function (req, res) {
        let resData = await registrationController.getARNCategoryDropdwn();
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);

    });
    routerApp.post('/saveRegisterOnAMFI', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.saveRegisterOnAMFI(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'saveRegisterOnAMFI');
        return res.status(resData.status).json(resObj);


    });

    routerApp.post('/updatePersonalDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.updatePersonalDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updatePersonalDetails')
        return res.status(resData.status).json(resObj);

    });

    routerApp.post('/updateCertificationDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.updateCertificationDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updateCertificationDetails')
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/updateBankDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.updateBankDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updateBankDetails');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/updateDocuments', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.updateDocuments(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updateDocuments');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/verifyMobileNoOtp', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.verifyMobileNoOtp(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'verifyMobileNoOtp');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/verifyEmailOtp', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.verifyEmailOtp(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'verifyEmailOtp');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getDetailsByPincode', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getDetailsByPincode(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getBankDetailsByIFSCcode', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getBankDetailsByIFSCcode(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getPersonalDetailsById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getPersonalDetailsById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getCertificationDetailsById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getCertificationDetailsById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getBankDetailsById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getBankDetailsById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/resendMobileOtp', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.resendMobileOtp(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'resendMobileOtp');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/resendEmailOtp', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.resendEmailOtp(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'resendEmailOtp');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updateRegistrationType', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.updateRegistrationType(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updateRegistrationType');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updateCompanyDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.updateCompanyDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updateCompanyDetails');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getCompanyDetailsById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getCompanyDetailsById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getDetailsByARNId', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getDetailsByARNId(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/registrationActivate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        reqObj.user_id = null;
        let resData = await registrationController.registrationActivate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'registrationActivate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getDocumentsById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getDocumentsById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/loginARNEUIN', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.loginARNEUIN(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'loginARNEUIN');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/resumeByPanNo', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.resumeByPanNo(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'resumeByPanNo');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAccountTypeById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getAccountTypeById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getPaymentAmountById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getPaymentAmountById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getDeclarationById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getDeclarationById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getFilebase64ByID', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getFilebase64ByID(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getDropDownData', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.getDropDownData(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/verifyOtp', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.verifyOtp(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'verifyOtp');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/forgotUserId', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.forgotUserId(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'forgotUserId');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/forgotPasswordSendOtp', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.forgotPasswordSendOtp(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'forgotPasswordSendOtp');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/forgotPasswordVerifyOtp', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.forgotPasswordVerifyOtp(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'forgotPasswordVerifyOtp');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/changePassword', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.changePassword(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'changePassword');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updateRegistrationReview', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.updateRegistrationReview(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updateRegistrationReview');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updatePayment', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.updatePayment(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updatePayment');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/logoutARNEUIN', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.logoutARNEUIN(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'logoutARNEUIN');
        return res.status(resData.status).json(resObj);
    });

}
module.exports = initiator;

