
function initiator(routerApp, app) {
    const { uploadBase64 } = require("../../common/file_uploader");
    const helperController = require("../controllers/helper.controller");
    const encryption = require('../../common/encrypt_decrypt')
    const reconService = require('../services/recon.service')
    app.use('/helper', routerApp)
    routerApp.post('/getEncryptedData', async function (req, res) {
        try {
            // reconService.reconGetApplicationData();
            //reconService.reconApiImportData();
            let textToEncrypt = JSON.stringify(req.body);
            let encryptedText = encryption.encrypt(textToEncrypt);
            res.send(encryptedText)
        }
        catch (error) {
            console.log(error)
        }

    });

    routerApp.post('/getDecryptedData', async function (req, res) {
        try {

            let decryptedText = encryption.decrypt(req.body['encryptedRequestResponse']);
            res.send(decryptedText)
        }
        catch (error) {
            console.log(error)
        }

    });

    routerApp.post('/fileUploader', async function (req, res) {
        try {
            //  let obj = uploadBase64(req.body, res);

            let reqObj = JSON.parse(encryption.decrypt(req.body['encryptedRequestResponse']));
            let resData = await helperController.upload_file(reqObj);
            let resObj = encryption.encrypt(JSON.stringify(resData));
            return res.status(resData.status).json(resObj);

        }
        catch (error) {
            console.log(error)
        }

    });
    routerApp.post('/test_file', async function (req, res) {
        try {
            //  let obj = uploadBase64(req.body, res);
            let resData = await helperController.test_file();


        }
        catch (error) {
            console.log(error)
        }

    });
}
module.exports = initiator;
