function initiator(routerApp, app) {
    app.use('/admin', routerApp)

    const adminController = require("../controllers/admin.controller");
    const encryptionDecryption = require('../../common/encrypt_decrypt')
    const helperService = require('../services/helper.service')

    routerApp.get('/', async function (req, res) {
        try {
            res.send("ARN Profile API's");
        }
        catch (error) {
            console.log(error)
        }

    });


    routerApp.post('/searchByAdmin', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.searchByAdmin(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });


    routerApp.post('/getAdmintProfileSummaryById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getAdmintProfileSummaryById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getAdminActiveBankDetailsById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getAdminActiveBankDetailsById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getAdminGSTInfoById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getAdminGSTInfoById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getAdminProfilePictureById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getAdminProfilePictureById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getUpdatesHistory', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getUpdatesHistory(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getRegRenHistory', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getRegRenHistory(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getMappingHistory', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getMappingHistory(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getDeMappingHistory', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getDeMappingHistory(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getViewAllEUINAdmin', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getViewAllEUINAdmin(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getMappingEUINListAdmin', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getMappingEUINListAdmin(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getDeMappingEUINListAdmin', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getDeMappingEUINListAdmin(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getRegisterRenewalEUINAdmin', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getRegisterRenewalEUINAdmin(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getIssueDuplicateReqStatus', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getIssueDuplicateReqStatus(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getProductCategoriesOptionAdmin', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getProductCategoriesOptionAdmin(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/searchByNismPan', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.searchByNismPan(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getInvalidType', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getInvalidType(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getInvalidAuthority', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.getInvalidAuthority(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/saveInvalidDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await adminController.saveInvalidDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'saveInvalidDetails');
        return res.status(resData.status).json(resObj);
    });
}

module.exports = initiator;
