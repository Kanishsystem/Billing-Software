function initiator(routerApp, app) {
    app.use('/greivance', routerApp)

    const encryptionDecryption = require('../../common/encrypt_decrypt');
    const greivanceController = require("../controllers/greivance.controller")
    const helperService = require('../services/helper.service')
    routerApp.get('/', async function (req, res) {
        try {
            res.send("Greivance API's");
        }
        catch (error) {
            console.log(error)
        }
    });

    routerApp.post('/getGreivanceCategory', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.getGreivanceCategory(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getGreivanceSubCategory', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.getGreivanceSubCategory(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/raiseGreivanceRequest', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.raiseGreivanceRequest(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'raiseGreivanceRequest')
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/searchAllGreivanceDetailsByFO', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.searchAllGreivanceDetailsByFO(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getGreivanceDetailsById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.getGreivanceDetailsById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getGreivanceQueue', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.getGreivanceQueue(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/addGreivanceResponses', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.addGreivanceResponses(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'addGreivanceResponses')
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getGreivanceMessages', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.getGreivanceMessages(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getGreivanceMessageDetailsForArn', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.getGreivanceMessageDetailsForArn(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/greivanceCloseTicket', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.greivanceCloseTicket(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'greivanceCloseTicket')
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/greivanceMessageMarkAsRead', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.greivanceMessageMarkAsRead(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'greivanceMessageMarkAsRead')
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/resolveTicketByUser', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.resolveTicketByUser(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'resolveTicketByUser')
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/deleteGreivanceMessage', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.deleteGreivanceMessage(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'deleteGreivanceMessage')
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/deleteAllGreivanceMessage', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await greivanceController.deleteAllGreivanceMessage(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'deleteAllGreivanceMessage')
        return res.status(resData.status).json(resObj);
    });
}

module.exports = initiator;

