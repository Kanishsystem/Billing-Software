function initiator(routerApp, app) {
    app.use('/gst', routerApp)

    const encryptionDecryption = require('../../common/encrypt_decrypt');
    const helperService = require('../services/helper.service')
    const gstController = require('../controllers/gst.controller')
    routerApp.get('/', async function (req, res) {
        try {
            res.send("Gst API's");
        }
        catch (error) {
            console.log(error)
        }
    });

    routerApp.post('/saveGstDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await gstController.saveGstDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'saveGstDetails')
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/updateGstDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await gstController.updateGstDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updateGstDetails')
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/testFileMerge', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await gstController.testFileMerge(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });


}

module.exports = initiator;

