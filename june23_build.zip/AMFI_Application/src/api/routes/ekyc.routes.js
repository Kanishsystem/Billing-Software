

function initiator(routerApp, app) {
    app.use('/ekyc', routerApp)

    const ekycController = require("../controllers/ekyc.controller");
    const encryptionDecryption = require('../../common/encrypt_decrypt')
    const helperService = require('../services/helper.service')
    const _encdec = require('../../ekyc/ekyc_encryption_decryption');
    const envObj = require('../../config/env.config');

    routerApp.get('/', async function (req, res) {
        try {
            res.send("Ekyc API's");
        }
        catch (error) {
            console.log(error)
        }

    });

    routerApp.post('/verifyAadhar', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await ekycController.verifyAadhar(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'verifyAadhar');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/saveAadharResponse', async function (req, res) {
        // await helperService.saveAuditLogs(req.body, {}, 'saveAadharResponse1');
        // let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await ekycController.saveAadharResponse(req.body);
        // let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(req.body, resData, 'saveAadharResponse2');
        //return res.status(200).json(resData);
        if (resData.status == 500) {
            // let resUrl = envObj.application_onlineurl + `/#/sessions/kyc?status=Error&message=Error During Ekyc`;
            //  resData.status = 200;
            let resUrl = envObj.application_onlineurl + `/#/sessions/kyc?status=` + resData.status + '&message=' + 'Error During Ekyc';
            return res.redirect(resUrl);

        } else {

            let resUrl = envObj.application_onlineurl + `/#/sessions/kyc?status=` + resData.status + '&message=' + resData.message;

            return res.redirect(resUrl);
        }

    });

    routerApp.post('/saveOnlineAadharResponse', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        // let resData = await ekycController.saveAadharResponse(req.body.test);
        // let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, {}, 'saveOnlineAadharResponse');
        return res.status(200).json({ 'status': 'sucess' });
    });

    routerApp.post('/updateEkycFiles', async function (req, res) {
        // let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        console.log("req.body==========>", req.body)
        let resData = await ekycController.updateEkycFiles(req.body);
        // let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(req.body, resData, 'updateEkycFiles');
        return res.status(resData.status).json(resData);
    });

}

module.exports = initiator;

