function initiator(routerApp, app) {
    app.use('/euin', routerApp)

    const euinProfileController = require("../controllers/euinprofile.controller");
    const registrationController = require("../controllers/registration.controller")
    const encryptionDecryption = require('../../common/encrypt_decrypt')
    const helperService = require('../services/helper.service')

    routerApp.get('/', async function (req, res) {
        try {
            res.send("EUIN Profile API's");
        }
        catch (error) {
            console.log(error)
        }

    });

    routerApp.post('/getEUINProfileSummary', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await euinProfileController.getEUINProfileSummary(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getARNDetailsByEUINId', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await euinProfileController.getARNDetailsByEUINId(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updatNewEmployerForEUIN', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await euinProfileController.updatNewEmployerForEUIN(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'updatNewEmployerForEUIN');
        return res.status(resData.status).json(resObj);

    });
    routerApp.post('/activateEUINById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await registrationController.registrationActivate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'activateEUINById');
        return res.status(resData.status).json(resObj);

    });

    routerApp.post('/sentForRenewalByEUINId', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await euinProfileController.sentForRenewalByEUINId(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'sentForRenewalByEUINId');
        return res.status(resData.status).json(resObj);

    });

}

module.exports = initiator;

