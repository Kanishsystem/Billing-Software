function initiator(routerApp, app) {
    app.use('/arn', routerApp)

    const arnProfileController = require("../controllers/arnprofile.controller.js");
    const encryptionDecryption = require('../../common/encrypt_decrypt')
    const helperService = require('../services/helper.service')

    routerApp.get('/', async function (req, res) {
        try {
            res.send("ARN Profile API's");
        }
        catch (error) {
            console.log(error)
        }

    });


    routerApp.post('/getProfileSummaryById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getProfileSummaryById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getActiveBankDetailsById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getActiveBankDetailsById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getGSTInfoById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getGSTInfoById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getProfilePictureById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getProfilePictureById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    //Update Data
    routerApp.post('/updateActiveProfileAddress', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.updateActiveProfileAddress(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'updateActiveProfileAddress');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/updateActiveBankDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.updateActiveBankDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'updateActiveBankDetails');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/updateGSTInfo', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.updateGSTInfo(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'updateGSTInfo');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updateProfilePicture', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.updateProfilePicture(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'updateProfilePicture');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updateProfilePicture', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.updateProfilePicture(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'updateProfilePicture');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getARNRenewal', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getARNRenewal(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/sendMobileNoChangeOtpForProfile', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.sendMobileNoChangeOtpForProfile(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'sendMobileNoChangeOtpForProfile');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/sendEmailChangeOtpForProfile', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.sendEmailChangeOtpForProfile(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'sendEmailChangeOtpForProfile');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/resendEmailChangeOtpForProfile', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.resendEmailChangeOtpForProfile(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'resendEmailChangeOtpForProfile');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/resendMobileNoChangeOtpForProfile', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.resendMobileNoChangeOtpForProfile(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'resendMobileNoChangeOtpForProfile');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/verifyEmailAndUpdateEMail', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.verifyEmailAndUpdateEMail(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'verifyEmailAndUpdateEMail');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/VerifyMobileAndUpdateMobile', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.VerifyMobileAndUpdateMobile(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'VerifyMobileAndUpdateMobile');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getMappingEUINList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getMappingEUINList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getDeMappingEUINList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getDeMappingEUINList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getViewAllEUIN', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getViewAllEUIN(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getEUINRenewalList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getEUINRenewalList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getRegistrationPaymentList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getRegistrationPaymentList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getProductCategoriesOption', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getProductCategoriesOption(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/saveProductCategoriesOption', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.saveProductCategoriesOption(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'saveProductCategoriesOption');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/viewMappingEUINApplicationById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.viewMappingEUINApplicationById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/removeDeMappingEUIN', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.removeDeMappingEUIN(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'removeDeMappingEUIN');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/approveMappingEUIN', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.approveMappingEUIN(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'approveMappingEUIN');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/viewRenewalResigtrationEUINs', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getRegistrationPaymentList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getARNRenewalDetailsById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getARNRenewalDetailsById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/rejectMappingById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.rejectMappingById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'rejectMappingById');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/rejectDeMappingById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.rejectDeMappingById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'rejectDeMappingById');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getselfDeclarationByCode', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.getselfDeclarationByCode(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/verifyEmailAndsubmitDeclaration', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.verifyEmailAndsubmitDeclaration(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'verifyEmailAndsubmitDeclaration');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/verifyMobileAndsubmitDeclaration', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.verifyMobileAndsubmitDeclaration(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'verifyMobileAndsubmitDeclaration');
        return res.status(resData.status).json(resObj);
    });


    routerApp.post('/sentForRenewalByARNId', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await arnProfileController.sentForRenewalByARNId(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'sentForRenewalByARNId');
        return res.status(resData.status).json(resObj);

    });

}

module.exports = initiator;

