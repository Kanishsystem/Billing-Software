function initiator(routerApp, app) {
    app.use('/payment', routerApp)
    const envObj = require('../../config/env.config');

    const paymentController = require("../controllers/payment.controller");
    const encryptionDecryption = require('../../common/encrypt_decrypt')
    const helperService = require('../services/helper.service')

    routerApp.get('/', async function (req, res) {
        try {
            res.send("Payment API's");
        }
        catch (error) {
            console.log(error)
        }

    });

    routerApp.post('/createOnlinePayment', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await paymentController.createOnlinePayment(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/saveOnlinePaymentTransaction', async function (req, res) {
        // let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await paymentController.saveOnlinePaymentTransaction(req.body.msg);
        // let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(req.body.msg, resData, 'saveOnlinePaymentTransaction');
        // return res.status(200).json(resData);
        let resUrl = envObj.application_onlineurl + `/#/payment/redirect/?status=` + resData.status + '&message=' + resData.message;
        return res.redirect(resUrl);
    });

    routerApp.get('/billdeskCallbackTxnStatusUpdate', async function (req, res) {
        try {
            let resData = await paymentController.billdeskCallbackTxnStatusUpdate(req.body);
            return res.status(200).json({ 'status': 200, 'message': 'Success' });
        }
        catch (error) {
            console.log(error)
            return res.status(200).json({ 'status': 200, 'message': 'Success' });

        }
    });

}

module.exports = initiator;

