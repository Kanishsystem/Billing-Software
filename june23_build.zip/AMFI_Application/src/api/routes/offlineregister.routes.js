function initiator(routerApp, app) {
    app.use('/offline', routerApp)
    const offlineregistercontroller = require("../controllers/offlineregister.controller.js");
    const encryptionDecryption = require('../../common/encrypt_decrypt');
    const helperService = require('../services/helper.service')

    routerApp.get('/', async function (req, res) {
        try {
            res.send("Offline Register API's");
        }
        catch (error) {
            console.log(error)
        }

    });

    routerApp.post('/getState', async function (req, res) {
        let resData = await offlineregistercontroller.getState();
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);

    });


    routerApp.post('/saveOfflineRegister', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.saveOfflineRegister(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'saveOfflineRegister');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getDocumentCheckListByType', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getDocumentCheckListByType(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/loginFO', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.loginFO(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getOfflineRegisterDataById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getOfflineRegisterDataById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitOfflineRegister', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitOfflineRegister(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'submitOfflineRegister');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAllARNList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAllARNList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updatePriority', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.updatePriority(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updateFo1Assign', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.updateFo1Assign(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'updateFo1Assign');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getOfflineApplicantDatasById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getOfflineApplicantDatasById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthorisation', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthorisation(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthorisation');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/updateFo2Assign', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.updateFo2Assign(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'updateFo2Assign');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getUploadedDocumentById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getUploadedDocumentById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'getUploadedDocumentById');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/loginBO', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.loginBO(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthorisationList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthorisationList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/saveOfflineRenewal', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.saveOfflineRenewal(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'saveOfflineRenewal');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/searchByArnNoApproved', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.searchByArnNoApproved(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/searchByEUINNoApproved', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.searchByEUINNoApproved(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/loginFOBO', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.loginFOBO(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'loginFOBO');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getRequestTypes', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getRequestTypes(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/saveRequestedUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.saveRequestedUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'saveRequestedUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getRejectReason', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getRejectReason(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getGender', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getGender(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getOfflineUpdateById', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getOfflineUpdateById(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitOfflineUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitOfflineUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitOfflineUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getOfflineUpdateQueueList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getOfflineUpdateQueueList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/offlineUpdatedataBoAssign', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.offlineUpdatedataBoAssign(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'offlineUpdatedataBoAssign');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getFinancialYear', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getFinancialYear(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthoriseSelfDeclareUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseSelfDeclareUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseSelfDeclaration', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseSelfDeclaration(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseSelfDeclaration');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthoriseSignatureUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseSignatureUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseSignature', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseSignature(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseSignature');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthoriseBasicDetailsUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseBasicDetailsUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseBasicDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseBasicDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseBasicDetails');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthoriseBankDetailsUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseBankDetailsUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseBankDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseBankDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseBankDetails');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthoriseContactsUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseContactsUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseContacts', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseContacts(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseContacts');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthoriseGSTDetailsUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseGSTDetailsUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseGSTDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseGSTDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseGSTDetails');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthorisephotoUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthorisephotoUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authorisePhoto', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authorisePhoto(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authorisePhoto');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthoriseOptionUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseOptionUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseOption', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseOption(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseOption');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthoriseMappingUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseMappingUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseMapping', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseMapping(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseMapping');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getNigoList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getNigoList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/searchNigoDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.searchNigoDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitNigoApplicationByFo', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitNigoApplicationByFo(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitNigoApplicationByFo');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/offlineUpdatedataBo2Assign', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.offlineUpdatedataBo2Assign(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'offlineUpdatedataBo2Assign');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/submitForAuthoriseSelfdeclareUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseSelfdeclareUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseSelfdeclareUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthoriseSignatureUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseSignatureUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseSignatureUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthoriseBasicDetailUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseBasicDetailUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseBasicDetailUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthoriseBankDetailsUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseBankDetailsUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseBankDetailsUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthoriseContactsUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseContactsUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseContactsUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthoriseGstUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseGstUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseGstUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthorisePhotoUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthorisePhotoUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthorisePhotoUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthoriseOptionUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseOptionUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseOptionUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthoriseMappingUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseMappingUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseMappingUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getOfflineUpdateAuthoriseList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getOfflineUpdateAuthoriseList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getNigoAuthorisationList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getNigoAuthorisationList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/nigoBo1Assign', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.nigoBo1Assign(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'nigoBo1Assign');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/nigoBo2Assign', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.nigoBo2Assign(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'nigoBo2Assign');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseRegisterRenewal', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        await helperService.saveErrorAuditLogs(reqObj, '', 'STARTROUTE')
        let resData = await offlineregistercontroller.authoriseRegisterRenewal(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseRegisterRenewal');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/rejectRegisterRenewal', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.rejectRegisterRenewal(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'rejectRegisterRenewal');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/rejectUpdates', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.rejectUpdates(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'rejectUpdates');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/rejectRegisterRenewalToNigo', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.rejectRegisterRenewalToNigo(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'rejectRegisterRenewalToNigo');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/rejectUpdatesToNigo1', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.rejectUpdatesToNigo(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'rejectUpdatesToNigo1');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getNigoApplicantDetails', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getNigoApplicantDetails(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitNigoForAuthorisation', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitNigoForAuthorisation(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitNigoForAuthorisation');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/authoriseNigoApplication', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseNigoApplication(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseNigoApplication');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/searchDetailsByPanNoForNigo', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.searchDetailsByPanNoForNigo(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/searchDetailsByPanNoForNigo', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.searchDetailsByPanNoForNigo(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/cancelAssignedRegisration', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.cancelAssignedRegisration(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'cancelAssignedRegisration');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/cancelAssignedRegisration', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.cancelAssignedRegisration(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'cancelAssignedRegisration');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/cancelAssignedUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.cancelAssignedUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'cancelAssignedUpdate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/cancelAssignedNigo', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.cancelAssignedNigo(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'cancelAssignedNigo');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getAuthoriseDuplicateCardUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseDuplicateCardUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthoriseDupCardUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseDupCardUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseDupCardUpdated');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/authoriseDupCardUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseDupCardUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseDupCardUpdated');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getCardPrintingList', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getCardPrintingList(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/payForIssueDuplicate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.payForIssueDuplicate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'payForIssueDuplicate');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/getCardIssueStatus', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getCardIssueStatus(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/submitForAuthorisationNewCadre', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthorisation(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthorisation');
        return res.status(resData.status).json(resObj);
    });
    routerApp.post('/submitForAuthorisationOverseaseDistributer', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthorisation(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthorisation');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/logoutFOBO', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.logoutFOBO(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData))
        await helperService.saveAuditLogs(reqObj, resData, 'logoutFOBO');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getAuthoriseSignatoryUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseSignatoryUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/submitForAuthoriseSignatoryUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseSignatoryUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseSignatoryUpdate');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/authoriseSignatory', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseSignatory(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseSignatory');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/getAuthoriseCategoryUpdated', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.getAuthoriseCategoryUpdated(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/submitForAuthoriseCategoryUpdate', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.submitForAuthoriseCategoryUpdate(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'submitForAuthoriseCategoryUpdate');
        return res.status(resData.status).json(resObj);
    });

    routerApp.post('/authoriseCategory', async function (req, res) {
        let reqObj = JSON.parse(encryptionDecryption.decrypt(req.body['encryptedRequestResponse']));
        let resData = await offlineregistercontroller.authoriseCategory(reqObj);
        let resObj = encryptionDecryption.encrypt(JSON.stringify(resData));
        await helperService.saveAuditLogs(reqObj, resData, 'authoriseCategory');
        return res.status(resData.status).json(resObj);
    });

}
module.exports = initiator;
