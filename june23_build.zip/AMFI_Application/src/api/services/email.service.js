

const email_sender = require('../../common/email_sender');
const pool = require("../../config/db");
const moment = require("moment");

sendOtpEmailRegister = async (pan_no, to_email_id, application_type) => {
    try {
        // let otpemail = Math.floor(100000 + Math.random() * 900000);
        let otpemail = '123456'
        let no_of_attempts = 0;
        let msgres = null;
        if (application_type == 'ARN') {
            msgres = await getMessageEmailData('ONLINE_ARN_REG_OTP');
        }
        else {
            msgres = await getMessageEmailData('ONLINE_EUIN_REG_OTP');

        }
        if (msgres !== null) {
            let subject = msgres['subject'];
            let body = msgres['body']
            body = body.replace('***mobile_otp***', otpemail)
            email_sender.sendEmail(subject, body, to_email_id);
        }
        let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [pan_no])
        if (res['rowCount'] > 0) {
            await pool.query(`update amfi_mobile_email_otp set "lastmobile_otp_senttime"=$1,"modified_date"=$3,"email_otp"=$4,"no_of_attempts"=$5,"email_id"=$6 where "pan_no"=$2`, ['now()', pan_no, 'now()', otpemail, no_of_attempts, to_email_id])
        }
        else {
            await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, ['', to_email_id, '', otpemail, 'now()', 'now()', no_of_attempts, true, null, null, 'now()', pan_no])
        }
    }
    catch (error) {
        console.log(error)
    }

}

sendOtpEmailResume = async (pan_no, to_email_id) => {
    //  let otpemail = Math.floor(100000 + Math.random() * 900000);
    let otpemail = '123456'
    let no_of_attempts = 0;
    let msg_emailres = await pool.query(`select subject ,body  from tbl_msg_email where code ='ONLINE_ARN_REG_OTP' 
    `)
    if (msg_emailres['rowCount'] > 0) {
        subject = msg_emailres['rows'][0]['subject'];
        msg = msg_emailres['rows'][0]['body'];
    }

    msg = msg.replace('***otp***', otpemail)
    email_sender.sendEmail(subject, msg, to_email_id);

    let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [pan_no])
    if (res['rowCount'] > 0) {
        await pool.query(`update amfi_mobile_email_otp set "lastmobile_otp_senttime"=$1,"modified_date"=$3,"email_otp"=$4,"no_of_attempts"=$5,"email_id"=$6 where "pan_no"=$2`, ['now()', pan_no, 'now()', otpemail, no_of_attempts, to_email_id])
    }
    else {
        await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, ['', to_email_id, '', otpemail, 'now()', 'now()', no_of_attempts, true, '', '', 'now()', pan_no])
    }

}
sendOtpEmail = async (pan_no, email_id, subject, mail_body) => {
    //let otpemail = Math.floor(100000 + Math.random() * 900000);
    let otpemail = '123456'; //common.random number generator 6 digit
    let no_of_attempts = 0;
    email_sender.sendEmail(subject, mail_body, email_id);

    let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [pan_no])
    if (res['rowCount'] > 0) {
        await pool.query(`update amfi_mobile_email_otp set "email_otp"=$1,"email_id"=$2,"lastmobile_otp_senttime"=$3,"modified_date"=$5,"no_of_attempts"=$6 where "pan_no"=$4`, [otpemail, email_id, 'now()', pan_no, 'now()', no_of_attempts])
    }
    else {
        await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, ['', otpemail, '', email_id, 'now()', 'now()', no_of_attempts, true, '', '', 'now()', pan_no])
    }
}

sendClientEmail = async (pan_no, to_email_id, code) => {
    let subject = '';
    let msg = '';
    let msg_emailres = await pool.query(`select subject ,body  from tbl_msg_email where code =${code} 
    `)
    if (msg_emailres['rowCount'] > 0) {
        subject = msg_emailres['rows'][0]['subject'];
        msg = msg_emailres['rows'][0]['body'];
    }
}

resendOnlineARNRegOTpEmail = async (pan_no, to_email_id, otpemail) => {
    try {
        let res = null;
        let selected_data = await pool.query(`select application_type  from amfi_distributer_master_pending where pan_no =$1
        `, [pan_no])

        if (selected_data['rowCount'] > 0) {
            if (selected_data['rows'][0]['application_type'] == 'ARN') {
                res = await getMessageEmailData('ONLINE_ARN_REG_OTP_RESEND');
            }
            else {
                res = await getMessageEmailData('ONLINE_EUIN_REG_OTP_RESEND');
            }
        }
        if (res !== null) {
            let subject = res['subject'];
            let body = res['body']
            body = body.replace('***mobile_otp***', otpemail)
            email_sender.sendEmail(subject, body, to_email_id);
        }
    }
    catch (error) {
        console.log(error)
    }
}

onlineARNSubmitEmail = async (pan_no, to_email_id) => {
    try {
        let res = await getMessageEmailData('ONLINE_ARN_REGISTRATION');
        if (res !== null) {
            let subject = res['subject'];
            let body = res['body']
            body = body.replace('***created_date***', moment().format('DD-MM-YYYY'))
            email_sender.sendEmail(subject, body, to_email_id);
        }
    }
    catch (error) {
        console.log(error)
    }
}

getMessageEmailData = async (code) => {
    let res = await pool.query(`select "type" ,subject ,body  from tbl_msg_email where code=$1`, [code])

    if (res['rowCount'] > 0) {
        return { 'type': res['rows'][0]['type'], 'subject': res['rows'][0]['subject'], 'body': res['rows'][0]['body'] }
    }
    return null;
}

onlineEUINSubmitEmail = async (pan_no, to_email_id) => {
    try {
        let res = await getMessageEmailData('ONLINE_ARN_REGISTRATION');
        if (res !== null) {
            let subject = res['subject'];
            let body = res['body']
            body = body.replace('***created_date***', moment().format('DD-MM-YYYY'))
            email_sender.sendEmail(subject, body, to_email_id);
        }
    }
    catch (error) {
        console.log(error)
    }
}

offlineFORegSubmitEmail = async (pan_no, to_email_id) => {
    try {
        let res = await getMessageEmailData('OFFLINE_ARN_REG_IND_NONIND');
        if (res !== null) {
            let subject = res['subject'];
            let body = res['body']
            body = body.replace('***created_date***', moment().format('DD-MM-YYYY'))
            email_sender.sendEmail(subject, body, to_email_id);
        }
    }
    catch (error) {
        console.log(error)
    }
}

module.exports = {
    sendOtpEmailRegister,
    sendClientEmail,
    sendOtpEmailResume,
    getMessageEmailData,
    resendOnlineARNRegOTpEmail,
    onlineARNSubmitEmail,
    onlineEUINSubmitEmail,
    offlineFORegSubmitEmail
}
