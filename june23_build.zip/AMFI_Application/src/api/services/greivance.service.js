const pool = require("../../config/db");
const helperService = require("../services/helper.service")

getGreivanceCategory = async (data) => {
    let res = await pool.query(`select distinct ("category") from amfi_greiv_category_master where "status"=true`)

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;

}

getGreivanceSubCategory = async (data) => {
    let res = await pool.query(`select "subcategory"  from amfi_greiv_category_master where "status"=true and "category"=$1`, [data.category])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;

}

raiseGreivanceRequest = async (data) => {
    let ticket_no = 1000;
    // let select_counter = await pool.query(`select * from amfi_counter`)
    // if (select_counter['rowCount'] > 0) {
    //     ticket_no = select_counter['rows'][0]['griv_ticket_counter'] + 1
    //     await pool.query(`update amfi_counter set "griv_ticket_counter"='${ticket_no}'`)
    // }
    ticket_no = await helperService.generateTicketNumber();
    let res = await pool.query(`INSERT INTO amfi_greivance_request
   (ticket_no, pan_no, category, subcategory, status, action_status_fo, action_code_fo, action_status_bo,action_code_bo,"document",  created_by,modified_by, modified_date,type)
   VALUES( $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) Returning "ticket_no","id"`, [ticket_no, data.pan_no, data.category, data.subcategory, "Pending", 'Submitted', 'SUBMITTED', 'Pending Response', 'PENDING_RESPONSE', data.document, data.user_id, data.user_id, 'now()', data.type]);

    if (res['rowCount'] > 0) {
        await pool.query(`INSERT INTO amfi_greivance_responses
        (ticket_no, pan_no, "Message", added_by, created_by,  modified_by, modified_date,"attachment")VALUES($1,$2,$3,$4,$5,$6,$7,$8)`, [ticket_no, data.pan_no, data.Message, 'USER', data.user_id, data.user_id, 'now()', ''])

        return res['rows'][0];
    }
    return null;
}

searchAllGreivanceDetailsByFO = async (data) => {
    let res = await pool.query(`select "ticket_no","pan_no","category" ,"subcategory","status",action_status_fo,action_status_bo,to_char("created_date",'YYYY-MM-DD'),type  from amfi_greivance_request where "pan_no"=$1`, [data.pan_no])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

getGreivanceDetailsById = async (data) => {
    let res = await pool.query(`select A."pan_no",A."category",A."subcategory",A."document",B."first_name",B."middle_name",B."last_name",B."mobile_no",B."email_id",B."arn_number",A."type",A."action_status_fo",A."action_status_bo" from amfi_greivance_request A,amfi_distributer_master_approved B where A."pan_no"=B."pan_no" and A."ticket_no" =$2 and A."pan_no"=$1`, [data.pan_no, data.ticket_no])

    if (res['rowCount'] > 0) {
        let doc_id = res['rows'][0]['document'];
        res['rows'][0]['document_base64'] = null;
        res['rows'][0]['document_image_type'] = '';
        res['rows'][0]['document_filename'] = '';
        var num1 = parseInt(doc_id) || 0;
        if (num1 > 0) {
            let doc_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [doc_id])
            if (doc_res['rowCount'] > 0) {
                let imgBuff = doc_res['rows'][0]['image'];
                res['rows'][0]['document_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                res['rows'][0]['document_image_type'] = doc_res['rows'][0]['image_type'];
                res['rows'][0]['document_filename'] = doc_res['rows'][0]['file_name']
            }
        }
        return res['rows'][0];
    }
    return null;

}

getGreivanceQueue = async (data) => {
    let res = await pool.query(`select A."ticket_no",A."pan_no",A."category" ,A."subcategory",A."status",A.action_status_fo,A.action_status_bo,to_char(A."created_date",'YYYY-MM-DD'),A."type",B."first_name" ,B."middle_name" ,B."last_name"  from amfi_greivance_request A,amfi_distributer_master_pending B where A."pan_no"=B."pan_no" and A."status"!='Deleted' order by A."created_date" desc`,)

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

addGreivanceResponses = async (data) => {
    let attachment = '';
    if ('attachment' in data) {
        attachment = data.attachment;
    }
    let res = await pool.query(`INSERT INTO amfi_greivance_responses
    (ticket_no, pan_no, "Message", added_by, created_by,  modified_by, modified_date,"attachment")VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING "ticket_no","id"`, [data.ticket_no, data.pan_no, data.Message, data['added_by'].toUpperCase(), data.user_id, data.user_id, 'now()', attachment])

    if (res['rowCount'] > 0) {
        let action_status_fo = 'Submitted';
        let action_code_fo = 'SUBMITTED';
        let action_status_bo = 'Pending Response';
        let action_code_bo = 'PENDING_RESPONSE';
        if (data['added_by'].toUpperCase() == 'BO') {
            action_status_fo = 'Needs Clarification';
            action_code_fo = 'NEEDS_CLARIFICATION';
            action_status_bo = 'User Clarification';
            action_code_bo = 'USER_CLARIFICATION';
        }

        await pool.query(`update amfi_greivance_request set action_status_fo=$3, action_code_fo=$4, action_status_bo=$5,action_code_bo=$6, modified_by=$7, modified_date=$8,is_msg_read=$9 where "pan_no"=$1 and "ticket_no"=$2`, [data.pan_no, data.ticket_no, action_status_fo, action_code_fo, action_status_bo, action_code_bo, data.user_id, 'now()', false])
        return res['rows'][0];
    }

    return null;
}

getGreivanceMessages = async (data) => {
    let res = await pool.query(`select A."ticket_no",A."pan_no",A."Message",A."added_by",A."id" as msg_id,A."attachment",B.file_name ,B.image_type,A."created_date" from amfi_greivance_responses A left join amfi_file  B on A."attachment"=cast(B."id" as character varying(20)) and B."status"=true where A."ticket_no" =$1 and A."pan_no"= $2 and A."status"=true order by "created_date" ASC`, [data.ticket_no, data.pan_no])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getGreivanceMessageDetailsForArn = async (data) => {
    let res = await pool.query(`select "ticket_no","pan_no","category" ,"subcategory","status","action_status_fo","action_status_bo",type,is_msg_read,"created_date"  from amfi_greivance_request where "pan_no"=$1 and "status"!='Deleted' order by "created_date" DESC`, [data.pan_no])

    if (res['rowCount'] > 0) {
        for (let i = 0; i < res['rows'].length; i++) {
            let select_msg = await pool.query(`select A."ticket_no",A."pan_no",A."Message",A."added_by",A."id" as msg_id,A."attachment",B.file_name ,B.image_type,A."created_date" from amfi_greivance_responses A left join amfi_file  B on A."attachment"=cast(B."id" as character varying(20)) and B."status"=true where A."ticket_no" =$1 and A."pan_no"= $2 and A.status=true order by A."created_date" DESC limit 1`, [res['rows'][i]['ticket_no'], res['rows'][i]['pan_no']])
            res['rows'][i]['message'] = '';
            res['rows'][i]['added_by'] = '';
            res['rows'][i]['msg_id'] = '';
            res['rows'][i]['attachment'] = '';
            res['rows'][i]['file_name'] = '';
            res['rows'][i]['image_type'] = '';
            if (select_msg['rowCount'] > 0) {
                res['rows'][i]['message'] = select_msg['rows'][0]['Message']
                res['rows'][i]['added_by'] = select_msg['rows'][0]['added_by'];
                res['rows'][i]['msg_id'] = select_msg['rows'][0]['msg_id']
                res['rows'][i]['attachment'] = select_msg['rows'][0]['attachment'];
                res['rows'][i]['file_name'] = select_msg['rows'][0]['file_name'];
                res['rows'][i]['image_type'] = select_msg['rows'][0]['image_type'];
                res['rows'][i]['created_date'] = select_msg['rows'][0]['created_date'];
            }

        }
        return res['rows'];
    }
    return null;
}
greivanceCloseTicket = async (data) => {
    let attachment = '';
    if ('attachment' in data) {
        attachment = data.attachment;
    }
    let res = await pool.query(`INSERT INTO amfi_greivance_responses
    (ticket_no, pan_no, "Message", added_by, created_by,  modified_by, modified_date,"attachment")VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING "ticket_no","id"`, [data.ticket_no, data.pan_no, data.Message, data['added_by'].toUpperCase(), data.user_id, data.user_id, 'now()', attachment])

    if (res['rowCount'] > 0) {
        let action_status_fo = 'View Ticket';
        let action_code_fo = 'VIEWTICKET';
        let action_status_bo = 'View Ticket';
        let action_code_bo = 'VIEWTICKET';


        await pool.query(`update amfi_greivance_request set action_status_fo=$3, action_code_fo=$4, action_status_bo=$5,action_code_bo=$6, modified_by=$7, modified_date=$8,"status"=$9 where "pan_no"=$1 and "ticket_no"=$2`, [data.pan_no, data.ticket_no, action_status_fo, action_code_fo, action_status_bo, action_code_bo, data.user_id, 'now()', 'Closed'])
        return res['rows'][0];
    }

    return null;
}

greivanceMessageMarkAsRead = async (data) => {
    let ticket_nostr = '';
    for (let i = 0; i < data.ticket_no.length; i++) {
        let ticket_no = data.ticket_no[i]
        ticket_nostr += '\'' + ticket_no + '\'' + ','
    }
    ticket_nostr = ticket_nostr.slice(0, ticket_nostr.length - 1);
    let res = await pool.query(`update amfi_greivance_request set is_msg_read=true,  modified_by=$1, modified_date=$2 where  "ticket_no" in (${ticket_nostr})`, [data.user_id, 'now()'])

    if (res['rowCount'] > 0) {
        return data.ticket_no;
    }
    return null;
}

resolveTicketByUser = async (data) => {
    let action_status_fo = 'View Ticket';
    let action_code_fo = 'VIEWTICKET';
    let action_status_bo = 'View Ticket';
    let action_code_bo = 'VIEWTICKET';

    let res = await pool.query(`update amfi_greivance_request set action_status_fo=$3, action_code_fo=$4, action_status_bo=$5,action_code_bo=$6, modified_by=$7, modified_date=$8,"status"=$9 where "pan_no"=$1 and "ticket_no"=$2 returning "id"`, [data.pan_no, data.ticket_no, action_status_fo, action_code_fo, action_status_bo, action_code_bo, data.user_id, 'now()', 'Closed'])

    if (res['rowCount'] > 0) {
        return res['rows'][0]['id'];
    }
    return null;
}

deleteGreivanceMessage = async (data) => {
    let res = await pool.query(`update  amfi_greivance_responses set status =false,modified_by=$3, modified_date=$4 where pan_no =$1 and ticket_no =$2 and "id" in (${data.msg_id}) and status=true returning "id"`, [data.pan_no, data.ticket_no, data.user_id, 'now()'])

    if (res['rowCount'] > 0) {
        return data.msg_id;
    }
    return null;
}

deleteAllGreivanceMessage = async (data) => {
    let ticket_nostr = '';
    for (let i = 0; i < data.ticket_no.length; i++) {
        let ticket_no = data.ticket_no[i]
        ticket_nostr += '\'' + ticket_no + '\'' + ','
    }
    ticket_nostr = ticket_nostr.slice(0, ticket_nostr.length - 1);
    let res = await pool.query(`update  amfi_greivance_responses set status =false,modified_by=$2, modified_date=$3 where pan_no =$1 and "ticket_no" in (${ticket_nostr})  and status=true returning "id"`, [data.pan_no, data.user_id, 'now()'])

    if (res['rowCount'] > 0) {
        await pool.query(`update amfi_greivance_request set "status"=$4,modified_by=$2, modified_date=$3  where "pan_no"=$1 and "ticket_no" in (${ticket_nostr}) returning "id"`, [data.pan_no, data.user_id, 'now()', 'Deleted'])
        return data.ticket_no;
    }
    return null;
}

module.exports = {
    getGreivanceCategory,
    getGreivanceSubCategory,
    raiseGreivanceRequest,
    searchAllGreivanceDetailsByFO,
    getGreivanceDetailsById,
    getGreivanceQueue,
    addGreivanceResponses,
    getGreivanceMessages,
    getGreivanceMessageDetailsForArn,
    greivanceCloseTicket,
    greivanceMessageMarkAsRead,
    resolveTicketByUser,
    deleteGreivanceMessage,
    deleteAllGreivanceMessage
}