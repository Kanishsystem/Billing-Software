const email_sender = require("../../common/email_sender");
const message_sender = require("../../common/message_sender");
const pool = require("../../config/db");
const moment = require("moment");

const helper = require("../services/helper.service");
const offlineService = require("../services/offlineregister.service")
const mergeSinglePdf = require("../../common/file_merge");
const { PDFDocument } = require('pdf-lib')
const emailService = require("../services/email.service");


getDistributerPendingDataById = async (data) => {
    let res = await pool.query(`select * from amfi_distributer_master_pending where id=$1`, [data.id])
    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

getARNCategoryDropdwn = async () => {
    let res = await pool.query(`select "id","category_code","category_description" from "tbl_amfi_category_master" where "status"=$1 and "req_type"=$2 order by "id"`, [true, 'ARN'])
    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

saveRegisterOnAMFI = async (data) => {
    // declare nism varibale default null or 0
    let certificate_number = ''
    let date_of_passing_test = null
    let cpe_certificate_number = ''
    let date_of_cpe_from = null
    let date_of_cpe_to = null
    let validity_from = moment().format('YYYY-MM-DD');
    let validity_to = moment(validity_from, 'YYYY-MM-DD').add(3, 'years');
    let application_reference_no = ''
    // let select_counter = await pool.query(`select * from amfi_counter`)
    // if (select_counter['rowCount'] > 0) {
    //     let applicount = select_counter['rows'][0]['application_reference_count'] + 1
    //     application_reference_no = 'APP-REF' + applicount
    //     await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
    // }
    application_reference_no = await helper.generateApplicationNumber()

    if (data['application_type'] == 'EUIN') {
        data['category_of_corporation'] = 'EMP'
    }

    // if (data['application_type'] == 'ARN') {
    let coporate_res = await pool.query(`select "exam_code" from tbl_amfi_category_master where "category_code"=$1`, [data.category_of_corporation])

    if (coporate_res['rowCount'] > 0) {
        let nism_res = await pool.query(`select  to_char("nism_certificate_date",'YYYY-MM-DD') as date_of_passing_test,"nism_certificate_no" as certificate_number,to_char("validity_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("validity_to",'YYYY-MM-DD') AS date_of_cpe_to  from tbl_user_nism_details  where "nism_category"=$1 and "pan_no"=$2 order by "created_date" desc`, [coporate_res['rows'][0]['exam_code'], data['pan_no']])


        if (nism_res['rowCount'] > 0) {
            date_of_passing_test = nism_res['rows'][0]['date_of_passing_test']
            certificate_number = nism_res['rows'][0]['certificate_number']
            validity_from = nism_res['rows'][0]['date_of_cpe_from']
            validity_to = nism_res['rows'][0]['date_of_cpe_to']
        }
    }
    // }

    let res = await pool.query(`INSERT INTO amfi_distributer_master_pending("pan_no","mobile_no","email_id","application_type","distributer_master_status", "modified_date","certificate_number","date_of_passing_test","cpe_certificate_number","date_of_cpe_from","date_of_cpe_to","application_reference_no","registration_type","category_of_corporation","validity_from", "validity_to")VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING id`, [data['pan_no'], data['mobile_no'], data['email_id'], data['application_type'], 'Pending', 'now()', certificate_number, date_of_passing_test, cpe_certificate_number, date_of_cpe_from, date_of_cpe_to, application_reference_no, 'ONLINE', data['category_of_corporation'], validity_from, validity_to])

    if (res['rowCount'] > 0) {
        let req_type = '';
        if (data['application_type'] == 'ARN') {
            req_type = 'ARN_REG'
            await pool.query(`INSERT INTO amfi_corporate_master_pending( "pan_no","corporate_master_status", "modified_date","distributer_master_id")VALUES($1,$2,$3,$4)`, [data['pan_no'], 'Pending', 'now()', res['rows'][0]['id']]
            )
        }
        else {
            req_type = 'EUIN_REG'

        }

        let reqData = {
            "pan_no": data['pan_no'],
            "application_reference_no": application_reference_no,
            "req_type": req_type,
            "appl_uploads": '',
            "req_status": 'Pending',
            "source": 'ONLINE',
            "user_id": null
        }
        await insertRegRenHistory(reqData)
        return res['rows'][0]['id'];


    }
    return null;
}


updatePersonalDetails = async (data) => {
    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET "first_name"=$1, "last_name" = $2,"date_of_birth" = $3,"gender" = $4,"address1"=$5,"address2"=$6,"address3"=$7,"city"=$8,"pincode"=$9,"state"= $10,"gstn"=$11,"modified_date"=$13,"gst_filepath"=$14 where "id"=$12`, [data['first_name'], data['last_name'], data['date_of_birth'], data['gender'], data['address1'], data['address2'], data['address3'], data['city'], data['pincode'], data['state'], data['gstn'], data['id'], 'now()', data['gst_filepath']])
    if (res['rowCount'] > 0) {
        return data['id'];
    }
    return null;
}

updateCertificationDetails = async (data) => {
    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET  "certificate_number"=$1,"date_of_passing_test"=$2,"cpe_certificate_number"=$3,
"date_of_cpe_from"=$4,"date_of_cpe_to"=$5,"qualification"=$6,"university"=$7,
"year_of_passing"=$8,"modified_date"=$10 where "id"=$9`, [data['certificate_number'], data['date_of_passing_test'], data['cpe_certificate_number'], data['date_of_cpe_from'], data['date_of_cpe_to'], data['qualification'], data['university'], data['year_of_passing'], data['id'], 'now()'])

    if (res['rowCount'] > 0) {
        return data['id'];
    }
    return null;
}

updateBankDetails = async (data) => {
    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
"account_Number"=$1,"bank_proof_filepath"=$2,"ifsc"=$3,"name_of_bank"=$4,
"branch"=$5,"bank_city"=$6, "account_type"=$7,"modified_date"=$9 where "id"=$8`, [data['account_Number'], data['bank_proof_filepath'], data['ifsc'], data['name_of_bank'], data['branch'], data['bank_city'], data['account_type'], data['id'], 'now()'])

    if (res['rowCount'] > 0) {
        return data['id'];
    }
    return null;
}

updateDocuments = async (data) => {
    let buff = await helper.base64ToThumbnail(data['photo_filepath']);

    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET "pancard_filepath"=$1,"adharcard_filepath"=$2,"photo_filepath"=$3,"signature_filepath"=$4,"modified_date"=$6,"photo_thumbnail"=$7 where "id"=$5`, [data['pancard_filepath'], data['adharcard_filepath'], data['photo_filepath'], data['signature_filepath'], data['id'], 'now()', buff])

    if (res['rowCount'] > 0) {
        return data['id'];
    }
    return null;
},

    sendOtp = async (data) => {
        // let sixdigitOtp = Math.floor(100000 + Math.random() * 900000);
        let otpmobile = '123456'; //common.random number generator 6 digit
        let otpemail = '123456';
        let msg = "Hi AMFI ur otp " + otpmobile;
        let subject = "Register";
        let no_of_attempts = 0;
        await message_sender.sendMessage(msg, data.mobile_no);
        await email_sender.sendEmail(subject, msg, data.email_id);

        let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [data.pan_no])
        if (res['rowCount'] > 0) {
            await pool.query(`update amfi_mobile_email_otp set "mobile_otp"=$1,"mobile_no"=$2,"lastmobile_otp_senttime"=$3,"modified_date"=$5,"email_otp"=$6,"no_of_attempts"=$7,"email_id"=$8 where "pan_no"=$4`, [otpmobile, data.mobile_no, 'now()', data.pan_no, 'now()', otpemail, no_of_attempts, data.email_id])
        }
        else {
            await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, [data.mobile_no, data.email_id, otpmobile, otpemail, 'now()', 'now()', no_of_attempts, true, '', '', 'now()', data.pan_no])
        }

        //save to database
        //otp , email 
    }

panExistsInPending = async (panNo) => {
    let res = await pool.query(`select "pan_no","registration_type" from amfi_distributer_master_pending where "pan_no"=$1 `, [panNo])
    if (res['rowCount'] > 0) {

        if (res['rows'][0]['registration_type'] == 'OFFLINE') {
            let pen_res = await pool.query(`select "pan_no" from amfi_distributer_master_pending where "pan_no"=$1 and current_action_code!=$2`, [panNo, 'PENDING'])
            if (pen_res['rowCount'] > 0) {
                return true;
            }
            return false;
        }
        else {
            let pen_res = await pool.query(`select "pan_no" from amfi_distributer_master_pending where "pan_no"=$1`, [panNo])

            if (pen_res['rowCount'] > 0) {
                return true;
            }
            return false;
        }

    }
    return false;
}
panExistsInActivated = async (panNo) => {
    let res = await pool.query(`select "pan_no" from amfi_distributer_master_approved where "pan_no"=$1`, [panNo])
    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

arnExistsInActivated = async (arn_number) => {
    let res = await pool.query(`select "arn_number" from amfi_distributer_master_approved where "arn_number"=$1`, [arn_number])
    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

euinExistsInActivated = async (euin_number) => {
    let res = await pool.query(`select "euin_number" from amfi_distributer_master_approved where "euin_number"=$1`, [euin_number])
    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

emailExistsInPending = async (emailId) => {
    let res = await pool.query(`select "email_id" from amfi_distributer_master_pending where "email_id"=$1`, [emailId])
    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

emailExistsInActivated = async (emailId) => {
    let res = await pool.query(`select "email_id" from amfi_distributer_master_approved where "email_id"=$1`, [emailId])
    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

mobileNoExistsInPending = async (mobileNo) => {
    let res = await pool.query(`select "mobile_no" from amfi_distributer_master_pending where "mobile_no"=$1`, [mobileNo])
    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

mobileNoExistsInActivated = async (mobileNo) => {
    let res = await pool.query(`select "mobile_no" from amfi_distributer_master_approved where "mobile_no"=$1`, [mobileNo])
    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

verifyMobileNoOtp = async (data) => {
    let res = await pool.query(`select "id" from amfi_mobile_email_otp where "mobile_no"=$1 and "mobile_otp"=$2`, [data.mobile_no, data.mobile_otp])

    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

verifyEmailOtp = async (data) => {
    let res = await pool.query(`select "id" from amfi_mobile_email_otp where "email_id"=$1 and "email_otp"=$2`, [data.email_id, data.email_otp])

    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

getDetailsByPincode = async (data) => {
    let res = await pool.query(`select "pincode","city","state","country","statename" from amfi_pincode_master where pincode like '%${data.pincode}%' 
    `)

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

getBankDetailsByIFSCcode = async (data) => {
    let res = await pool.query(`select "bank_name","ifsc","micr","branch","address","contact","bank_city","district" from amfi_rbi_master where "ifsc" like '%${data.search_key}%'  order by "id"
    `)

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

pan4thcharacter = async (panno) => {
    let pan4thchar = panno.charAt('3')
    let res = await pool.query(`select "id" from tbl_amfi_category_master where "pan_4th_character"=$1 and "status"=$2`, [pan4thchar, true])
    if (res['rowCount'] > 0) {
        return false;
    }
    return true;
}
getPersonalDetailsById = async (data) => {
    let res = await pool.query(`select "id","first_name","last_name",to_char("date_of_birth",'YYYY-MM-DD') AS  date_of_birth  ,"pan_no", "gender", "address1", "address2", "address3","city","pincode","state",
    "gstn","gst_filepath","country" from amfi_distributer_master_pending where id=$1`, [data.id])

    if (res['rowCount'] > 0) {
        res['rows'][0]['gender_name'] = '';
        let select_gender = await pool.query(`select req_desc  from tbl_dropdown_master where status =true and req_type ='GENDER' and req_code =$1`, [res['rows'][0]['gender']])
        if (select_gender['rowCount'] > 0) {
            res['rows'][0]['gender_name'] = select_gender['rows'][0]['req_desc']
        }

        let gst_id = res['rows'][0]['gst_filepath'];
        var num1 = parseInt(gst_id) || 0;
        if (num1 > 0) {
            let gst_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [gst_id])
            if (gst_res['rowCount'] > 0) {
                res['rows'][0]['gst_filepath_image_type'] = gst_res['rows'][0]['image_type'];
                res['rows'][0]['gst_filename'] = gst_res['rows'][0]['file_name'];
            }
        }
        return res['rows'];
    }
    return null;
}

getCertificationDetailsById = async (data) => {
    let res = await pool.query(`select  "id","certificate_number",to_char("date_of_passing_test",'YYYY-MM-DD') as date_of_passing_test,"cpe_certificate_number",to_char("date_of_cpe_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("date_of_cpe_to",'YYYY-MM-DD') as date_of_cpe_to,"qualification","university","year_of_passing" from amfi_distributer_master_pending where id=$1`, [data.id])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getBankDetailsById = async (data) => {
    let res = await pool.query(`select  "id","account_Number","bank_proof_filepath","ifsc","name_of_bank","branch","bank_city","account_type" from amfi_distributer_master_pending where id=$1`, [data.id])

    if (res['rowCount'] > 0) {
        let bankproof_id = res['rows'][0]['bank_proof_filepath'];
        var num1 = parseInt(bankproof_id) || 0;
        if (num1 > 0) {
            let bankproof_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [bankproof_id])
            if (bankproof_res['rowCount'] > 0) {
                res['rows'][0]['bank_proof_file_image_type'] = bankproof_res['rows'][0]['image_type'];
                res['rows'][0]['bank_proof_filename'] = bankproof_res['rows'][0]['file_name']

            }
        }
        return res['rows'];
    }
    return null;
}
resendMobileOtp = async (data) => {
    let res = await pool.query(`select "mobile_otp" from amfi_mobile_email_otp where "mobile_no"=$1 order by id desc`, [data.mobile_no])

    if (res['rowCount'] > 0) {
        let otpmobile = res['rows'][0]['mobile_otp'];
        let msg = "Hi AMFI ur otp " + otpmobile;
        let subject = "Register";
        await message_sender.sendMessage(msg, data.mobile_no);
        return "success";
    }
    return null;
}

resendEmailOtp = async (data) => {
    let res = await pool.query(`select "email_otp",pan_no from amfi_mobile_email_otp where "email_id"=$1 order by id desc `, [data.email_id])

    if (res['rowCount'] > 0) {
        let otpemail = res['rows'][0]['email_otp'];
        let pan_no = res['rows'][0]['pan_no'];
        emailService.resendOnlineARNRegOTpEmail(pan_no, data.email_id, otpemail);
        return "success";
    }
    return null;
}

updateRegistrationType = async (data) => {
    if (data['registration_type'] == 'OFFLINE') {
        data['registration_type'] = 'DOCUMENT';
    }
    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
    "kyd_source"=$1,"modified_date"=$3 where "id"=$2`, [data['registration_type'].toUpperCase(), data['id'], 'now()'])

    if (res['rowCount'] > 0) {
        return data['id'];
    }
    return null;
}

panExistsInNism = async (panNo) => {
    let res = await pool.query(`select "pan_no" from tbl_user_nism_details where "pan_no"=$1 and "status"=true `, [panNo])
    if (res['rowCount'] > 0) {
        return false;
    }
    return true;
}

panExpireInNism = async (panNo) => {
    let current_date = moment().format('YYYY-MM-DD')
    let res = await pool.query(`select "pan_no","nism_certificate_date"  from tbl_user_nism_details where "pan_no"=$1 and "validity_to">=$2 and "status"=true order by "id" desc limit 1`, [panNo, current_date])
    if (res['rowCount'] > 0) {
        return false;
    }
    return true;
}

checkNismCertificateDate = async (panNo) => {
    let current_date = moment().format('YYYY-MM-DD')
    let res = await pool.query(`select "pan_no","nism_certificate_date" from tbl_user_nism_details where "pan_no"=$1 and "nism_certificate_date">$2  and "status"=true order by "id" desc limit 1`, [panNo, current_date])
    if (res['rowCount'] > 0) {
        return false;
    }
    return true;
}

updateCompanyDetails = async (data) => {
    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
    "arn_id"=$1, "name_of_organisation"=$2,"date_of_appointment"=$3,"designation"=$4,"description_of_responsibilities"=$5,"company_address1"=$6,"company_address2"=$7,"company_address3"=$8,"company_pincode"=$9,"company_city"=$10,"company_state"=$11,"modified_date"=$12 where "id"=$13`, [data['arn_id'], data['name_of_organisation'], data['date_of_appointment'], data['designation'], data['description_of_responsibilities'], data['company_address1'], data['company_address2'], data['company_address3'], data['company_pincode'], data['company_city'], data['company_state'], 'now()', data['id']])

    if (res['rowCount'] > 0) {
        return data['id'];
    }
    return null;
}

getCompanyDetailsById = async (data) => {
    let res = await pool.query(`select  "id","arn_id","name_of_organisation",to_char("date_of_appointment",'YYYY-MM-DD') as date_of_appointment,"designation","description_of_responsibilities","company_address1","company_address2","company_address3","company_pincode","company_city","company_state","company_country" from amfi_distributer_master_pending where id=$1`, [data.id])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getDetailsByARNId = async (data) => {
    let res = await pool.query(`select "id","arn_number",first_name, middle_name, last_name,"pan_no","mobile_no","email_id" from amfi_distributer_master_approved where "arn_number" like '%${data.arn_number}%'`)

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

registrationActivate = async (data) => {
    let pending_res_data = await pool.query(`select *  from amfi_distributer_master_pending where "id"=$1`, [data.id])
    if (pending_res_data['rowCount'] > 0) {
        let pendingres = pending_res_data['rows'][0]
        let arn_no = 0;
        let euin_no = 0;
        let arn_number = '';
        let euin_number = ''
        let coporate_res = null;
        let date_of_passing_test = null
        let certificate_number = ''
        let validity_from = null;
        let validity_to = null;

        if (pendingres['application_type'] == 'ARN') {
            let pending_coporate_res = await pool.query(`select * from amfi_corporate_master_pending where "distributer_master_id" =$1`, [data.id])
            if (pending_coporate_res['rowCount'] > 0) {
                coporate_res = pending_coporate_res['rows'][0]
            }
        }
        if (pendingres['renewal_type'] == 'RENEWAL') {
            arn_number = pendingres['arn_number']
            euin_number = pendingres['euin_number']

            let app_res = await pool.query(`select "id" from amfi_distributer_master_approved where "pan_no"=$1`, [pendingres['pan_no']])
            if (app_res['rowCount'] > 0) {
                await pool.query(`delete from amfi_corporate_master_approved where "distributer_master_id"=$1`, [app_res['rows'][0]['id']]);
                await pool.query(`delete from amfi_distributer_master_approved where "pan_no"=$1`, [pendingres['pan_no']]);
            }

        }
        else {

            let select_counter = await pool.query(`select * from amfi_counter`)
            if (select_counter['rowCount'] > 0) {
                if (pendingres['application_type'] == 'ARN') {
                    arn_no = select_counter['rows'][0]['arncount'] + 1
                    arn_number = 'ARN' + '-' + arn_no
                }
                else if (pendingres['application_type'] == 'EUIN') {
                    arn_no = select_counter['rows'][0]['arncount']
                }
                euin_no = select_counter['rows'][0]['euincount'] + 1
                euin_number = 'EUIN' + '-' + euin_no;
                await pool.query(`update amfi_counter set "arncount"='${arn_no}',"euincount"='${euin_no}'`)

            }
        }

        let category_res = await pool.query(`select "exam_code" from tbl_amfi_category_master where "category_code"=$1`, [pendingres['category_of_corporation']])

        if (category_res['rowCount'] > 0) {
            let nism_res = await pool.query(`select  to_char("nism_certificate_date",'YYYY-MM-DD') as date_of_passing_test,"nism_certificate_no" as certificate_number,to_char("validity_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("validity_to",'YYYY-MM-DD') AS date_of_cpe_to  from tbl_user_nism_details  where "nism_category"=$1 and "pan_no"=$2 order by "created_date" desc`, [category_res['rows'][0]['exam_code'], data['pan_no']])


            if (nism_res['rowCount'] > 0) {
                // date_of_passing_test = nism_res['rows'][0]['date_of_passing_test']
                // certificate_number = nism_res['rows'][0]['certificate_number']
                // validity_from = nism_res['rows'][0]['date_of_cpe_from']
                // validity_to = nism_res['rows'][0]['date_of_cpe_to']
            }
        }
        // if (pendingres['renewal_type'] == 'RENEWAL') {
        //     let current_date = moment().format('YYYY-MM-DD');
        //     validity_from = current_date;
        //     // validity_to = moment(current_date, 'YYYY-MM-DD').add(3, 'years');
        // }
        let insert_approved = `INSERT INTO amfi_distributer_master_approved( first_name, middle_name, last_name, gender, date_of_birth, pan_no, gstn, "whether_kyd_Compliant", certificate_number, date_of_passing_test, address1, address2, address3, city, pincode, state, country, telephone_number, fax, mobile_no, email_id, qualification, university, year_of_passing, name_of_bank, branch, bank_city, "account_Number", ifsc, account_type, micr, dd_cheque_number, dd_cheque_date, amount, drawn_on_bank_branch, signature, place, sign_date, undertaking_consent, kyd_source, cpe_certificate_number, date_of_cpe_from, distributor_category, arn_id, name_of_organisation, utr_no, type_of_distributor, distributer_master_status, created_by, modified_by, modified_date, application_type, date_of_cpe_to, bank_proof_filepath, pancard_filepath, adharcard_filepath, photo_filepath, signature_filepath, registration_type, date_of_appointment, designation, description_of_responsibilities, company_address1, company_address2, company_address3, company_pincode, company_city, company_state, arn_number, euin_number, gst_filepath, application_reference_no, document_checklist, address_proof_filepath, nism_certificate_filepath, kyd_acknowledge_filepath, priority, current_action, fo1_verified, fo2_verified, gst_verified, gst_verified_by, renewal_type,photo_thumbnail,category_of_corporation,validity_from, validity_to,single_merged_doc)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42,$43,$44,$45,$46,$47,$48,$49,$50,$51,$52,$53,$54,$55,$56,$57,$58,$59,$60,$61,$62,$63,$64,$65,$66,$67,$68,$69,$70,$71,$72,$73,$74,$75,$76,$77,$78,$79,$80,$81,$82,$83,$84,$85,$86,$87,$88) returning "id","arn_number","euin_number"`

        let dis_ins = await pool.query(insert_approved, [pendingres['first_name'], pendingres['middle_name'], pendingres['last_name'], pendingres['gender'], pendingres['date_of_birth'], pendingres['pan_no'], pendingres['gstn'], pendingres['whether_kyd_Compliant'], pendingres['certificate_number'], pendingres['date_of_passing_test'], pendingres['address1'], pendingres['address2'], pendingres['address3'], pendingres['city'], pendingres['pincode'], pendingres['state'], pendingres['country'], pendingres['telephone_number'], pendingres['fax'], pendingres['mobile_no'], pendingres['email_id'], pendingres['qualification'], pendingres['university'], pendingres['year_of_passing'], pendingres['name_of_bank'], pendingres['branch'], pendingres['bank_city'], pendingres['account_Number'], pendingres['ifsc'], pendingres['account_type'], pendingres['micr'], pendingres['dd_cheque_number'], pendingres['dd_cheque_date'], pendingres['amount'], pendingres['drawn_on_bank_branch'], pendingres['signature'], pendingres['place'], pendingres['sign_date'], pendingres['undertaking_consent'], pendingres['kyd_source'], pendingres['cpe_certificate_number'], pendingres['date_of_cpe_from'], pendingres['distributor_category'], pendingres['arn_id'], pendingres['name_of_organisation'], pendingres['utr_no'], pendingres['type_of_distributor'], 'Active', data.user_id, data.user_id, 'now()', pendingres['application_type'], pendingres['date_of_cpe_to'], pendingres['bank_proof_filepath'], pendingres['pancard_filepath'], pendingres['adharcard_filepath'], pendingres['photo_filepath'], pendingres['signature_filepath'], pendingres['registration_type'], pendingres['date_of_appointment'], pendingres['designation'], pendingres['description_of_responsibilities'], pendingres['company_address1'], pendingres['company_address2'], pendingres['company_address3'], pendingres['company_pincode'], pendingres['company_city'], pendingres['company_state'], arn_number, euin_number, pendingres['gst_filepath'], pendingres['application_reference_no'], pendingres['document_checklist'], pendingres['address_proof_filepath'], pendingres['nism_certificate_filepath'], pendingres['kyd_acknowledge_filepath'], pendingres['priority'], pendingres['current_action'], pendingres['fo1_verified'], pendingres['fo2_verified'], pendingres['gst_verified'], pendingres['gst_verified_by'], pendingres['renewal_type'], pendingres['photo_thumbnail'], pendingres['category_of_corporation'], pendingres['validity_from'], pendingres['validity_to'], pendingres['single_merged_doc']])


        if (dis_ins['rowCount'] > 0) {

            if (coporate_res != null) {
                let insert_cop_approved = await pool.query(`INSERT INTO amfi_corporate_master_approved("pan_no", engaged_as_insurance_agent, registered_insurance_company, "whether_group_company_has_arn", name_of_group_company, "arn_of_group_company", no_of_proposed_branches_for_sales, "no_of_proposed_employees_for_sales",no_of_certified_employees, no_of_employess_under_coporate, name_of_signatory, designation_of_signatory, "mobile_no_of_signatory", structure_of_corporate, countries_proposed_for_distribution, list_of_activities_other_than_mf_distribution, group_company_has_arn, "name_of_prop_firm", corporate_master_status, created_by, modified_by, modified_date, distributer_master_id,new_cadre_category)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`, [pendingres['pan_no'], coporate_res['engaged_as_insurance_agent'], coporate_res['registered_insurance_company'], coporate_res['whether_group_company_has_arn'], coporate_res['name_of_group_company'], coporate_res['ARN_of_group_company'], coporate_res['no_of_proposed_branches_for_sales'], coporate_res['no_of_proposed_employees_for_sales'], coporate_res['no_of_certified_employees'], coporate_res['no_of_employess_under_coporate'], coporate_res['name_of_signatory'], coporate_res['designation_of_signatory'], coporate_res['mobile_no_of_signatory'], coporate_res['structure_of_corporate'], coporate_res['countries_proposed_for_distribution'], coporate_res['list_of_activities_other_than_mf_distribution'], coporate_res['group_company_has_arn'], coporate_res['name_of_prop_firm'], 'Active', null, null, 'now()', dis_ins['rows'][0]['id'], coporate_res['rows'][0]['new_cadre_category']])
            }

            if (pendingres['renewal_type'] == 'REGISTRATION') {
                let password = '12345678'
                let user_profile = pendingres['application_type']
                // let str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$';
                // for (let i = 1; i <= 8; i++) {
                //     var char = Math.floor(Math.random() * str.length + 1);
                //     password += str.charAt(char)
                // }
                let user_name = ''
                if (user_profile == 'ARN') {
                    user_name = arn_number;
                }
                else if (user_profile == 'EUIN') {
                    user_name = euin_number;
                }

                let insert_user = await pool.query(`INSERT INTO amfi_user_login ( user_name, "password", last_login_datetime, active, user_profile, first_login, status, modified_date,"pan_no")VALUES($1,$2,$3, $4,$5,$6, $7, $8,$9) RETURNING "user_id"`, [user_name, password, 'now()', true, user_profile, true, true, 'now()', pendingres['pan_no']]
                )

                if (insert_user['rowCount'] > 0) {
                    await pool.query(`update amfi_distributer_master_approved set "user_id"=$1 where "id"=$2`, [insert_user['rows'][0]['user_id'], dis_ins['rows'][0]['id']])
                }
            }
            else {
                let login_res = await pool.query(`select "user_id" from amfi_user_login where "user_name"=$1`, [pendingres['pan_no']])
                if (login_res['rowCount'] > 0) {
                    await pool.query(`update amfi_distributer_master_approved set "user_id"=$1 where "id"=$2`, [login_res['rows'][0]['user_id'], dis_ins['rows'][0]['id']])
                }
            }
            await pool.query(`delete from amfi_corporate_master_pending where "distributer_master_id"=$1`, [data.id]);
            await pool.query(`delete from amfi_distributer_master_pending where "id"=$1`, [data.id]);
            await offlineService.saveApproveToApprovehistory(pendingres['pan_no'], pendingres['application_reference_no'])

            let reqData = {
                "pan_no": pendingres['pan_no'],
                "application_reference_no": pendingres['application_reference_no'],
                "req_status": "Active",
            }
            await registrationService.updateRegRenHistory(reqData);

            await pool.query(`INSERT INTO tbl_chng_req_hist(
                pan_no, req_type, appl_date, appl_uploads, req_status, key_value_edited, key_value_old, key_value_new, modified_date, application_reference_no,created_by,modified_by,source,"req_status_code",is_amount_paid) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) returning "id","application_reference_no"`, [pendingres['pan_no'], 'DUP', 'now()', '', 'Completed', '', '', '', 'now()', pendingres['application_reference_no'], null, null, 'ONLINE', 'COMPLETED', true])
            return dis_ins['rows'][0];
        }

        return null;
    }
}
getDocumentsById = async (data) => {
    let resObj = {}
    let res = await pool.query(`select "id","pancard_filepath","adharcard_filepath","photo_filepath","signature_filepath" from amfi_distributer_master_pending where id=$1`, [data.id])

    if (res['rowCount'] > 0) {
        resObj = res['rows'][0];
        resObj['adharcard_filepath_base64'] = '';
        resObj['pancard_filepath_base64'] = '';
        resObj['photo_filepath_base64'] = '';
        resObj['signature_filepath_base64'] = ''
        let pan_id = res['rows'][0]['pancard_filepath'];
        let adhar_id = res['rows'][0]['adharcard_filepath'];
        let photo_id = res['rows'][0]['photo_filepath'];
        let sign_id = res['rows'][0]['signature_filepath'];

        var num1 = parseInt(pan_id) || 0;
        if (num1 > 0) {
            let pan_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [num1])

            if (pan_res['rowCount'] > 0) {
                let imgBuff = pan_res['rows'][0]['image'];
                resObj['pancard_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                resObj['pancard_filepath_image_type'] = pan_res['rows'][0]['image_type'];
                resObj['pancard_filename'] = pan_res['rows'][0]['file_name'];

                //                resObj['pancard_filepath_base64'] = pan_res['rows'][0]['image'];

            }
        }
        var num2 = parseInt(adhar_id) || 0;
        if (num2 > 0) {

            let aadhar_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [num2])
            if (aadhar_res['rowCount'] > 0) {
                let imgBuff = aadhar_res['rows'][0]['image'];
                resObj['adharcard_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                resObj['adharcard_filepath_image_type'] = aadhar_res['rows'][0]['image_type'];
                resObj['adharcard_filename'] = aadhar_res['rows'][0]['file_name'];

                //                resObj['adharcard_filepath_base64'] = aadhar_res['rows'][0]['image']
            }
        }
        var num3 = parseInt(photo_id) || 0;
        if (num3 > 0) {
            let photo_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [num3])
            if (photo_res['rowCount'] > 0) {
                let imgBuff = photo_res['rows'][0]['image'];
                resObj['photo_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                resObj['photo_filepath_image_type'] = photo_res['rows'][0]['image_type'];
                resObj['photo_filename'] = photo_res['rows'][0]['file_name'];

                //                resObj['photo_filepath_base64'] = photo_res['rows'][0]['image']

            }
        }

        var num4 = parseInt(sign_id) || 0;
        if (num4 > 0) {
            let sign_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [num4])
            if (sign_res['rowCount'] > 0) {
                let imgBuff = sign_res['rows'][0]['image'];
                resObj['signature_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                resObj['signature_filepath_image_type'] = sign_res['rows'][0]['image_type'];
                resObj['signature_filename'] = sign_res['rows'][0]['file_name'];

                //                resObj['signature_filepath_base64'] = sign_res['rows'][0]['image']

            }
        }
        return resObj;
    }

    return null;
}
loginARNEUIN = async (data) => {

    let res = await pool.query(`select "user_id","user_name","first_login",user_profile,"pan_no","user_role" from amfi_user_login where "user_name"=$1 and "password"=$2`, [data.user_name, data.password])

    if (res['rowCount'] > 0) {

        if (res['rows'][0]['user_profile'] == 'ARN' || res['rows'][0]['user_profile'] == 'EUIN') {
            await pool.query(`update amfi_distributer_master_approved set "user_id"=$1 where "pan_no"=$2`, [res['rows'][0]['user_id'], res['rows'][0]['pan_no']])
            let activeres = await pool.query(`select "pan_no","mobile_no","email_id","photo_filepath","first_name","middle_name","last_name","arn_number","euin_number"  from amfi_distributer_master_approved where user_id =$1 
        `, [res['rows'][0]['user_id']])

            if (res['rowCount'] > 0) {
                res['rows'][0]['pan_no'] = activeres['rows'][0]['pan_no']
                res['rows'][0]['mobile_no'] = activeres['rows'][0]['mobile_no']
                res['rows'][0]['email_id'] = activeres['rows'][0]['email_id']
                res['rows'][0]['photo_filepath'] = activeres['rows'][0]['photo_filepath']
                res['rows'][0]['first_name'] = activeres['rows'][0]['first_name']
                res['rows'][0]['middle_name'] = activeres['rows'][0]['middle_name']
                res['rows'][0]['arn_number'] = activeres['rows'][0]['arn_number']
                res['rows'][0]['last_name'] = activeres['rows'][0]['last_name']
                res['rows'][0]['euin_number'] = activeres['rows'][0]['euin_number']
                var num1 = parseInt(activeres['rows'][0]['photo_filepath']) || 0;
                if (num1 > 0) {
                    let photo_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [num1])

                    if (photo_res['rowCount'] > 0) {
                        let imgBuff = photo_res['rows'][0]['image'];

                        res['rows'][0]['photo_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                        res['rows'][0]['photo_filepath_image_type'] = photo_res['rows'][0]['image_type'];
                        res['rows'][0]['photo_filename'] = photo_res['rows'][0]['file_name'];
                        //                    res['rows'][0]['photo_filepath_base64'] = photo_res['rows'][0]['image'];
                    }
                }

            }
        }

        if ('systemCode' in data) {
            await pool.query(`delete from amfi_user_session where "user_id"=$1 and "user_name"=$2`, [res['rows'][0]['user_id'], data.user_name])
            await pool.query(`INSERT INTO amfi_user_session
            ( user_id, user_name, uuid)
            VALUES( $1,$2,$3)`, [res['rows'][0]['user_id'], data.user_name, data.systemCode])
        }
        await pool.query(`update amfi_user_login set "last_login_datetime"=$1 where "user_id"=$2`, ['now()', res['rows'][0]['user_id']])
        return res['rows'][0];
    }
    return null;
}

getdataByPanNo = async (data) => {
    let res = await pool.query(`select "id","mobile_no","email_id","created_date","application_type","pan_no","kyd_source","ekyc_verified" from amfi_distributer_master_pending where "pan_no"=$1`, [data.pan_no])

    if (res['rowCount'] > 0) {
        let resObj = {}
        resObj['dis_res'] = res['rows'];
        resObj['cop_res'] = []
        if (res['rows'][0]['application_type'] == 'ARN') {
            let cop_res = await pool.query(`select B."reg_req_resume_days"  from amfi_distributer_master_pending A,tbl_amfi_category_master B where A."id"=$1 and A."category_of_corporation"=B."category_code"`, [res['rows'][0]["id"]])

            if (cop_res['rowCount'] > 0) {
                resObj['cop_res'] = cop_res['rows']
            }
        }

        return resObj;
    }
    return null;
}

deleteAfterResumeDays = async (id) => {
    await pool.query(`delete from amfi_corporate_master_pending where "distributer_master_id"=$1`, [id]);
    await pool.query(`delete from amfi_distributer_master_pending where "id"=$1`, [id]);
}

getAccountTypeById = async (data) => {
    let res = await pool.query(`select B."allowed_bank_type" from amfi_distributer_master_pending A,tbl_amfi_category_master B where A."id"= $1 and B."category_code"=A."category_of_corporation"`, [data.id])

    if (res['rowCount'] > 0) {
        let account_type = res['rows'][0]['allowed_bank_type'].split(',')
        return { "account_type": account_type }

    }
    return null;
}

getPaymentAmountById = async (data) => {
    let res = await pool.query(`select B."pay_amount" from amfi_distributer_master_pending A,tbl_amfi_category_master B where A."id"= $1 and B."category_code"=A."category_of_corporation"`, [data.id])

    if (res['rowCount'] > 0) {
        return res['rows']
    }
    return null;
}

getDeclarationById = async (data) => {
    let res = await pool.query(`select B."declaration" from amfi_distributer_master_pending A,tbl_amfi_category_master B where A."id"= $1 and B."category_code"=A."category_of_corporation"`, [data.id])

    if (res['rowCount'] > 0) {
        return res['rows']
    }
    return null;
}

getFilebase64ByID = async (data) => {
    let res = await pool.query(`select "image_type","file_name","image" from amfi_file where "id"=$1 
`, [data.id])
    if (res['rowCount'] > 0) {
        let resObj = {}
        let imgBuff = res['rows'][0]['image'];
        resObj['file_type'] = res['rows'][0]['image_type']
        resObj['file_name'] = res['rows'][0]['file_name']
        resObj['filebase64'] = imgBuff == null ? null : imgBuff.toString('base64');

        return resObj;
    }
    return null;
}

getDropDownData = async (data) => {
    let res = await pool.query(`select "id","req_type","req_code","req_desc"  from tbl_dropdown_master where "status"=true and "req_type"=$1`, [data.request_type])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

verifyOtp = async (data) => {
    let res = await pool.query(`select "id" from amfi_mobile_email_otp where "email_id"=$1 and "email_otp"=$2 and "mobile_no"=$3 and "mobile_otp"=$4 and "pan_no"=$5`, [data.email_id, data.email_otp, data.mobile_no, data.mobile_otp, data.pan_no])

    if (res['rowCount'] > 0) {
        return true;
    }
    else {
        let count_res = await pool.query(`select "no_of_attempts" from amfi_mobile_email_otp where "pan_no"=$1`, [data.pan_no])
        if (count_res['rowCount'] > 0) {
            let count = count_res['rows'][0]['no_of_attempts'] + 1;
            await pool.query(`update amfi_mobile_email_otp set "no_of_attempts"=$2,"modified_date"=$3 where "pan_no"=$1`, [data.pan_no, count, 'now()'])
        }

        return false;

    }
}

getNoOfAttemptCount = async (data) => {
    let res = await pool.query(`select "no_of_attempts" from amfi_mobile_email_otp where "pan_no"=$1`, [data.pan_no])
    if (res['rowCount'] > 0) {
        let count = res['rows'][0]['no_of_attempts'];
        return count;
    }
    return null;
}

forgotUserId = async (data) => {
    let res = await pool.query(`select "user_name","user_id" from amfi_user_login where "pan_no"=$1 and "status"=true`, [data.pan_no])
    if (res['rowCount'] > 0) {
        return res['rows'][0]['user_id']
    }
    return null;
}
sendOtpMobile = async (pan_no, mobile_no, message) => {
    // let sixdigitOtp = Math.floor(100000 + Math.random() * 900000);
    let otpmobile = '123456'; //common.random number generator 6 digit
    let no_of_attempts = 0;
    await message_sender.sendMessage(message, mobile_no);

    let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [pan_no])
    if (res['rowCount'] > 0) {
        await pool.query(`update amfi_mobile_email_otp set "mobile_otp"=$1,"mobile_no"=$2,"lastmobile_otp_senttime"=$3,"modified_date"=$5,"no_of_attempts"=$6 where "pan_no"=$4`, [otpmobile, mobile_no, 'now()', pan_no, 'now()', no_of_attempts])
    }
    else {
        await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, [mobile_no, '', otpmobile, '', 'now()', 'now()', no_of_attempts, true, '', '', 'now()', pan_no])
    }
}

sendOtpEmail = async (pan_no, email_id, subject, mail_body) => {
    // let sixdigitOtp = Math.floor(100000 + Math.random() * 900000);
    let otpemail = '123456'; //common.random number generator 6 digit
    let no_of_attempts = 0;
    await email_sender.sendEmail(subject, mail_body, email_id);

    let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [pan_no])
    if (res['rowCount'] > 0) {
        await pool.query(`update amfi_mobile_email_otp set "email_otp"=$1,"email_id"=$2,"lastmobile_otp_senttime"=$3,"modified_date"=$5,"no_of_attempts"=$6 where "pan_no"=$4`, [otpemail, email_id, 'now()', pan_no, 'now()', no_of_attempts])
    }
    else {
        await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, ['', otpemail, '', email_id, 'now()', 'now()', no_of_attempts, true, '', '', 'now()', pan_no])
    }
}


forgotPasswordSendOtp = async (data) => {
    let select_panno = await pool.query(`select "pan_no"  from amfi_user_login where user_name  =$1 and status =true`, [data.user_id])
    if (select_panno['rowCount'] > 0) {
        let pan_no = select_panno['rows'][0]['pan_no'];
        let select_data = await pool.query(`select "mobile_no" ,"email_id"  from amfi_distributer_master_approved where pan_no =$1`, [pan_no])
        if (select_data['rowCount'] > 0) {
            let mobile_no = select_data['rows'][0]['mobile_no'];
            let email_id = select_data['rows'][0]['email_id'];
            if (data.verifywithMobile == true) {
                let message = "Hi"
                await sendOtpMobile(pan_no, mobile_no, message)
            }
            if (data.verifywithEmail == true) {
                let subject = "forgot Password";
                let mail_body = "hi";
                await sendOtpEmail(pan_no, email_id, subject, mail_body)
            }
        }
        return pan_no;
    }
    return null;
}

forgotPasswordVerifyOtp = async (data) => {
    let select_data = await pool.query(`select "mobile_no" ,"email_id"  from amfi_distributer_master_approved where pan_no =$1`, [data.pan_no])
    if (select_data['rowCount'] > 0) {
        let mobileotpverified = true;
        let emailotpverified = true;
        let mobile_no = select_data['rows'][0]['mobile_no'];
        let email_id = select_data['rows'][0]['email_id'];
        if (data.verifywithMobile == true) {
            let res = await pool.query(`select "id" from amfi_mobile_email_otp where "mobile_no"=$1 and "mobile_otp"=$2`, [mobile_no, data.otp])
            if (res['rowCount'] > 0) {
                mobileotpverified = true;
            }
            else {
                mobileotpverified = false;

            }
        }
        if (data.verifywithEmail == true) {
            let res = await pool.query(`select "id" from amfi_mobile_email_otp where "email_id"=$1 and "email_otp"=$2`, [email_id, data.otp])

            if (res['rowCount'] > 0) {
                emailotpverified = true;
            }
            else {
                emailotpverified = true;
            }
        }
        if (mobileotpverified == true && emailotpverified == true) {
            await pool.query(`update amfi_user_login set "password" =$2,"modified_date"=$3 where "pan_no"=$1 and "status"=true`, [data.pan_no, data.new_password, 'now()'])
            return true;
        }
        else {
            return false;
        }
    }
    return false;
}

changePassword = async (data) => {
    let select_data = await pool.query(`select "user_id"  from amfi_user_login where "pan_no"  =$1 and status =true and "password"=$2 and "user_id"=$3`, [data.pan_no, data.old_password, data.user_id])

    if (select_data['rowCount'] > 0) {
        await pool.query(`update amfi_user_login set "password" =$2,"modified_date"=$3 where "pan_no"=$1 and "status"=true`, [data.pan_no, data.new_password, 'now()'])
        return data.user_id;
    }
    return null;
}

updateRegistrationReview = async (data) => {
    let select_data = await pool.query(`select "kyd_source","application_type","application_reference_no",email_id  FROM amfi_distributer_master_pending where "id" =$1 and "pan_no"=$2`, [data.id, data.pan_no])

    let current_action = 'Pending'
    let single_merged_doc = await updateConcatinatedFile(data.pan_no)

    if (select_data['rowCount'] > 0) {

        if (select_data['rows'][0]['application_type'] == 'EUIN') {
            emailService.onlineEUINSubmitEmail(data.pan_no, select_data['rows'][0]['email_id'])
            if (select_data['rows'][0]['kyd_source'] == 'DOCUMENT') {
                current_action = 'Completed';
                await pool.query(`update amfi_distributer_master_pending set "current_action"='Completed',"current_action_code"='COMPLETED',"modified_date"=$3,"single_merged_doc"=$4 where "id"=$1 and "pan_no"=$2 `, [data.id, data.pan_no, 'now()', single_merged_doc])
            }

        }
        else {
            if (select_data['rows'][0]['kyd_source'] == 'DOCUMENT') {
                await pool.query(`update amfi_distributer_master_pending set "current_action_code"='PENDING_AUTHORISE',"modified_date"=$3,"single_merged_doc"=$4 where "id"=$1 and "pan_no"=$2 `, [data.id, data.pan_no, 'now()', single_merged_doc])
            }
            emailService.onlineARNSubmitEmail(data.pan_no, select_data['rows'][0]['email_id'])

        }

        let reqData = {
            "pan_no": data.pan_no,
            "application_reference_no": select_data['rows'][0]['application_reference_no'],
            "req_status": current_action,
            "user_id": null,
            "appl_uploads": single_merged_doc
        }
        await updateRegRenHistory(reqData);

        return select_data['rows'][0]['kyd_source'];
    }
    return null;
}

updatePayment = async (data) => {
    let select_data = await pool.query(`select "kyd_source","id","application_type",registration_type,application_reference_no,"current_action"  FROM amfi_distributer_master_pending where  "pan_no"=$1`, [data.pan_no])

    if (select_data['rowCount'] > 0) {
        data.id = select_data['rows'][0]['id']
        let current_action = select_data['rows'][0]['current_action']
        if (select_data['rows'][0]['application_type'] == 'EUIN' && select_data['rows'][0]['registration_type'] == 'ONLINE') {
            current_action = 'Completed';
            await pool.query(`update amfi_distributer_master_pending set "current_action_code"='COMPLETED',"current_action"='Completed',"is_amount_paid"=true,"modified_date"=$3 where "id"=$1 and "pan_no"=$2`, [data.id, data.pan_no, 'now()'])
            await registrationActivate(data)
        }
        else {
            current_action = 'Authorise';
            await pool.query(`update amfi_distributer_master_pending set "current_action_code"='AUTHORISE',"current_action"='Authorise',"is_amount_paid"=true,"modified_date"=$3 where "id"=$1 and "pan_no"=$2`, [data.id, data.pan_no, 'now()'])
        }

        let reqData = {
            "pan_no": data.pan_no,
            "application_reference_no": select_data['rows'][0]['application_reference_no'],
            "req_status": current_action,
            "user_id": null,
        }
        await updateRegRenHistory(reqData);
        return select_data['rows'][0];

    }
    return null;
}

getUserSession = async (data) => {
    let res = await pool.query(`select * from amfi_user_session where "user_name"=$1`, [data.user_name])
    if (res['rowCount'] > 0) {
        // let currenttime = new Date().getTime();
        // let createdTime = new Date(res['rows'][0]['created_date']).getTime();

        // console.log(currenttime, createdTime, currenttime - createdTime)
        // let diffHr = (((currenttime - createdTime) / 3600) / 1000)

        // console.log("diffHr==========>", diffHr)
        return true;
    }

    return false;
}

updateARNEUINtoken = async (user_id, user_name, pan_no, token) => {
    await pool.query(`update amfi_user_login set "token_key"=$1 where "user_id"=$2 and "user_name"=$3 and "pan_no"=$4`, [token, user_id, user_name, pan_no])
}

logoutARNEUIN = async (data) => {
    let res = await pool.query(`select "user_id","user_name","first_login",user_profile,"pan_no" from amfi_user_login where "user_name"=$1 and "user_id"=$2 and "user_profile" IN ('ARN','EUIN') `, [data.user_name, data.user_id])

    if (res['rowCount'] > 0) {
        await pool.query(`delete from amfi_user_session where "user_id"=$1 and "user_name"=$2`, [data.user_id, data.user_name])

        await pool.query(`update amfi_user_login set "token_key"=$1 where "user_id"=$2 and "user_name"=$3 and "pan_no"=$4`, ['', res['rows'][0]['user_id'], data.user_name, res['rows'][0]['pan_no']])

        return res['rows'][0];
    }
    return null;
}
updateConcatinatedFile = async (pan_no) => {
    try {
        let fileId_arr = []
        let selected_file = await pool.query(`select pancard_filepath  ,adharcard_filepath ,photo_filepath  ,signature_filepath  ,kyd_acknowledge_filepath,gst_filepath ,bank_proof_filepath ,address_proof_filepath  ,signatory_filepath ,nism_certificate_filepath  from amfi_distributer_master_pending  where pan_no =$1`, [pan_no])

        if (selected_file['rowCount'] > 0) {
            fileId_arr.push(selected_file['rows'][0]['pancard_filepath'])
            fileId_arr.push(selected_file['rows'][0]['adharcard_filepath'])
            fileId_arr.push(selected_file['rows'][0]['signature_filepath'])
            fileId_arr.push(selected_file['rows'][0]['kyd_acknowledge_filepath'])
            fileId_arr.push(selected_file['rows'][0]['gst_filepath'])
            fileId_arr.push(selected_file['rows'][0]['bank_proof_filepath'])
            fileId_arr.push(selected_file['rows'][0]['address_proof_filepath'])
            fileId_arr.push(selected_file['rows'][0]['signatory_filepath'])
            fileId_arr.push(selected_file['rows'][0]['nism_certificate_filepath'])
            fileId_arr.push(selected_file['rows'][0]['photo_filepath'])

            let blobArrayList = [];

            for (let i = 0; i < fileId_arr.length; i++) {
                if (fileId_arr[i] != null || fileId_arr[i] != 'null' || fileId_arr[i] != '') {

                    var num = parseInt(fileId_arr[i]) || 0;
                    if (num > 0) {
                        let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [num])

                        if (file_res['rowCount'] > 0) {

                            let imgBuff = file_res['rows'][0]['image'];
                            let image_type = file_res['rows'][0]['image_type'];

                            if (image_type == 'pdf') {
                                blobArrayList.push(imgBuff);

                            }
                            else if (image_type == 'png' || image_type == 'PNG') {
                                //convert pdf
                                let convertedImagebuff = await convertPngToPdf(imgBuff)
                                if (convertedImagebuff != null) {
                                    blobArrayList.push(convertedImagebuff);
                                }
                            }
                            else if (image_type == 'jpg' || image_type == 'jpeg' || image_type == 'JPG' || image_type == 'JPEG') {
                                //convert pdf
                                let convertedImagebuff = await convertJpgToPdf(imgBuff)
                                if (convertedImagebuff != null) {
                                    blobArrayList.push(convertedImagebuff);
                                }
                            }
                        }

                    }
                }
            }

            let file_base64 = await mergeSinglePdf.mergeSinglePdf(blobArrayList);

            if (file_base64 != null) {
                let req_data = {
                    "file_name": pan_no + "_" + Date.now() + ".pdf",
                    "image_type": "pdf",
                    "image": file_base64
                }

                let fileid = await helper.upload_file(req_data);

                return fileid;
            }

        }

        return null;
    }
    catch (error) {
        console.log("error===========>", error)
    }
}


convertJpgToPdf = async (imgBuffer) => {
    try {
        const pdfDoc = await PDFDocument.create();
        const img = await pdfDoc.embedJpg(imgBuffer);
        const imagePage = pdfDoc.insertPage(0);

        imagePage.drawImage(img, {
            x: 0,
            y: 0,
            width: imagePage.getWidth(),
            height: imagePage.getHeight()
        });

        const pdfBytes = await pdfDoc.save();
        var imageBuff = Buffer.from(pdfBytes).toString('base64');
        return imageBuff;
    }
    catch (error) {
        console.log(error);
        return null;
    }
}

convertPngToPdf = async (imgBuffer) => {
    try {
        const pdfDoc = await PDFDocument.create();
        const img = await pdfDoc.embedPng(imgBuffer);
        const imagePage = pdfDoc.insertPage(0);

        imagePage.drawImage(img, {
            x: 0,
            y: 0,
            width: imagePage.getWidth(),
            height: imagePage.getHeight()
        });

        const pdfBytes = await pdfDoc.save();
        var imageBuff = Buffer.from(pdfBytes).toString('base64');
        return imageBuff;
    }
    catch (error) {
        console.log(error);
        return null;
    }
}

insertRegRenHistory = async (data) => {
    await pool.query(`INSERT INTO tbl_reg_ren_hist
(pan_no, sys_appl_no, req_type, appl_date, appl_uploads, req_status, "source", created_by, created_date, modified_by, modified_date)
VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
`, [data.pan_no, data.application_reference_no, data.req_type, 'now()', data.appl_uploads, data.req_status, data.source, data.user_id, 'now()', data.user_id, 'now()'])
}

updateRegRenHistory = async (data) => {
    let appl_uploads = '';
    let user_id = null;
    if ('appl_uploads' in data) {
        appl_uploads = data.appl_uploads;
    }
    if ('user_id' in data) {
        user_id = data['user_id'];
    }
    await pool.query(`update tbl_reg_ren_hist
    set req_status=$3,appl_uploads=$6, modified_by=$4, modified_date=$5 where "pan_no"=$1 and "sys_appl_no"=$2
    `, [data.pan_no, data.application_reference_no, data.req_status, user_id, 'now()', appl_uploads])
}

checkEuinExistsForCorpARN = async (data) => {
    let cor_res = await pool.query(`select * from amfi_distributer_master_approved where pan_no =$1 and arn_number =$2 and category_of_corporation ='COR'`, [data.pan_no, data.arn_number])

    if (cor_res['rowCount'] > 0) {
        let select_euin = await pool.query(`select * from amfi_distributer_master_approved where arn_id=$1`, [data.arn_number])
        if (select_euin['rowCount'] > 0) {
            let current_date = moment().format('YYYY-MM-DD')

            let valid_res = await pool.query(`select "pan_no" from amfi_distributer_master_approved where "pan_no"=$1 and "validity_to">$2`, [data.pan_no, current_date])

            if (valid_res['rowCount'] > 0) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return true;
        }
    }
    else {
        return false;
    }
}

checkInvalidDetails = async (data) => {
    let current_date = moment().format('YYYY-MM-DD')
    let res = await pool.query(`select * from tbl_amfi_invalid_details where pan_no=$1 and invalid_from<=$2 and invalid_to>=$2`, [data.pan_no, current_date])

    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

checkInvalidDetailsForLogin = async (data) => {
    let select_data = await pool.query(`select pan_no  from amfi_distributer_master_approved where arn_number=$1`, [data.user_name])

    if (select_data['rowCount'] > 0) {
        let current_date = moment().format('YYYY-MM-DD')
        let res = await pool.query(`select * from tbl_amfi_invalid_details where pan_no=$1 and invalid_from<=$2 and invalid_to>=$2`, [select_data['rows'][0]['pan_no'], current_date])

        if (res['rowCount'] > 0) {
            return true;
        }
        return false;
    }
    else {
        return true;
    }
}


checkandGetValidFromandTo = async (data) => {
    let current_date = moment().format('YYYY-MM-DD')
    let arn_validity = null;
    let nism_validto = null;
    let validity_from = null;
    let validity_to = null;
    let select_arnvalidity = await pool.query(`select to_char("validity_to",'YYYY-MM-DD')as arn_validity from amfi_distributer_master_approved where "pan_no"=$1 and arn_number =$2 `, [data.pan_no, data.arn_number])

    if (select_arnvalidity['rowCount'] > 0) {
        arn_validity = select_arnvalidity['rows'][0]['arn_validity'];

    }

    let selectnism_valid = await pool.query(`select "pan_no",validity_to from tbl_user_nism_details where "pan_no"=$1 and "status"=true order by "id" desc limit 1`, [data.pan_no])

    if (selectnism_valid['rowCount'] > 0) {
        nism_validto = selectnism_valid['rows'][0]['validity_to'];
    }

    let cor_res = await pool.query(`select * from amfi_distributer_master_approved where pan_no =$1 and arn_number =$2 and category_of_corporation ='COR'`, [data.pan_no, data.arn_number])

    if (cor_res['rowCount'] > 0) {

        let valid_res = await pool.query(`select "pan_no" from amfi_distributer_master_approved where "pan_no"=$1 and "validity_to">$2`, [data.pan_no, current_date])

        if (valid_res['rowCount'] > 0) {
            let select_euin = await pool.query(`select * from amfi_distributer_master_approved where arn_id=$1`, [data.arn_number])
            if (select_euin['rowCount'] > 0) {
                validity_from = current_date;
                validity_to = moment(current_date, 'YYYY-MM-DD').add(3, 'years')
            }
            else {
                return null;
            }

        }
        else {
            validity_from = arn_validity
            validity_to = moment(arn_validity, 'YYYY-MM-DD').add(3, 'years')

        }

    }
    else {
        let nism_cert = await pool.query(`select "pan_no","nism_certificate_date" from tbl_user_nism_details where "pan_no"=$1 and "nism_certificate_date">$2  and "status"=true order by "id" desc limit 1`, [data.pan_no, current_date])
        if (nism_cert['rowCount'] > 0) {
            let select_arnvalid = (`select "pan_no","nism_certificate_date" from tbl_user_nism_details where "pan_no"=$1 and "nism_certificate_date"<$2  and "status"=true order by "id" desc limit 1`, [data.pan_no, arn_validity])
            if (select_arnvalid['rowCount'] > 0) {
                validity_from = arn_validity
                validity_to = nism_validto;
            }
            else {
                validity_from = current_date;
                validity_to = nism_validto;
            }

        }
        else {

        }
    }
    return { 'validity_from': validity_from, 'validity_to': validity_to };
}

checkandGetValidFromandToDate = async (data) => {
    let current_date = moment().format('YYYY-MM-DD')
    let arn_validity = null;
    let nism_validto = null;
    let validity_from = null;
    let validity_to = null;
    let select_arnvalidity = await pool.query(`select to_char("validity_to",'YYYY-MM-DD')as arn_validity from amfi_distributer_master_approved where "pan_no"=$1`, [data.pan_no])

    if (select_arnvalidity['rowCount'] > 0) {
        arn_validity = select_arnvalidity['rows'][0]['arn_validity'];

    }
    let selectnism_valid = await pool.query(`select "pan_no",to_char("validity_to",'YYYY-MM-DD')as nism_validity from tbl_user_nism_details where "pan_no"=$1 and "status"=true order by "id" desc limit 1`, [data.pan_no])

    if (selectnism_valid['rowCount'] > 0) {
        nism_validto = selectnism_valid['rows'][0]['nism_validity'];
    }

    let cor_res = await pool.query(`select * from amfi_distributer_master_approved where pan_no =$1  and category_of_corporation ='COR'`, [data.pan_no])

    if (cor_res['rowCount'] > 0) {

        let valid_res = await pool.query(`select "pan_no" from amfi_distributer_master_approved where "pan_no"=$1 and "validity_to">$2`, [data.pan_no, current_date])

        if (valid_res['rowCount'] > 0) {
            let select_euin = await pool.query(`select * from amfi_distributer_master_approved where arn_id=$1`, [data.arn_number])
            if (select_euin['rowCount'] > 0) {
                validity_from = current_date;
                validity_to = moment(current_date, 'YYYY-MM-DD').add(3, 'years')
            }
            else {
                return null;
            }

        }
        else {
            validity_from = arn_validity
            validity_to = moment(arn_validity, 'YYYY-MM-DD').add(3, 'years')

        }

    }
    else {
        let nism_validity = await pool.query(`select "pan_no","nism_certificate_date" from tbl_user_nism_details where "pan_no"=$1 and "validity_to"<=$2  and "status"=true order by "id" desc limit 1`, [data.pan_no, arn_validity])
        if (nism_validity['rowCount'] > 0) {

            return null;
        }
        else {

            let nism_cert = await pool.query(`select "pan_no","nism_certificate_date" from tbl_user_nism_details where "pan_no"=$1 and "nism_certificate_date">$2  and "status"=true order by "id" desc limit 1`, [data.pan_no, current_date])

            if (nism_cert['rowCount'] > 0) {
                let select_arnvalidity = await pool.query(`select "validity_to" from amfi_distributer_master_approved where "pan_no"=$1 and arn_number =$2 and "validity_to"<$3 `, [data.pan_no, data.arn_number, current_date])

                if (select_arnvalidity['rowCount'] > 0) {
                    validity_from = current_date;
                    validity_to = nism_validto;
                }
                else {
                    validity_from = moment(arn_validity, 'YYYY-MM-DD').add(1, 'days');
                    validity_to = nism_validto;
                }
            }
            else {
                return null;
            }
        }
    }
    return { 'validity_from': validity_from, 'validity_to': validity_to };

}




module.exports = {
    getDistributerPendingDataById,
    getARNCategoryDropdwn,
    saveRegisterOnAMFI,
    updatePersonalDetails,
    updateCertificationDetails,
    updateBankDetails,
    updateDocuments,
    sendOtp,
    panExistsInPending,
    panExistsInActivated,
    emailExistsInPending,
    emailExistsInActivated,
    mobileNoExistsInPending,
    mobileNoExistsInActivated,
    verifyMobileNoOtp,
    verifyEmailOtp,
    getDetailsByPincode,
    getBankDetailsByIFSCcode,
    pan4thcharacter,
    getPersonalDetailsById,
    getCertificationDetailsById,
    getBankDetailsById,
    resendMobileOtp,
    resendEmailOtp,
    updateRegistrationType,
    panExistsInNism,
    updateCompanyDetails,
    getCompanyDetailsById,
    getDetailsByARNId,
    registrationActivate,
    getDocumentsById,
    loginARNEUIN,
    getdataByPanNo,
    deleteAfterResumeDays,
    panExpireInNism,
    getAccountTypeById,
    getPaymentAmountById,
    getDeclarationById,
    arnExistsInActivated,
    euinExistsInActivated,
    getFilebase64ByID,
    getDropDownData,
    verifyOtp,
    getNoOfAttemptCount,
    forgotUserId,
    forgotPasswordSendOtp,
    forgotPasswordVerifyOtp,
    changePassword,
    updateRegistrationReview,
    updatePayment,
    getUserSession,
    updateARNEUINtoken,
    logoutARNEUIN,
    updateConcatinatedFile,
    convertJpgToPdf,
    convertPngToPdf,
    checkNismCertificateDate,
    insertRegRenHistory,
    updateRegRenHistory,
    checkEuinExistsForCorpARN,
    checkInvalidDetails,
    checkInvalidDetailsForLogin,
    checkandGetValidFromandTo,
    checkandGetValidFromandToDate
};

