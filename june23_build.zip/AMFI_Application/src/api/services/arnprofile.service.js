const email_sender = require("../../common/email_sender");
const message_sender = require("../../common/message_sender");
const pool = require("../../config/db");
const helper = require("../services/helper.service");
const offlineService = require("../services/offlineregister.service")


getProfileSummaryById = async (data) => {
    let res = await pool.query(`select A."id", A."arn_number",A."first_name",A."last_name",A."pan_no",to_char(A."date_of_birth",'YYYY-MM-DD') as  date_of_birth,A."address1",A."address2",A."address3",A."city",A."pincode",A."state",A."mobile_no",A."email_id",to_char(A.validity_to ,'YYYY-MM-DD') AS validity_to from amfi_distributer_master_approved A where A."user_id"=$1`, [data.user_id])
    if (res['rowCount'] > 0) {
        let d1 = new Date(res['rows'][0]['validity_to'])
        let d2 = new Date();

        let mondiff = await monthDiff(d1, d2);
        if (mondiff > 6) {
            res['rows'][0]['status'] = 'Active';
        }
        else if (mondiff < 6 && mondiff > 1) {
            res['rows'][0]['status'] = 'Expires in ' + mondiff + ' Months';
        }
        else {
            let daydiff = await daysDiff(d1, d2);
            res['rows'][0]['status'] = 'Expires in ' + daydiff + ' days';

        }
        if (res['rows'][0]['status'] != 'Active') {

            let pending_res_data = await pool.query(`select *  from amfi_distributer_master_pending  where "pan_no"=$1`, [res['rows'][0]['pan_no']])

            if (pending_res_data['rowCount'] > 0) {
                if (pending_res_data['rows'][0]['is_amount_paid'] == false) {
                    res['rows'][0]['status'] = 'Sent for Renewal, Payment Pending';
                }
                else {
                    res['rows'][0]['status'] = 'Payment Completed Pending with BO2';
                }
            }
        }
        return res['rows'];
    }
    return null;
}

monthDiff = async (dt1, dt2) => {
    var diffMonth = (dt2.getTime() - dt1.getTime()) / 1000;
    diffMonth /= (60 * 60 * 24 * 7 * 4);
    return Math.abs(Math.round(diffMonth));
}

daysDiff = async (dt1, dt2) => {
    var diffTime = (dt2.getTime() - dt1.getTime());
    var daysDiff = diffTime / (1000 * 3600 * 24);
    return Math.abs(Math.round(daysDiff));

}


getActiveBankDetailsById = async (data) => {
    let res = await pool.query(`select "id", "account_Number" ,"account_type","name_of_bank","branch","bank_city","ifsc","bank_proof_filepath","pan_no"  from amfi_distributer_master_approved where "user_id"=$1`, [data.user_id])
    if (res['rowCount'] > 0) {
        let bankproof_id = res['rows'][0]['bank_proof_filepath'];
        res['rows'][0]['bank_proof_filepath_base64'] = null;
        res['rows'][0]['bank_proof_filepath_image_type'] = '';
        res['rows'][0]['bank_proof_filename'] = '';
        var num1 = parseInt(bankproof_id) || 0;
        if (num1 > 0) {
            let bankproof_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [bankproof_id])
            if (bankproof_res['rowCount'] > 0) {
                let imgBuff = bankproof_res['rows'][0]['image'];
                res['rows'][0]['bank_proof_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                res['rows'][0]['bank_proof_filepath_image_type'] = bankproof_res['rows'][0]['image_type'];
                res['rows'][0]['bank_proof_filename'] = bankproof_res['rows'][0]['file_name']

                //                res['rows'][0]['bank_proof_filepath_base64'] = bankproof_res['rows'][0]['image'];

            }
        }
        return res['rows'];
    }
    return null;
}

getGSTInfoById = async (data) => {
    let res = await pool.query(`select "id", "gstn","gst_filepath","gst_verified","gst_verified_by","pan_no"  from amfi_distributer_master_approved where "user_id"=$1`, [data.user_id])
    if (res['rowCount'] > 0) {

        let gst_id = res['rows'][0]['gst_filepath'];
        res['rows'][0]['gst_filepath_base64_image_type'] = '';
        res['rows'][0]['gst_filename'] = '';
        res['rows'][0]['gst_filepath_base64'] = null;
        var num1 = parseInt(gst_id) || 0;
        if (num1 > 0) {
            let gst_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [gst_id])
            if (gst_res['rowCount'] > 0) {
                let imgBuff = gst_res['rows'][0]['image'];
                res['rows'][0]['gst_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                res['rows'][0]['gst_filepath_base64_image_type'] = gst_res['rows'][0]['image_type'];
                res['rows'][0]['gst_filename'] = gst_res['rows'][0]['file_name'];

                //                res['rows'][0]['gst_filepath_base64'] = gst_res['rows'][0]['image'];

            }
        }
        return res['rows'];
    }
    return null;
}

getProfilePictureById = async (data) => {
    let resObj = {}
    let res = await pool.query(` select "id", "photo_filepath" from amfi_distributer_master_approved where "user_id"=$1`, [data.user_id])
    if (res['rowCount'] > 0) {
        let photo_id = res['rows'][0]['photo_filepath'];
        if (photo_id != null) {
            let photo_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [photo_id])
            if (photo_res['rowCount'] > 0) {
                resObj['photo_filepath'] = photo_id;

                let imgBuff = photo_res['rows'][0]['image'];
                resObj['photo_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');;
                resObj['photo_filepath_base64_image_type'] = photo_res['rows'][0]['image_type'];
                resObj['photo_filename'] = photo_res['rows'][0]['file_name'];

                //                resObj['photo_filepath_base64'] = photo_res['rows'][0]['image'];

            }
        }
        return resObj;
    }
    return null;
}


updateActiveProfileAddress = async (data) => {
    let active_res = await pool.query(`select "address1","address2","address3","city","pincode","state","address_proof_filepath" from  amfi_distributer_master_approved where  "user_id"=$1`, [data['user_id']])

    if (active_res['rowCount'] > 0) {
        let application_reference_no = ''
        // let select_counter = await pool.query(`select * from amfi_counter`)
        // if (select_counter['rowCount'] > 0) {
        //     let applicount = select_counter['rows'][0]['application_reference_count'] + 1
        //     application_reference_no = 'APP-REF' + applicount
        //     await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
        // }
        application_reference_no = await helper.generateApplicationNumber()

        await saveChangeRequestHistory(data, '', '', '', application_reference_no, 'BD', data['address_proof_filepath'])
        await offlineService.saveApproveToApprovehistory(data['pan_no'], application_reference_no)

        await pool.query(`UPDATE amfi_distributer_master_approved_history SET "address1"=$1,"address2"=$2,"address3"=$3,"city"=$4,"pincode"=$5,"state"= $6,"address_proof_filepath"=$7,"modified_date"=$8,"modified_by"=$9 where "application_reference_no"=$10 and "pan_no"=$11`, [data['address1'], data['address2'], data['address3'], data['city'], data['pincode'], data['state'], data['address_proof_filepath'], 'now()', data.user_id, application_reference_no, data.pan_no])

        // if (active_res['rows'][0]['address1'] != data.address1) {
        //     await saveChangeRequestHistory(data, 'address1', active_res['rows'][0]['address1'], data.address1, application_reference_no, 'BD')
        // }
        // if (active_res['rows'][0]['address2'] != data.address2) {
        //     await saveChangeRequestHistory(data, 'address2', active_res['rows'][0]['address2'], data.address2, application_reference_no, 'BD')
        // }
        // if (active_res['rows'][0]['address3'] != data.address3) {
        //     await saveChangeRequestHistory(data, 'address3', active_res['rows'][0]['address3'], data.address3, application_reference_no, 'BD')
        // }
        // if (active_res['rows'][0]['city'] != data.city) {
        //     await saveChangeRequestHistory(data, 'city', active_res['rows'][0]['city'], data.city, application_reference_no, 'BD')
        // }
        // if (active_res['rows'][0]['pincode'] != data.pincode) {
        //     await saveChangeRequestHistory(data, 'pincode', active_res['rows'][0]['pincode'], data.pincode, application_reference_no, 'BD')
        // }
        // if (active_res['rows'][0]['state'] != data.state) {
        //     await saveChangeRequestHistory(data, 'state', active_res['rows'][0]['state'], data.state, application_reference_no, 'BD')
        // }
        // if (active_res['rows'][0]['address_proof_filepath'] != data.address_proof_filepath) {
        //     await saveChangeRequestHistory(data, 'address_proof_filepath', active_res['rows'][0]['address_proof_filepath'], data.address_proof_filepath, application_reference_no, 'BD')
        // }

        // let res = await pool.query(`UPDATE amfi_distributer_master_approved SET "address1"=$1,"address2"=$2,"address3"=$3,"city"=$4,"pincode"=$5,"state"= $6,"address_proof_filepath"=$7,"modified_date"=$8,"modified_by"=$9 where "user_id"=$10`, [data['address1'], data['address2'], data['address3'], data['city'], data['pincode'], data['state'], data['address_proof_filepath'], 'now()', data.user_id, data.user_id])

        // if (res['rowCount'] > 0) {
        return data['user_id'];
        // }
    }
    return null;
}



updateActiveBankDetails = async (data) => {
    let active_res = await pool.query(`select "account_Number","bank_proof_filepath","ifsc","name_of_bank","branch","bank_city","account_type" from  amfi_distributer_master_approved where  "user_id"=$1`, [data['user_id']])
    if (active_res['rowCount'] > 0) {
        let application_reference_no = ''
        // let select_counter = await pool.query(`select * from amfi_counter`)
        // if (select_counter['rowCount'] > 0) {
        //     let applicount = select_counter['rows'][0]['application_reference_count'] + 1
        //     application_reference_no = 'APP-REF' + applicount
        //     await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
        // }
        application_reference_no = await helper.generateApplicationNumber()

        await saveChangeRequestHistory(data, '', '', '', application_reference_no, 'BANK', data['bank_proof_filepath'])
        await offlineService.saveApproveToApprovehistory(data['pan_no'], application_reference_no)
        await pool.query(`UPDATE amfi_distributer_master_approved_history SET 
         "account_Number"=$1,"bank_proof_filepath"=$2,"ifsc"=$3,"name_of_bank"=$4,
         "branch"=$5,"bank_city"=$6, "account_type"=$7,"modified_date"=$8,"modified_by"=$9 where "application_reference_no"=$10 and "pan_no"=$11`, [data['account_Number'], data['bank_proof_filepath'], data['ifsc'], data['name_of_bank'], data['branch'], data['bank_city'], data['account_type'], 'now()', data['user_id'], application_reference_no, data.pan_no])


        // if (active_res['rows'][0]['account_Number'] != data.account_Number) {
        //     await saveChangeRequestHistory(data, 'Account Number', active_res['rows'][0]['account_Number'], data.account_Number, application_reference_no, 'BANK')
        // }

        // if (active_res['rows'][0]['bank_proof_filepath'] != data.bank_proof_filepath) {
        //     await saveChangeRequestHistory(data, 'bank_proof_filepath', active_res['rows'][0]['bank_proof_filepath'], data['bank_proof_filepath'], application_reference_no, 'BANK')
        // }
        // if (active_res['rows'][0]['ifsc'] != data.ifsc) {
        //     await saveChangeRequestHistory(data, 'ifsc', active_res['rows'][0]['ifsc'], data['ifsc'], application_reference_no, 'BANK')
        // }
        // if (active_res['rows'][0]['name_of_bank'] != data.name_of_bank) {
        //     await saveChangeRequestHistory(data, 'name_of_bank', active_res['rows'][0]['name_of_bank'], data['name_of_bank'], application_reference_no, 'BANK')
        // }
        // if (active_res['rows'][0]['branch'] != data.branch) {
        //     await saveChangeRequestHistory(data, 'branch', active_res['rows'][0]['branch'], data['branch'], application_reference_no, 'BANK')
        // }
        // if (active_res['rows'][0]['bank_city'] != data.bank_city) {
        //     await saveChangeRequestHistory(data, 'bank_city', active_res['rows'][0]['bank_city'], data['bank_city'], application_reference_no, 'BANK')
        // }
        // if (active_res['rows'][0]['account_type'] != data.account_type) {
        //     await saveChangeRequestHistory(data, 'account_type', active_res['rows'][0]['account_type'], data['account_type'], application_reference_no, 'BANK')
        // }

        //         let res = await pool.query(`UPDATE amfi_distributer_master_approved SET 
        // "account_Number"=$1,"bank_proof_filepath"=$2,"ifsc"=$3,"name_of_bank"=$4,
        // "branch"=$5,"bank_city"=$6, "account_type"=$7,"modified_date"=$9,"modified_by"=$10 where "user_id"=$8`, [data['account_Number'], data['bank_proof_filepath'], data['ifsc'], data['name_of_bank'], data['branch'], data['bank_city'], data['account_type'], data['user_id'], 'now()', data['user_id']])

        //         if (res['rowCount'] > 0) {
        return data['user_id'];
        // }
    }
    return null;
}
updateGSTInfo = async (data) => {
    let active_res = await pool.query(`select "gst_filepath","gstn" from  amfi_distributer_master_approved where  "user_id"=$1`, [data['user_id']])

    if (active_res['rowCount'] > 0) {
        let application_reference_no = ''
        // let select_counter = await pool.query(`select * from amfi_counter`)
        // if (select_counter['rowCount'] > 0) {
        //     let applicount = select_counter['rows'][0]['application_reference_count'] + 1
        //     application_reference_no = 'APP-REF' + applicount
        //     await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
        // }
        application_reference_no = await helper.generateApplicationNumber()

        await saveChangeRequestHistory(data, 'Gst', active_res['rows'][0]['gstn'], data['gstn'], application_reference_no, 'GST', data['gst_filepath'])
        await offlineService.saveApproveToApprovehistory(data['pan_no'], application_reference_no)

        await pool.query(`UPDATE amfi_distributer_master_approved_history SET "gst_filepath"=$3,"gstn"=$4,"modified_date"=$1,"modified_by"=$2 where "application_reference_no"=$5 and "pan_no"=$6`, ['now()', data['user_id'], data['gst_filepath'], data['gstn'], application_reference_no, data['pan_no']]);

        // if (active_res['rows'][0]['gst_filepath'] != data.gst_filepath) {
        //     await saveChangeRequestHistory(data, 'gst_filepath', active_res['rows'][0]['gst_filepath'], data['gst_filepath'], application_reference_no, 'GST')
        // }
        // if (active_res['rows'][0]['gstn'] != data.gstn) {
        //     await saveChangeRequestHistory(data, 'gstn', active_res['rows'][0]['gstn'], data['gstn'], application_reference_no, 'GST')
        // }

        // let res = await pool.query(`UPDATE amfi_distributer_master_approved SET "gst_filepath"=$4,"gstn"=$5,"modified_date"=$2,"modified_by"=$3 where "user_id"=$1`, [data['user_id'], 'now()', data['user_id'], data['gst_filepath'], data['gstn']]);

        // if (res['rowCount'] > 0) {
        return data['user_id'];
        // }
    }

    return null;
}
updateProfilePicture = async (data) => {
    let buff = await helper.base64ToThumbnail(data['photo_filepath']);
    let res = await pool.query(`UPDATE amfi_distributer_master_approved SET "photo_filepath"=$4,"modified_date"=$2,"modified_by"=$3,"photo_thumbnail"=$5  where "user_id"=$1`, [data['user_id'], 'now()', data['user_id'], data['photo_filepath'], buff]);

    if (res['rowCount'] > 0) {
        return data['user_id'];
    }
    return null;
}

getARNRenewal = async (data) => {
    let res = await pool.query(`select A."id",A."arn_number",to_char(A.validity_to ,'YYYY-MM-DD') AS validity_to from amfi_distributer_master_approved  A  where A."user_id"=$1`, [data.user_id])
    if (res['rowCount'] > 0) {
        let d1 = new Date(res['rows'][0]['validity_to'])
        let d2 = new Date();
        let mondiff = await monthDiff(d1, d2);
        if (mondiff > 6) {
            res['rows'][0]['status'] = 'Active';
        }
        else if (mondiff < 6 && mondiff > 1) {
            res['rows'][0]['status'] = 'Expires in ' + mondiff + ' Months';
        }
        else {
            let daydiff = await daysDiff(d1, d2);
            res['rows'][0]['status'] = 'Expires in ' + daydiff + ' days';

        }
        return res['rows'];
    }
    return null;
}



sendMobileNoChangeOtpForProfile = async (data) => {
    // let sixdigitOtp = Math.floor(100000 + Math.random() * 900000);
    let otpmobile = '123456'; //common.random number generator 6 digit
    let msg = "Hi AMFI ur otp " + otpmobile;
    let subject = "Register";
    let no_of_attempts = 0;
    await message_sender.sendMessage(msg, data.mobile_no);

    let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [data.pan_no])
    if (res['rowCount'] > 0) {
        await pool.query(`update amfi_mobile_email_otp set "mobile_otp"=$1,"mobile_no"=$2,"lastmobile_otp_senttime"=$3,"modified_date"=$5 where "pan_no"=$4`, [otpmobile, data.mobile_no, 'now()', data.pan_no, 'now()'])
        return data;

    }
    else {
        await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, [data.mobile_no, '', otpmobile, '', 'now()', 'now()', no_of_attempts, false, '', '', 'now()', data.pan_no])
        return data;

    }
}

sendEmailChangeOtpForProfile = async (data) => {
    //let sixdigitOtp = Math.floor(100000 + Math.random() * 900000);
    let otpemail = '123456'; //common.random number generator 6 digit
    let msg = "Hi AMFI ur otp " + sixdigitOtp;
    let subject = "Register";
    let no_of_attempts = 0;
    await email_sender.sendEmail(subject, msg, data.email_id);

    let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [data.pan_no])
    if (res['rowCount'] > 0) {
        await pool.query(`update amfi_mobile_email_otp set "email_otp"=$1,"email_id"=$2,"lastemail_otp_senttime"=$3,"modified_date"=$5 where "pan_no"=$4`, [otpemail, data.email_id, 'now()', data.pan_no, 'now()'])
        return data;

    }
    else {
        await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, ['', data.email_id, '', otpemail, 'now()', 'now()', no_of_attempts, false, '', '', 'now()', data.pan_no])
        return data;

    }
}

resendEmailChangeOtpForProfile = async (data) => {
    let res = await pool.query(`select "email_otp" from amfi_mobile_email_otp where "email_id"=$1 and "pan_no"=$2`, [data.email_id, data.pan_no])

    if (res['rowCount'] > 0) {
        let otpemail = res['rows'][0]['email_otp'];
        let msg = "Hi AMFI ur otp " + otpemail;
        let subject = "Register";
        await email_sender.sendEmail(subject, msg, data.email_id);
        return "success";
    }
    return null;
}

resendMobileNoChangeOtpForProfile = async (data) => {
    let res = await pool.query(`select "mobile_otp" from amfi_mobile_email_otp where "mobile_no"=$1 and "pan_no"=$2`, [data.mobile_no, data.pan_no])

    if (res['rowCount'] > 0) {
        let otpmobile = res['rows'][0]['mobile_otp'];
        let msg = "Hi AMFI ur otp " + otpmobile;
        let subject = "Register";
        await message_sender.sendMessage(msg, data.mobile_no);
        return "success";
    }
    return null;
}

verifyEmailOTP = async (data) => {
    let res = await pool.query(`select "id" from amfi_mobile_email_otp where "email_otp"=$1 and "pan_no"=$2`, [data.email_otp, data.pan_no])

    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

verifyEmailAndUpdateEMail = async (data) => {
    let res = await verifyEmailOTP(data);
    if (res) {
        let active_res = await pool.query(`select "email_id" from amfi_distributer_master_approved where "user_id"=$1 and "pan_no"=$2`, [data.user_id, data.pan_no])

        if (active_res['rowCount'] > 0) {
            if (active_res['rows'][0]['email_id'] != data.email_id) {
                // await saveChangeRequestHistory(data, 'email_id', active_res['rows'][0]['email_id'], data.email_id, '')
                await pool.query(`INSERT INTO tbl_chng_req_hist
                ("pan_no","req_type","appl_date","appl_uploads","req_status","key_value_edited","key_value_old", "key_value_new", "modified_date","created_by","modified_by",application_reference_no,"source","status","req_status_code") VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`, [data.pan_no, 'email_id', 'now()', '', 'Completed', 'email_id', active_res['rows'][0]['email_id'], data.email_id, 'now()', data.user_id, data.user_id, '', 'ONLINE', false, 'COMPLETED'])
            }
            await pool.query(`update amfi_distributer_master_approved set "email_id"=$1 where "user_id"=$2 and "pan_no"=$3  
            `, [data.email_id, data.user_id, data.pan_no])
        }

        return true;
    }
    return false;
}

verifyMobileOTP = async (data) => {
    let res = await pool.query(`select "id" from amfi_mobile_email_otp where "mobile_otp"=$1 and "pan_no"=$2`, [data.mobile_otp, data.pan_no])

    if (res['rowCount'] > 0) {
        //if count>3 return false

        return true;
    }
    //update lastmodified time count
    return false;
}

VerifyMobileAndUpdateMobile = async (data) => {
    let res = await verifyMobileOTP(data);
    if (res) {
        let active_res = await pool.query(`select "mobile_no" from amfi_distributer_master_approved where "user_id"=$1 and "pan_no"=$2`, [data.user_id, data.pan_no])

        if (active_res['rowCount'] > 0) {

            if (active_res['rows'][0]['mobile_no'] != data.mobile_no) {
                // await saveChangeRequestHistory(data, 'mobile_no', active_res['rows'][0]['mobile_no'], data.mobile_no, '')

                await pool.query(`INSERT INTO tbl_chng_req_hist
                ("pan_no","req_type","appl_date","appl_uploads","req_status","key_value_edited","key_value_old", "key_value_new", "modified_date","created_by","modified_by",application_reference_no,"source","status","req_status_code") VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`, [data.pan_no, 'mobile_no', 'now()', '', 'Completed', 'mobile_no', active_res['rows'][0]['mobile_no'], data.mobile_no, 'now()', data.user_id, data.user_id, '', 'ONLINE', false, 'COMPLETED'])
            }
            await pool.query(`update amfi_distributer_master_approved set "mobile_no"=$1 where "user_id"=$2 and "pan_no"=$3  
            `, [data.mobile_no, data.user_id, data.pan_no])
        }
        return true;
    }
    return false;
}

getMappingEUINList = async (data) => {
    let res = await pool.query(`select B."id",B."first_name" ,B."middle_name" ,B."last_name" ,A."pan_no",B."designation" ,to_char(A."created_date",'YYYY-MM-DD') as applied_on,"branch" ,"company_city","mobile_no","email_id",B."distributer_master_status",B."euin_number"   from map_hist A,amfi_distributer_master_approved B where A."new_arn"=$1 and B."application_type" ='EUIN' and A."pan_no"=B."pan_no" and B.arn_id='' and A."status"=true `, [data.arn_number])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getDeMappingEUINList = async (data) => {
    let res = await pool.query(`select B."id",B."first_name" ,B."middle_name" ,B."last_name" ,A."pan_no",B."designation" ,to_char(A."created_date",'YYYY-MM-DD') as applied_on,"branch" ,"company_city","mobile_no","email_id",B."distributer_master_status",B."euin_number"   from map_hist A,amfi_distributer_master_approved B where A.old_arn=$1 and B."application_type" ='EUIN' and A."pan_no"=B."pan_no" and  B.arn_id!='' and A."status"=true`, [data.arn_number])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getViewAllEUIN = async (data) => {
    let arr1 = []
    let arr2 = []
    let res_approved = await pool.query(`select "id","first_name" ,"middle_name" ,"last_name" ,"pan_no","distributer_master_status","euin_number","arn_id","photo_filepath","photo_thumbnail" from amfi_distributer_master_approved where "application_type" ='EUIN' and "arn_id"=$1`, [data.arn_number])

    if (res_approved['rowCount'] > 0) {
        arr1 = res_approved['rows'];
    }

    let res_pending = await pool.query(`select "id","first_name" ,"middle_name" ,"last_name" ,"pan_no","distributer_master_status","arn_id","photo_filepath","photo_thumbnail","euin_number" from amfi_distributer_master_pending where "application_type" ='EUIN' and "arn_id"=$1`, [data.arn_number])

    if (res_pending['rowCount'] > 0) {
        arr2 = res_pending['rows'];
    }
    var arr3 = [...arr1, ...arr2];

    return arr3;
}

getEUINRenewalList = async (data) => {
    let res = await pool.query(`select "id", "first_name" ,"middle_name" ,"last_name" ,"pan_no","designation" ,"renewal_type" ,"mobile_no","email_id","application_reference_no"  from amfi_distributer_master_pending where "application_type" ='EUIN' and "renewal_type"='RENEWAL' and "arn_id"=$1`, [data.arn_number])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getRegistrationPaymentList = async (data) => {
    let res = await pool.query(`select "id","first_name" ,"middle_name" ,"last_name" ,"pan_no","designation" ,"renewal_type" ,"mobile_no","email_id","application_reference_no"  from amfi_distributer_master_pending where "application_type" ='EUIN'  and "arn_id"=$1 and "current_action_code"='COMPLETED'`, [data.arn_number])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}
getProductCategoriesOption = async (data) => {
    let res = await pool.query(`select "id","op_code","op_desc"  from tbl_optins_master where "status"=true`)

    if (res['rowCount'] > 0) {
        let opincode = []
        let opin_res = await pool.query(`select "opin_codes" from tbl_user_opin where "pan_no"=$1`, [data.pan_no])

        if (opin_res['rowCount'] > 0) {
            opincode = opin_res['rows'][0]['opin_codes'].split(',')
        }

        for (let i = 0; i < res['rows'].length; i++) {
            res['rows'][i]['checked'] = false;
            for (let j = 0; j < opincode.length; j++) {
                if (res['rows'][i]['op_code'] == opincode[j]) {
                    res['rows'][i]['checked'] = true;
                }
            }
        }
        return res['rows'];

    }
    return null;
}

saveProductCategoriesOption = async (data) => {
    if (data.opin.length > 0) {
        await pool.query(`delete from tbl_user_opin where "pan_no"=$1`, [data.pan_no])
        let opin_codes = []
        for (let i = 0; i < data.opin.length; i++) {
            if (data.opin[i]['checked'])
                opin_codes.push(data.opin[i]['op_code'])
        }

        let res = await pool.query(`INSERT INTO tbl_user_opin
    ("pan_no", "opin_codes", "last_opin_date", "opin_prev", created_by,  modified_by, modified_date)VALUES($1,$2,$3,$4,$5,$6,$7)returning "id"`, [data.pan_no, opin_codes.toString(), null, '', data.user_id, data.user_id, 'now()'])

        if (res['rowCount'] > 0) {
            return res['rows'][0]['id'];
        }
    }
    return null;
}

viewMappingEUINApplicationById = async (data) => {
    let res = await pool.query(`select "id","first_name","last_name",to_char("date_of_birth",'YYYY-MM-DD') AS  date_of_birth  ,"pan_no", "gender", "arn_id","name_of_organisation",to_char("date_of_appointment",'YYYY-MM-DD') as date_of_appointment,"designation","description_of_responsibilities","company_address1","company_address2","company_address3","company_pincode","company_city","company_state","country","certificate_number",to_char("date_of_passing_test",'YYYY-MM-DD') as date_of_passing_test,"qualification","university","year_of_passing","euin_number"  from amfi_distributer_master_approved  where id=$1`, [data.id])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

removeDeMappingEUIN = async (data) => {

    let id_array = data.id
    let str = `update amfi_distributer_master_approved set "arn_id"='',modified_date='now()' ,modified_by=${data.user_id} where id in (${id_array})`

    let res = await pool.query(str)
    if (res['rowCount'] > 0) {
        let pannostr = ''
        let panres = await pool.query(`select "pan_no" from amfi_distributer_master_approved where "id" in (${id_array})`)

        if (panres['rowCount'] > 0) {
            for (let i = 0; i < panres['rows'].length; i++) {
                let panid = panres['rows'][i]['pan_no']
                pannostr += '\'' + panid + '\'' + ','
            }
            pannostr = pannostr.slice(0, pannostr.length - 1);
            let delete_maphist = await pool.query(`update map_hist set old_appr_rej_date='now()',"old_appr_rej_status"='APPROVED' where "pan_no" in (${pannostr})`)
        }
        return data.id;
    }
    return null;
}

approveMappingEUIN = async (data) => {
    let id_array = data.id
    let str = `update amfi_distributer_master_approved set "arn_id" ='${data.arn_number}', modified_date ='now()', modified_by =${data.user_id}  where "id" in (${id_array})`
    let res = await pool.query(str)

    if (res['rowCount'] > 0) {
        let pannostr = ''
        let panres = await pool.query(`select "pan_no" from amfi_distributer_master_approved where "id" in (${id_array})`)

        if (panres['rowCount'] > 0) {
            for (let i = 0; i < panres['rows'].length; i++) {
                let panid = panres['rows'][i]['pan_no']
                pannostr += '\'' + panid + '\'' + ','
            }
            pannostr = pannostr.slice(0, pannostr.length - 1);
            let delete_maphist = await pool.query(`update map_hist set "status"=false,new_apprv_rej_date='now()',"new_appr_rej_status"='APPROVED' where "pan_no" in (${pannostr})`)
        }
        return data.id;
    }
    return null;
}

getARNRenewalDetailsById = async (data) => {
    let res = await pool.query(`select "id","first_name","last_name",to_char("date_of_birth",'YYYY-MM-DD') AS  date_of_birth  ,"pan_no", "gender", "address1", "address2", "address3","city","pincode","state",
    "gstn","certificate_number",to_char("date_of_passing_test",'YYYY-MM-DD') as date_of_passing_test,"cpe_certificate_number",to_char("date_of_cpe_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("date_of_cpe_to",'YYYY-MM-DD') as date_of_cpe_to,"qualification","university","year_of_passing","account_Number","bank_proof_filepath","ifsc","name_of_bank","branch","bank_city","account_type" from amfi_distributer_master_approved where "pan_no"=$1`, [data.pan_no])

    if (res['rowCount'] > 0) {
        let bankproof_id = res['rows'][0]['bank_proof_filepath'];
        res['rows'][0]['bank_proof_filepath_base64'] = null;
        var num1 = parseInt(bankproof_id) || 0;
        if (num1 > 0) {
            let bankproof_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [bankproof_id])
            if (bankproof_res['rowCount'] > 0) {
                let imgBuff = bankproof_res['rows'][0]['image'];
                res['rows'][0]['bank_proof_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                res['rows'][0]['bank_proof_filepath_image_type'] = bankproof_res['rows'][0]['image_type'];
                res['rows'][0]['bank_proof_filename'] = bankproof_res['rows'][0]['file_name'];

                //                res['rows'][0]['bank_proof_filepath_base64'] = bankproof_res['rows'][0]['image'];

            }
        }
        return res['rows'];
    }
    return null;
}

rejectMappingById = async (data) => {
    let id_array = data.id;
    let pannostr = '';
    let panres = await pool.query(`select "pan_no" from amfi_distributer_master_approved where "id" in (${id_array})`)

    if (panres['rowCount'] > 0) {
        for (let i = 0; i < panres['rows'].length; i++) {
            let panid = panres['rows'][i]['pan_no']
            pannostr += '\'' + panid + '\'' + ','
        }
        pannostr = pannostr.slice(0, pannostr.length - 1);
        let delete_maphist = await pool.query(`update map_hist set "status"=false,"new_appr_rej_status"='REJECTED' where "pan_no" in (${pannostr})`)
    }
    return data.id;
}

rejectDeMappingById = async (data) => {
    let id_array = data.id;
    let pannostr = '';
    let panres = await pool.query(`select "pan_no" from amfi_distributer_master_approved where "id" in (${id_array})`)

    if (panres['rowCount'] > 0) {
        for (let i = 0; i < panres['rows'].length; i++) {
            let panid = panres['rows'][i]['pan_no']
            pannostr += '\'' + panid + '\'' + ','
        }
        pannostr = pannostr.slice(0, pannostr.length - 1);
        let delete_maphist = await pool.query(`update map_hist set "status"=false,"old_appr_rej_status"='REJECTED' where "pan_no" in (${pannostr})`)
    }
    return data.id;
}

getselfDeclarationByCode = async (data) => {
    let res = await pool.query(`select "id","text" from amfi_declaration_ref where "code"=$1`, [data.code])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

verifyEmailAndsubmitDeclaration = async (data) => {
    let res = await verifyEmailOTP(data);
    if (res) {
        await pool.query(`update amfi_distributer_master_approved  set "declaration_time"='now()' where "pan_no"=$1`, [data.pan_no])
        return true;
    }
    return false;
}

verifyMobileAndsubmitDeclaration = async (data) => {
    let res = await verifyMobileOTP(data);
    if (res) {
        await pool.query(`update amfi_distributer_master_approved  set "declaration_time"='now()' where "pan_no"=$1`, [data.pan_no])
        return true;
    }
    return false;
}

saveChangeRequestHistory = async (data, key_value, old_value, new_value, application_reference_no, req_type, appl_uploads) => {
    // let appl_uploads = ''
    // if (key_value == 'gst_filepath' || key_value == 'bank_proof_filepath' || key_value == 'address_proof_filepath') {
    //     appl_uploads = new_value;
    // }
    await pool.query(`INSERT INTO tbl_chng_req_hist
    ("pan_no","req_type","appl_date","appl_uploads","req_status","key_value_edited","key_value_old", "key_value_new", "modified_date","created_by","modified_by",application_reference_no,"source","req_status_code") VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`, [data.pan_no, req_type, 'now()', appl_uploads, 'Authorise', key_value, old_value, new_value, 'now()', data.user_id, data.user_id, application_reference_no, 'ONLINE', 'AUTHORISE'])
}

module.exports = {
    getProfileSummaryById,
    getActiveBankDetailsById,
    getGSTInfoById,
    getProfilePictureById,
    updateActiveProfileAddress,
    updateActiveBankDetails,
    updateGSTInfo,
    updateProfilePicture,
    getARNRenewal,
    sendMobileNoChangeOtpForProfile,
    sendEmailChangeOtpForProfile,
    resendEmailChangeOtpForProfile,
    resendMobileNoChangeOtpForProfile,
    verifyEmailAndUpdateEMail,
    VerifyMobileAndUpdateMobile,
    getMappingEUINList,
    getDeMappingEUINList,
    getViewAllEUIN,
    getEUINRenewalList,
    getRegistrationPaymentList,
    getProductCategoriesOption,
    saveProductCategoriesOption,
    viewMappingEUINApplicationById,
    removeDeMappingEUIN,
    approveMappingEUIN,
    getARNRenewalDetailsById,
    rejectMappingById,
    rejectDeMappingById,
    getselfDeclarationByCode,
    verifyEmailAndsubmitDeclaration,
    verifyMobileAndsubmitDeclaration,
    verifyEmailOTP,
    verifyMobileOTP
}