const pool = require("../../config/db");
const helper = require("../services/helper.service");
const mergeSinglePdf = require("../../common/file_merge");
const registrationService = require("../services/registration.service");
const moment = require("moment");

getState = async () => {
    let res = await pool.query(`select distinct("state"),"statename" from amfi_pincode_master`)

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

saveOfflineRegister = async (data) => {
    let certificate_number = ''
    let date_of_passing_test = null
    let cpe_certificate_number = ''
    let date_of_cpe_from = null
    let date_of_cpe_to = null
    let application_reference_no = ''
    let validity_from = moment().format('YYYY-MM-DD');
    let validity_to = moment(validity_from, 'YYYY-MM-DD').add(3, 'years');
    let pendingres = await pool.query(`select * from amfi_distributer_master_pending where "pan_no" =$1`, [data.pan_no])

    if (data['application_type'] == 'EUIN') {
        data['category_of_corporation'] = 'EMP'
    }

    if (pendingres['rowCount'] > 0) {
        let res = await pool.query(`update amfi_distributer_master_pending set "mobile_no"=$2,"email_id"=$3,"application_type"=$4,"modified_by"=$5, "modified_date"=$6,"first_name"=$7,"last_name"=$8,"category_of_corporation"=$9 where  "pan_no"=$1 returning "id"`, [data['pan_no'], data['mobile_no'], data['email_id'], data['application_type'], data['user_id'], 'now()', data['first_name'], data['last_name'], data['category_of_corporation']])
        if (res['rowCount'] > 0) {

            if (data['application_type'] == 'ARN') {
                await pool.query(`update amfi_corporate_master_pending set "modified_by"=$1, "modified_date"=$2 where "distributer_master_id"=$3`, [data['user_id'], 'now()', res['rows'][0]['id']]
                )
            }
            return res['rows'][0];
        }

    }
    else {

        // let select_counter = await pool.query(`select * from amfi_counter`)
        // if (select_counter['rowCount'] > 0) {
        //     let applicount = select_counter['rows'][0]['application_reference_count'] + 1
        //     application_reference_no = 'APP-REF' + applicount
        //     await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
        // }
        application_reference_no = await helper.generateApplicationNumber()

        //  if (data['application_type'] == 'ARN') {
        let coporate_res = await pool.query(`select "exam_code" from tbl_amfi_category_master where "category_code"=$1`, [data.category_of_corporation])

        if (coporate_res['rowCount'] > 0) {
            let nism_res = await pool.query(`select  to_char("nism_certificate_date",'YYYY-MM-DD') as date_of_passing_test,"nism_certificate_no" as certificate_number,to_char("validity_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("validity_to",'YYYY-MM-DD') AS date_of_cpe_to  from tbl_user_nism_details  where "nism_category"=$1 and "pan_no"=$2 order by "created_date" desc`, [coporate_res['rows'][0]['exam_code'], data['pan_no']])

            if (nism_res['rowCount'] > 0) {
                date_of_passing_test = nism_res['rows'][0]['date_of_passing_test']
                certificate_number = nism_res['rows'][0]['certificate_number']
                validity_from = nism_res['rows'][0]['date_of_cpe_from']
                validity_to = nism_res['rows'][0]['date_of_cpe_to']
            }
        }
        //}

        let res = await pool.query(`INSERT INTO amfi_distributer_master_pending("pan_no","mobile_no","email_id","application_type","distributer_master_status","created_by",  "modified_by", "modified_date","certificate_number","date_of_passing_test","cpe_certificate_number","date_of_cpe_from","date_of_cpe_to","first_name","last_name","application_reference_no","registration_type","category_of_corporation","validity_from", "validity_to")VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20) RETURNING "id","application_reference_no"`, [data['pan_no'], data['mobile_no'], data['email_id'], data['application_type'], 'Pending', null, null, 'now()', certificate_number, date_of_passing_test, cpe_certificate_number, date_of_cpe_from, date_of_cpe_to, data['first_name'], data['last_name'], application_reference_no, 'OFFLINE', data['category_of_corporation'], validity_from, validity_to])

        if (res['rowCount'] > 0) {

            let req_type = '';
            if (data['application_type'] == 'ARN') {
                req_type = 'ARN_REG'
                await pool.query(`INSERT INTO amfi_corporate_master_pending( "pan_no","corporate_master_status", "created_by", "modified_by", "modified_date","distributer_master_id")VALUES($1,$2,$3,$4,$5,$6)`, [data['pan_no'], 'Pending', null, null, 'now()', res['rows'][0]['id']]
                )
            }
            else {
                req_type = 'EUIN_REG'
            }
            let reqData = {
                "pan_no": data['pan_no'],
                "application_reference_no": application_reference_no,
                "req_type": req_type,
                "appl_uploads": '',
                "req_status": 'Pending',
                "source": 'OFFLINE',
                "user_id": data['user_id']
            }
            await insertRegRenHistory(reqData);
            return res['rows'][0];
        }
    }
    return null;
}

getDocumentCheckListByType = async (data) => {
    let res = await pool.query(`select  "document_checkList" from tbl_amfi_category_master where "category_code"=$1`, [data.application_typecd])

    if (res['rowCount'] > 0) {
        let document_checkList = res['rows'][0]['document_checkList'].split(',')
        return document_checkList;
    }
    return null;
}
loginFO = async (data) => {
    let res = await pool.query(`select "user_id","user_name","first_login" from amfi_user_login where "user_name"=$1 and "password"=$2 and "user_profile"='FO'`, [data.user_name, data.password])

    if (res['rowCount'] > 0) {
        if ('systemCode' in data) {
            await pool.query(`delete from amfi_user_session where "user_id"=$1 and "user_name"=$2`, [res['rows'][0]['user_id'], data.user_name])
            await pool.query(`INSERT INTO amfi_user_session
                ( user_id, user_name, uuid)
                VALUES( $1,$2,$3)`, [res['rows'][0]['user_id'], data.user_name, data.systemCode])
        }
        await pool.query(`update amfi_user_login set "last_login_datetime"=$1 where "user_id"=$2`, ['now()', res['rows'][0]['user_id']])
        return res['rows'];
    }
    return null;
}

getOfflineRegisterDataById = async (data) => {
    let res = await pool.query(`select  "id","first_name","last_name","application_reference_no","pan_no","mobile_no","email_id","arn_number","euin_number" from amfi_distributer_master_pending where id=$1`, [data.id])

    if (res['rowCount'] > 0) {

        let cor_res = await pool.query(`select B."category_description",B."category_code" from amfi_distributer_master_pending A,tbl_amfi_category_master B where A."id"= $1 and B."category_code"=A."category_of_corporation"`, [data.id])

        if (cor_res['rowCount'] > 0) {
            res['rows'][0].category_description = cor_res['rows'][0]['category_description'];
            res['rows'][0].category_code = cor_res['rows'][0]['category_code'];
        }

        return res['rows'];
    }

    return null;
}

submitOfflineRegister = async (data) => {
    // let buff = await helper.base64ToThumbnail(data['photo_filepath']);
    // let res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
    //     "document_checklist"=$3,"photo_filepath"=$4,"signature_filepath"=$5,"address_proof_filepath"=$6,"nism_certificate_filepath"=$7,"kyd_acknowledge_filepath"=$8,"current_action"=$10,"modified_date"=$2, "modified_by"=$9,"photo_thumbnail"=$11,"current_action_code"=$12 where "id"=$1 returning "application_reference_no"`, [data['id'], 'now()', data['document_checkList'].toString(), data['photo_filepath'], data['signature_filepath'], data['address_proof_filepath'], data['nism_certificate_filepath'], data['kyd_acknowledge_filepath'], data['user_id'], "Start Entry", buff, 'START_ENTRY'])
    let buff = null;
    let photo_filepath = null;
    let signature_filepath = null;
    // if ('photo_filepath' in data) {
    //     photo_filepath = data['photo_filepath'];
    //     buff = await helper.base64ToThumbnail(data['photo_filepath']);
    // }
    // if ('signature_filepath' in data) {
    //     signature_filepath = data['signature_filepath']
    // }


    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
     "document_checklist"=$3,"current_action"=$5,"modified_date"=$2, "modified_by"=$4,"current_action_code"=$6,"single_merged_doc"=$7,"photo_filepath"=$8,"signature_filepath"=$9,"photo_thumbnail"=$10 where "id"=$1 returning "application_reference_no","pan_no"`, [data['id'], 'now()', data['document_checkList'].toString(), data['user_id'], "Start Entry", 'START_ENTRY', data['single_merged_doc'], photo_filepath, signature_filepath, buff])


    if (res['rowCount'] > 0) {
        let reqData = {
            "pan_no": res['rows'][0]['pan_no'],
            "application_reference_no": res['rows'][0]['application_reference_no'],
            "req_status": "Start Entry",
            "user_id": data['user_id'],
            "appl_uploads": data['single_merged_doc']
        }
        await updateRegRenHistory(reqData)
        return res['rows'];
    }

    return null;
}

getAllARNList = async (data) => {
    // let res = await pool.query(`select "id","application_reference_no","pan_no","application_type","priority","current_action" from amfi_distributer_master_pending where "kyd_source"='DOCUMENT' and "nigo"=false and "renewal_type"=$1 and ("current_action"='Start Entry'or "current_action"='Pending' or ("current_action"='Assigned' and "fo2_verified"=0))`, [data.type])

    let res = await pool.query(`select "id","application_reference_no","pan_no","application_type","priority","current_action" from amfi_distributer_master_pending where  "kyd_source"='DOCUMENT' and "nigo"=false and "renewal_type"=$1 and ("current_action_code"='PENDING' or "current_action_code"='START_ENTRY' OR "current_action_code"='ASSIGNED_BO1')`, [data.type])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}
updatePriority = async (data) => {
    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
"modified_date"=$2, "modified_by"=$3,"priority"=$4 where "id"=$1 returning "id"`, [data['id'], 'now()', data['user_id'], data['priority'].toUpperCase()])

    if (res['rowCount'] > 0) {
        return res['rows'][0]['id'];
    }

    return null;
}
updateFo1Assign = async (data) => {
    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
"modified_date"=$2, "modified_by"=$3,"current_action"=$4,"fo1_verified"=$5,"current_action_code"=$6 where "id"=$1 returning "id","pan_no","application_reference_no"`, [data['id'], 'now()', data['user_id'], "Assigned", data['user_id'], 'ASSIGNED_BO1'])

    if (res['rowCount'] > 0) {

        let reqData = {
            "pan_no": res['rows'][0]['pan_no'],
            "application_reference_no": res['rows'][0]['application_reference_no'],
            "req_status": "Assigned",
            "user_id": data['user_id'],
        }
        await updateRegRenHistory(reqData);
        return res['rows'][0]['id'];
    }

    return null;
}

getOfflineApplicantDatasById = async (data) => {
    let res = await pool.query(`select "id","pan_no","first_name","middle_name","last_name","gender",to_char("date_of_birth",'YYYY-MM-DD') AS date_of_birth,"gstn","whether_kyd_Compliant","certificate_number",to_char("date_of_passing_test",'YYYY-MM-DD') AS date_of_passing_test,"cpe_certificate_number",to_char("date_of_cpe_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("date_of_cpe_to",'YYYY-MM-DD') as date_of_cpe_to,address1,address2,address3,city,pincode,state,telephone_number,"qualification","university","year_of_passing" ,"name_of_bank","branch","account_Number","micr","account_type","dd_cheque_number",to_char("dd_cheque_date",'YYYY-MM-DD') AS dd_cheque_date,"amount","drawn_on_bank_branch","document_checklist" AS checklist,"ifsc",to_char("date_of_appointment",'YYYY-MM-DD') as date_of_appointment,"arn_id" as arn_of_organisation,"name_of_organisation","designation","registration_type","application_reference_no","arn_number","euin_number",to_char("validity_to",'YYYY-MM-DD') as validity_to,category_of_corporation,"type_of_distributor","country","utr_no",email_id,single_merged_doc,photo_filepath,signature_filepath,photo_thumbnail from amfi_distributer_master_pending where id=$1`, [data.id])

    if (res['rowCount'] > 0) {
        let corp_res = await pool.query(`select name_of_prop_firm,new_cadre_category,name_of_group_company,structure_of_corporate,countries_proposed_for_distribution,list_of_activities_other_than_mf_distribution,group_company_has_arn,name_of_signatory,mobile_no_of_signatory,designation_of_signatory,corporation_category,name_of_the_corporate,engaged_as_insurance_agent,no_of_proposed_branches_for_sales,no_of_proposed_employees_for_sales,no_of_certified_employees,no_of_employess_under_coporate,arn_of_group_company,"whether_group_company_has_arn"  from amfi_corporate_master_pending where distributer_master_id=$1`, [data.id])
        if (corp_res['rowCount'] > 0) {
            res['rows'][0]['name_of_prop_firm'] = corp_res['rows'][0]['name_of_prop_firm'];
            res['rows'][0]['new_cadre_category'] = corp_res['rows'][0]['new_cadre_category'];
            res['rows'][0]['name_of_group_company'] = corp_res['rows'][0]['name_of_group_company']
            res['rows'][0]['structure_of_corporate'] = corp_res['rows'][0]['structure_of_corporate']
            res['rows'][0]['countries_proposed_for_distribution'] = corp_res['rows'][0]['countries_proposed_for_distribution']
            res['rows'][0]['list_of_activities_other_than_mf_distribution'] = corp_res['rows'][0]['list_of_activities_other_than_mf_distribution']
            res['rows'][0]['group_company_has_arn'] = corp_res['rows'][0]['group_company_has_arn']
            res['rows'][0]['name_of_signatory'] = corp_res['rows'][0]['name_of_signatory']
            res['rows'][0]['designation_of_signatory'] = corp_res['rows'][0]['designation_of_signatory']
            res['rows'][0]['mobile_no_of_signatory'] = corp_res['rows'][0]['mobile_no_of_signatory']
            res['rows'][0]['corporation_category'] = corp_res['rows'][0]['corporation_category']
            res['rows'][0]['name_of_the_corporate'] = corp_res['rows'][0]['name_of_the_corporate']
            res['rows'][0]['engaged_as_insurance_agent'] = corp_res['rows'][0]['engaged_as_insurance_agent']
            res['rows'][0]['no_of_proposed_branches_for_sales'] = corp_res['rows'][0]['no_of_proposed_branches_for_sales'];
            res['rows'][0]['no_of_proposed_employees_for_sales'] = corp_res['rows'][0]['no_of_proposed_employees_for_sales'];
            res['rows'][0]['no_of_certified_employees'] = corp_res['rows'][0]['no_of_certified_employees'];
            res['rows'][0]['no_of_employess_under_coporate'] = corp_res['rows'][0]['no_of_employess_under_coporate']
            res['rows'][0]['arn_of_group_company'] = corp_res['rows'][0]['arn_of_group_company']
            res['rows'][0]['whether_group_company_has_arn'] = corp_res['rows'][0]['whether_group_company_has_arn']
        }
        if (res['rows'][0]['checklist'] != null) {
            res['rows'][0]['document_checkList'] = res['rows'][0]['checklist'].split(',')
        }
        res['rows'][0]['kyd_list'] = [];
        let kyd_res = await pool.query(`select *, to_char("dob",'YYYY-MM-DD')as dob from tbl_kyd_details where pan_no =$1`, [res['rows'][0]['pan_no']])

        if (kyd_res['rowCount'] > 0) {
            res['rows'][0]['kyd_list'] = kyd_res['rows']
        }

        return res['rows'];
    }
    return null;
}

submitForAuthorisation = async (data, current_action, current_action_code) => {
    await helper.saveErrorAuditLogs(data, current_action, 'SUBMIT1')
    let document_checklist = null;
    let engaged_as_insurance_agent = '';
    let registered_insurance_company = '';
    let whether_group_company_has_arn = '';
    let name_of_group_company = '';
    let arn_of_group_company = '';
    let no_of_proposed_branches_for_sales = null;
    let no_of_certified_employees = null;
    let no_of_employess_under_coporate = null;
    let name_of_signatory = null;
    let designation_of_signatory = '';
    let mobile_no_of_signatory = '';
    let structure_of_corporate = '';
    let countries_proposed_for_distribution = '';
    let list_of_activities_other_than_mf_distribution = '';
    let group_company_has_arn = '';
    let name_of_prop_firm = '';
    let new_cadre_category = '';
    let type_of_distributor = '';
    let corporation_category = '';
    let name_of_the_corporate = '';
    let country = '';
    let utr_no = '';
    let email_id = '';
    let no_of_proposed_employees_for_sales = null;
    if (data['document_checkList'] !== null && data['document_checkList'] !== undefined && data['document_checkList'] !== '') {
        document_checklist = data['document_checkList'].toString()
    }

    if ('type_of_distributor' in data) {
        type_of_distributor = data['type_of_distributor'];
    }
    if ('country' in data) {
        country = data['country'];
    }

    if ('utr_no' in data) {
        utr_no = data['utr_no'];
    }
    if ('email_id' in data) {
        email_id = data['email_id'];

    }
    let buff = null;
    let photo_filepath = null;
    let signature_filepath = null;
    if ('photo_filepath' in data) {
        photo_filepath = data['photo_filepath'];
        buff = await helper.base64ToThumbnail(data['photo_filepath']);
    }
    if ('signature_filepath' in data) {
        signature_filepath = data['signature_filepath']
    }

    let res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
"modified_date"=$2, "modified_by"=$3,"current_action"=$4 ,"first_name"=$6,"middle_name"=$7,"last_name"=$8,"gender"=$9 ,"date_of_birth"=$10,"gstn"=$11,"whether_kyd_Compliant"=$12,"certificate_number"=$13,"date_of_passing_test"=$14,"cpe_certificate_number"=$15,"date_of_cpe_from"=$16,"date_of_cpe_to"=$17,"address1"=$18,"address2"=$19,"address3"=$20,"city"=$21,"pincode"=$22,"state"=$23,"telephone_number"=$24,"qualification"=$25,"university"=$26,"year_of_passing"=$27,"name_of_bank"=$28,"branch"=$29,"account_Number"=$30,"micr"=$31 ,"account_type"=$32,"dd_cheque_number"=$33,"dd_cheque_date"=$34,"amount"=$35,"drawn_on_bank_branch"=$36,"document_checklist"=$37,"current_action_code"=$38,"ifsc"=$39,"arn_id"=$40,"date_of_appointment"=$41,"name_of_organisation"=$42,"designation"=$43,"type_of_distributor"=$44,"country"=$45,"utr_no"=$46,"email_id"=$47,"single_merged_doc"=$48,"photo_filepath"=$49,"signature_filepath"=$50,"photo_thumbnail"=$51 where "id"=$1  and "pan_no"=$5 returning "id","application_type","application_reference_no"`, [data['id'], 'now()', data['user_id'], current_action, data['pan_no'], data['first_name'], data['middle_name'], data['last_name'], data['gender'], data['date_of_birth'], data['gstn'], data['whether_kyd_Compliant'], data['certificate_number'], data['date_of_passing_test'], data['cpe_certificate_number'], data['date_of_cpe_from'], data['date_of_cpe_to'], data['address1'], data['address2'], data['address3'], data['city'], data['pincode'], data['state'], data['telephone_number'], data['qualification'], data['university'], data['year_of_passing'], data['name_of_bank'], data['branch'], data['account_Number'], data['micr'], data['account_type'], data['dd_cheque_number'], data['dd_cheque_date'], data['amount'], data['drawn_on_bank_branch'], document_checklist, current_action_code, data['ifsc'], data['arn_of_organisation'], data['date_of_appointment'], data['name_of_organisation'], data['designation'], type_of_distributor, country, utr_no, email_id, data['single_merged_doc'], photo_filepath, signature_filepath, buff])

    if (res['rowCount'] > 0) {
        let application_type = res['rows'][0]['application_type']

        if (application_type == 'ARN') {

            if ('name_of_prop_firm' in data) {
                name_of_prop_firm = data['name_of_prop_firm'];
            }
            if ('new_cadre_category' in data) {
                new_cadre_category = data['new_cadre_category'];
            }

            if ('name_of_group_company' in data) {
                name_of_group_company = data['name_of_group_company']
            }
            if ('structure_of_corporate' in data) {
                structure_of_corporate = data['structure_of_corporate']
            }

            if ('countries_proposed_for_distribution' in data) {
                countries_proposed_for_distribution = data['countries_proposed_for_distribution']
            }

            if ('list_of_activities_other_than_mf_distribution' in data) {
                list_of_activities_other_than_mf_distribution = data['list_of_activities_other_than_mf_distribution']
            }

            if ('whether_group_company_has_arn' in data) {
                whether_group_company_has_arn = data['whether_group_company_has_arn']
            }

            if ('name_of_signatory' in data) {
                name_of_signatory = data['name_of_signatory']
            }

            if ('designation_of_signatory' in data) {
                designation_of_signatory = data['designation_of_signatory']
            }

            if ('mobile_no_of_signatory' in data) {
                mobile_no_of_signatory = data['mobile_no_of_signatory']
            }

            if ('corporation_category' in data) {
                corporation_category = data['corporation_category'];
            }

            if ('name_of_the_corporate' in data) {
                name_of_the_corporate = data['name_of_the_corporate'];
            }

            if ('engaged_as_insurance_agent' in data) {
                engaged_as_insurance_agent = data['engaged_as_insurance_agent'];

            }

            if ('no_of_proposed_branches_for_sales' in data) {
                no_of_proposed_branches_for_sales = data['no_of_proposed_branches_for_sales'];
            }

            if ('no_of_proposed_employees_for_sales' in data) {
                no_of_proposed_employees_for_sales = data['no_of_proposed_employees_for_sales'];
            }

            if ('no_of_certified_employees' in data) {
                no_of_certified_employees = data['no_of_certified_employees'];
            }

            if ('no_of_employess_under_coporate' in data) {
                no_of_employess_under_coporate = data['no_of_employess_under_coporate'];
            }

            if ('arn_of_group_company' in data) {
                arn_of_group_company = data['arn_of_group_company'];
            }


            let corp_res = await pool.query(`UPDATE amfi_corporate_master_pending
            SET engaged_as_insurance_agent=$2, registered_insurance_company=$3, "whether_group_company_has_arn"=$4, name_of_group_company=$5, arn_of_group_company=$6, no_of_proposed_branches_for_sales=$7, "no_of_proposed_employees_for_sales"=$8, no_of_certified_employees=$9, no_of_employess_under_coporate=$10, name_of_signatory=$11, designation_of_signatory=$12, mobile_no_of_signatory=$13, structure_of_corporate=$14, countries_proposed_for_distribution=$15, list_of_activities_other_than_mf_distribution=$16, group_company_has_arn=$17, name_of_prop_firm=$18, new_cadre_category=$19,"corporation_category"=$20,"name_of_the_corporate"=$21
            WHERE "distributer_master_id"=$1;`, [data['id'], engaged_as_insurance_agent, registered_insurance_company, whether_group_company_has_arn, name_of_group_company, arn_of_group_company, no_of_proposed_branches_for_sales, no_of_proposed_employees_for_sales, no_of_certified_employees, no_of_employess_under_coporate, name_of_signatory, designation_of_signatory, mobile_no_of_signatory, structure_of_corporate, countries_proposed_for_distribution, list_of_activities_other_than_mf_distribution, group_company_has_arn, name_of_prop_firm, new_cadre_category, corporation_category, name_of_the_corporate])
        }

        if ('kyd_list' in data) {
            // data['kyd_list'].forEach(element => {

            for (let i = 0; i < data['kyd_list'].length; i++) {
                let element = data['kyd_list'][i]
                await pool.query(`INSERT INTO tbl_kyd_details
              (pan_no, arn_id, distributer_name, fathers_name, kyd_pan_no, applicant_type, gender, dob, door_flat_no, appartment, street_name, city, pincode, state, telephone_no, bank_name, branch, account_number, micr_neft, account_type, empanelled, occupation) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)`, [data['pan_no'], element['arn_id'], element['distributer_name'], element['fathers_name'], element['kyd_pan_no'], element['applicant_type'], element['gender'], element['dob'], element['door_flat_no'], element['appartment'], element['street_name'], element['city'], element['pincode'], element['state'], element['telephone_no'], element['bank_name'], element['branch'], element['account_number'], element['micr_neft'], element['account_type'], element['empanelled'], element['occupation']]);

                await pool.query(`INSERT INTO tbl_kyd_details_history
              (pan_no, arn_id, distributer_name, fathers_name, kyd_pan_no, applicant_type, gender, dob, door_flat_no, appartment, street_name, city, pincode, state, telephone_no, bank_name, branch, account_number, micr_neft, account_type, empanelled, occupation) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)`, [data['pan_no'], element['arn_id'], element['distributer_name'], element['fathers_name'], element['kyd_pan_no'], element['applicant_type'], element['gender'], element['dob'], element['door_flat_no'], element['appartment'], element['street_name'], element['city'], element['pincode'], element['state'], element['telephone_no'], element['bank_name'], element['branch'], element['account_number'], element['micr_neft'], element['account_type'], element['empanelled'], element['occupation']]);

                // });
            }
        }
        await helper.saveErrorAuditLogs(data, res, 'SUBMIT2')

        let reqData = {
            "pan_no": data['pan_no'],
            "application_reference_no": res['rows'][0]['application_reference_no'],
            "req_status": current_action,
            "user_id": data['user_id'],
            "appl_uploads": data['single_merged_doc']
        }
        await updateRegRenHistory(reqData);

        return res['rows'][0]['id'];
    }

    return null;
}

updateFo2Assign = async (data) => {
    let resdata = await pool.query(`select "fo1_verified" from amfi_distributer_master_pending where "id"=$1`, [data['id']])
    if (resdata['rowCount'] > 0) {
        if (resdata['rows'][0]['fo1_verified'] == data.user_id) {
            return false;
        }
        else {
            let res = await pool.query(`UPDATE amfi_distributer_master_pending SET  "modified_date"=$2, "modified_by"=$3,"current_action"=$4,"fo2_verified"=$5,"current_action_code"=$6 where "id"=$1 returning "id","pan_no","application_reference_no"`, [data['id'], 'now()', data['user_id'], "Assigned", data['user_id'], 'ASSIGNED_BO2'])

            if (res['rowCount'] > 0) {
                let reqData = {
                    "pan_no": res['rows'][0]['pan_no'],
                    "application_reference_no": res['rows'][0]['application_reference_no'],
                    "req_status": "Assigned",
                    "user_id": data['user_id'],
                }
                await updateRegRenHistory(reqData);
                return res['rows'][0]['id'];
            }
        }
    }
    return null;
}

getUploadedDocumentById = async (data) => {
    let resObj = {}


    let res = await pool.query(`select "id","single_merged_doc" from amfi_distributer_master_pending where id=$1`, [data.id])

    if (res['rowCount'] > 0) {
        let single_merged_id = res['rows'][0]['single_merged_doc'];

        var file_no = parseInt(single_merged_id) || 0;
        if (file_no > 0) {
            let kyd_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_no])

            if (kyd_res['rowCount'] > 0) {
                resObj['merged_file_acknowledge_filepath'] = file_no;
                let imgBuff = kyd_res['rows'][0]['image'];
                resObj['merged_file_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                resObj['merged_file_filepath_image_type'] = kyd_res['rows'][0]['image_type'];
                resObj['merged_file_filename'] = kyd_res['rows'][0]['file_name'];
            }
        }
        return resObj;

    }
    return null;
    // let res = await pool.query(`select "id","address_proof_filepath","nism_certificate_filepath","photo_filepath","signature_filepath",kyd_acknowledge_filepath from amfi_distributer_master_pending where id=$1`, [data.id])

    // if (res['rowCount'] > 0) {
    //     let address_id = res['rows'][0]['address_proof_filepath'];
    //     let nism_id = res['rows'][0]['nism_certificate_filepath'];
    //     let photo_id = res['rows'][0]['photo_filepath'];
    //     let sign_id = res['rows'][0]['signature_filepath'];
    //     let kyd_id = res['rows'][0]['kyd_acknowledge_filepath']


    //     var num1 = parseInt(kyd_id) || 0;
    //     if (num1 > 0) {
    //         let kyd_res = await pool.query(`select * from amfi_file where "id"=$1 
    //         `, [num1])

    //         if (kyd_res['rowCount'] > 0) {
    //             resObj['kyd_acknowledge_filepath'] = num1;
    //             let imgBuff = kyd_res['rows'][0]['image'];
    //             resObj['kyd_acknowledge_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
    //             resObj['kyd_acknowledge_filepath_image_type'] = kyd_res['rows'][0]['image_type'];
    //             resObj['kyd_acknowledge_filename'] = kyd_res['rows'][0]['file_name'];

    //         }
    //     }
    //     var num2 = parseInt(address_id) || 0;
    //     if (num2 > 0) {

    //         let addr_res = await pool.query(`select * from amfi_file where "id"=$1 
    //         `, [num2])

    //         if (addr_res['rowCount'] > 0) {

    //             let imgBuff = addr_res['rows'][0]['image'];
    //             resObj['address_proof_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
    //             resObj['address_proof_filepath_image_type'] = addr_res['rows'][0]['image_type'];
    //             resObj['address_proof_filename'] = addr_res['rows'][0]['file_name'];

    //             //                resObj['address_proof_filepath_base64'] = addr_res['rows'][0]['image'];
    //             resObj['address_proof_filepath'] = num2;


    //         }
    //     }
    //     var num3 = parseInt(nism_id) || 0;
    //     if (num3 > 0) {
    //         let nism_res = await pool.query(`select * from amfi_file where "id"=$1 
    //         `, [num3])
    //         if (nism_res['rowCount'] > 0) {
    //             let imgBuff = nism_res['rows'][0]['image'];
    //             resObj['nism_certificate_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
    //             resObj['nism_certificate_filepath_image_type'] = nism_res['rows'][0]['image_type'];
    //             resObj['nism_certificate_filepname'] = nism_res['rows'][0]['file_name'];
    //             //                resObj['nism_certificate_filepath_base64'] = nism_res['rows'][0]['image']
    //             resObj['nism_certificate_filepath'] = num3;
    //         }
    //     }
    //     var num4 = parseInt(photo_id) || 0;
    //     if (num4 > 0) {
    //         let photo_res = await pool.query(`select * from amfi_file where "id"=$1 
    //         `, [num4])
    //         if (photo_res['rowCount'] > 0) {
    //             resObj['photo_filepath'] = num4;

    //             let imgBuff = photo_res['rows'][0]['image'];
    //             resObj['photo_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
    //             resObj['photo_filepath_image_type'] = photo_res['rows'][0]['image_type'];
    //             resObj['photo_filename'] = photo_res['rows'][0]['file_name'];

    //             //                resObj['photo_filepath_base64'] = photo_res['rows'][0]['image'];

    //         }
    //     }

    //     var num5 = parseInt(sign_id) || 0;
    //     if (num5 > 0) {
    //         let sign_res = await pool.query(`select * from amfi_file where "id"=$1 
    //         `, [num5])
    //         if (sign_res['rowCount'] > 0) {
    //             resObj['signature_filepath'] = num5
    //             let imgBuff = sign_res['rows'][0]['image'];
    //             resObj['signature_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
    //             resObj['signature_filepath_image_type'] = sign_res['rows'][0]['image_type'];
    //             resObj['signature_filename'] = sign_res['rows'][0]['file_name'];

    //             //                resObj['signature_filepath_base64'] = sign_res['rows'][0]['image']

    //         }
    //     }
    //     return resObj;
    // }

}

loginBO = async (data) => {
    let res = await pool.query(`select "user_id","user_name","first_login" from amfi_user_login where "user_name"=$1 and "password"=$2 and "user_profile"='BO'`, [data.user_name, data.password])

    if (res['rowCount'] > 0) {
        if ('systemCode' in data) {
            await pool.query(`delete from amfi_user_session where "user_id"=$1 and "user_name"=$2`, [res['rows'][0]['user_id'], data.user_name])
            await pool.query(`INSERT INTO amfi_user_session
                ( user_id, user_name, uuid)
                VALUES( $1,$2,$3)`, [res['rows'][0]['user_id'], data.user_name, data.systemCode])
        }
        await pool.query(`update amfi_user_login set "last_login_datetime"=$1 where "user_id"=$2`, ['now()', res['rows'][0]['user_id']])
        return res['rows'];
    }
    return null;
}


getAuthorisationList = async (data) => {
    // let res = await pool.query(`select "id","application_reference_no","pan_no","application_type","priority","current_action" from amfi_distributer_master_pending where  "kyd_source"='DOCUMENT' and "nigo"=false and "renewal_type"=$1 and ("current_action"='Authorise' or("current_action"='Assigned' and "fo2_verified"!=0))`, [data.type])

    let res = await pool.query(`select "id","application_reference_no","pan_no","application_type","priority","current_action" from amfi_distributer_master_pending where  "kyd_source"='DOCUMENT' and "nigo"=false and "renewal_type"=$1 and ("current_action_code"='PENDING_AUTHORISE' OR "current_action_code"='AUTHORISE' OR "current_action_code"='ASSIGNED_BO2')`, [data.type])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

rejectRegisterRenewal = async (data) => {
    let pending_res_data = await pool.query(`select *  from amfi_distributer_master_pending where "pan_no"=$1 and  "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])
    if (pending_res_data['rowCount'] > 0) {
        let pending_res = pending_res_data['rows'][0]
        let coporate_res = null;
        if (pending_res['application_type'] == 'ARN') {
            let pending_coporate_res = await pool.query(`select * from amfi_corporate_master_pending where "pan_no" =$1`, [data.pan_no])
            if (pending_coporate_res['rowCount'] > 0) {
                coporate_res = pending_coporate_res['rows'][0]
            }
        }
        let insert_rejected = `INSERT INTO amfi_distributer_master_rejected( first_name, middle_name, last_name, gender, date_of_birth, pan_no, gstn, "whether_kyd_Compliant", certificate_number, date_of_passing_test, address1, address2, address3, city, pincode, state, country, telephone_number, fax, mobile_no, email_id, qualification, university, year_of_passing, name_of_bank, branch, bank_city, "account_Number", ifsc, account_type, micr, dd_cheque_number, dd_cheque_date, amount, drawn_on_bank_branch, signature, place, sign_date, undertaking_consent, kyd_source, cpe_certificate_number, date_of_cpe_from, distributor_category, arn_id, name_of_organisation, utr_no, type_of_distributor, distributer_master_status, created_by, modified_by, modified_date, application_type, date_of_cpe_to, bank_proof_filepath, pancard_filepath, adharcard_filepath, photo_filepath, signature_filepath, registration_type, date_of_appointment, designation, description_of_responsibilities, company_address1, company_address2, company_address3, company_pincode, company_city, company_state, arn_number, euin_number, gst_filepath, application_reference_no, document_checklist, address_proof_filepath, nism_certificate_filepath, kyd_acknowledge_filepath, priority, current_action, fo1_verified, fo2_verified, gst_verified, gst_verified_by, renewal_type, reject_reason,category_of_corporation,single_merged_doc)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42,$43,$44,$45,$46,$47,$48,$49,$50,$51,$52,$53,$54,$55,$56,$57,$58,$59,$60,$61,$62,$63,$64,$65,$66,$67,$68,$69,$70,$71,$72,$73,$74,$75,$76,$77,$78,$79,$80,$81,$82,$83,$84,$85,$86) returning "id"`

        let dis_ins = await pool.query(insert_rejected, [pending_res['first_name'], pending_res['middle_name'], pending_res['last_name'], pending_res['gender'], pending_res['date_of_birth'], pending_res['pan_no'], pending_res['gstn'], pending_res['whether_kyd_Compliant'], pending_res['certificate_number'], pending_res['date_of_passing_test'], pending_res['address1'], pending_res['address2'], pending_res['address3'], pending_res['city'], pending_res['pincode'], pending_res['state'], pending_res['country'], pending_res['telephone_number'], pending_res['fax'], pending_res['mobile_no'], pending_res['email_id'], pending_res['qualification'], pending_res['university'], pending_res['year_of_passing'], pending_res['name_of_bank'], pending_res['branch'], pending_res['bank_city'], pending_res['account_Number'], pending_res['ifsc'], pending_res['account_type'], pending_res['micr'], pending_res['dd_cheque_number'], pending_res['dd_cheque_date'], pending_res['amount'], pending_res['drawn_on_bank_branch'], pending_res['signature'], pending_res['place'], pending_res['sign_date'], pending_res['undertaking_consent'], pending_res['kyd_source'], pending_res['cpe_certificate_number'], pending_res['date_of_cpe_from'], pending_res['distributor_category'], pending_res['arn_id'], pending_res['name_of_organisation'], pending_res['utr_no'], pending_res['type_of_distributor'], 'Rejected', data.user_id, data.user_id, 'now()', pending_res['application_type'], pending_res['date_of_cpe_to'], pending_res['bank_proof_filepath'], pending_res['pancard_filepath'], pending_res['adharcard_filepath'], pending_res['photo_filepath'], pending_res['signature_filepath'], pending_res['registration_type'], pending_res['date_of_appointment'], pending_res['designation'], pending_res['description_of_responsibilities'], pending_res['company_address1'], pending_res['company_address2'], pending_res['company_address3'], pending_res['company_pincode'], pending_res['company_city'], pending_res['company_state'], pending_res['arn_number'], pending_res['euin_number'], pending_res['gst_filepath'], pending_res['application_reference_no'], pending_res['document_checklist'], pending_res['address_proof_filepath'], pending_res['nism_certificate_filepath'], pending_res['kyd_acknowledge_filepath'], pending_res['priority'], pending_res['current_action'], pending_res['fo1_verified'], pending_res['fo2_verified'], pending_res['gst_verified'], pending_res['gst_verified_by'], pending_res['renewal_type'], data.reject_reason, pending_res['category_of_corporation'], pending_res['single_merged_doc']])


        if (dis_ins['rowCount'] > 0) {

            if (coporate_res != null) {
                let insert_cop_reject = await pool.query(`INSERT INTO amfi_corporate_master_rejected(pan_no, engaged_as_insurance_agent, registered_insurance_company, "whether_group_company_has_arn", name_of_group_company, "arn_of_group_company", no_of_proposed_branches_for_sales, "no_of_proposed_employees_for_sales",no_of_certified_employees, no_of_employess_under_coporate, name_of_signatory, designation_of_signatory, "mobile_no_of_signatory", structure_of_corporate, countries_proposed_for_distribution, list_of_activities_other_than_mf_distribution, group_company_has_arn, "name_of_prop_firm", corporate_master_status, created_by, modified_by, modified_date, distributer_master_id)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23)`, [pending_res['pan_no'], coporate_res['engaged_as_insurance_agent'], coporate_res['registered_insurance_company'], coporate_res['whether_group_company_has_arn'], coporate_res['name_of_group_company'], coporate_res['ARN_of_group_company'], coporate_res['no_of_proposed_branches_for_sales'], coporate_res['no_of_proposed_employees_for_sales'], coporate_res['no_of_certified_employees'], coporate_res['no_of_employess_under_coporate'], coporate_res['name_of_signatory'], coporate_res['designation_of_signatory'], coporate_res['mobile_no_of_signatory'], coporate_res['structure_of_corporate'], coporate_res['countries_proposed_for_distribution'], coporate_res['list_of_activities_other_than_mf_distribution'], coporate_res['group_company_has_arn'], coporate_res['name_of_prop_firm'], 'Rejected', data.user_id, data.user_id, 'now()', dis_ins['rows'][0]['id']])
            }
            await pool.query(`delete from amfi_corporate_master_pending where "pan_no"=$1`, [data.pan_no]);
            await pool.query(`delete from amfi_distributer_master_pending where "pan_no"=$1 and  "application_reference_no"=$2`, [data.pan_no, data.application_reference_no]);

            let reqData = {
                "pan_no": data.pan_no,
                "application_reference_no": data.application_reference_no,
                "req_status": "Rejected",
                "user_id": data['user_id'],
            }
            await updateRegRenHistory(reqData);
            return dis_ins['rows'][0]['id']
        }
        return null;
    }
}

saveOfflineRenewal = async (data) => {
    let certificate_number = ''
    let date_of_passing_test = null
    let cpe_certificate_number = ''
    let date_of_cpe_from = null
    let date_of_cpe_to = null
    let application_reference_no = ''
    let category_of_corporation = ''
    let validity_from = null;
    let validity_to = null;
    if ('validity_from' in data) {
        validity_from = data['validity_from'];
    }
    if ('validity_to' in data) {
        validity_to = data['validity_to'];
    }
    let pendingres = await pool.query(`select * from amfi_distributer_master_pending where "pan_no" =$1`, [data.pan_no])

    if (pendingres['rowCount'] > 0) {
        let res = await pool.query(`update amfi_distributer_master_pending set "mobile_no"=$2,"email_id"=$3,"application_type"=$4,"modified_by"=$5, "modified_date"=$6 where  "pan_no"=$1 returning "id"`, [data['pan_no'], data['mobile_no'], data['email_id'], data['renewal_type'], data['user_id'], 'now()'])

        if (res['rowCount'] > 0) {
            return res['rows'][0];
        }

    }
    else {
        // let select_counter = await pool.query(`select * from amfi_counter`)
        // if (select_counter['rowCount'] > 0) {
        //     let applicount = select_counter['rows'][0]['application_reference_count'] + 1
        //     application_reference_no = 'APP-REF' + applicount
        //     await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
        // }
        application_reference_no = await helper.generateApplicationNumber()

        let distribute_arroveres = await pool.query(`select "id","first_name","middle_name","last_name","gender",to_char("date_of_birth",'YYYY-MM-DD') as dob,"address1","address2","address3","city","pincode","state","category_of_corporation" from amfi_distributer_master_approved where "pan_no"=$1`, [data.pan_no])

        if (distribute_arroveres['rowCount'] > 0) {
            let distribute_arroveresdata = distribute_arroveres['rows'][0];
            if (data['renewal_type'] == 'ARN') {
                let coperate_approveres = await pool.query(`select "category_of_corporation" from amfi_distributer_master_approved where "id"=$1`, [distribute_arroveresdata['id']])

                if (coperate_approveres['rowCount'] > 0) {
                    category_of_corporation = coperate_approveres['rows'][0]['category_of_corporation']
                    let coporate_res = await pool.query(`select "exam_code" from tbl_amfi_category_master where "category_code"=$1`, [category_of_corporation])
                    if (coporate_res['rowCount'] > 0) {
                        let nism_res = await pool.query(`select  to_char("nism_certificate_date",'YYYY-MM-DD') as date_of_passing_test,"nism_certificate_no" as certificate_number,to_char("validity_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("validity_to",'YYYY-MM-DD') AS date_of_cpe_to  from tbl_user_nism_details  where "nism_category"=$1 and "pan_no"=$2 order by "created_date" desc`, [coporate_res['rows'][0]['exam_code'], data['pan_no']])

                        if (nism_res['rowCount'] > 0) {
                            date_of_passing_test = nism_res['rows'][0]['date_of_passing_test']
                            certificate_number = nism_res['rows'][0]['certificate_number']
                            // validity_from = nism_res['rows'][0]['date_of_cpe_from']
                            // validity_to = nism_res['rows'][0]['date_of_cpe_to']
                        }
                    }
                }
            }
            let res = await pool.query(`INSERT INTO amfi_distributer_master_pending("pan_no","mobile_no","email_id","application_type","distributer_master_status", "modified_date","certificate_number","date_of_passing_test","cpe_certificate_number","date_of_cpe_from","date_of_cpe_to","application_reference_no","registration_type","renewal_type","arn_number","euin_number","first_name","middle_name","last_name","gender","date_of_birth","address1","address2","address3","city","pincode","state","category_of_corporation","validity_from", "validity_to")VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30) RETURNING "id","application_reference_no"`, [data['pan_no'], data['mobile_no'], data['email_id'], data['renewal_type'], 'Pending', 'now()', certificate_number, date_of_passing_test, cpe_certificate_number, date_of_cpe_from, date_of_cpe_to, application_reference_no, 'OFFLINE', 'RENEWAL', data.arn_number, data.euin_number, distribute_arroveresdata['first_name'], distribute_arroveresdata['middle_name'], distribute_arroveresdata['last_name'], distribute_arroveresdata['gender'], distribute_arroveresdata['dob'], distribute_arroveresdata['address1'], distribute_arroveresdata['address2'], distribute_arroveresdata['address3'], distribute_arroveresdata['city'], distribute_arroveresdata['pincode'], distribute_arroveresdata['state'], distribute_arroveresdata['category_of_corporation'], validity_from, validity_to])

            if (res['rowCount'] > 0) {
                let req_type = '';
                if (data['renewal_type'] == 'ARN') {
                    req_type = 'ARN_REN';
                    await pool.query(`INSERT INTO amfi_corporate_master_pending( "pan_no","corporate_master_status", "modified_date","distributer_master_id")VALUES($1,$2,$3,$4)`, [data['pan_no'], 'Pending', 'now()', res['rows'][0]['id']]
                    )
                }
                else {
                    req_type = 'EUIN_REN';
                }

                let reqData = {
                    "pan_no": data['pan_no'],
                    "application_reference_no": application_reference_no,
                    "req_type": req_type,
                    "appl_uploads": '',
                    "req_status": 'Pending',
                    "source": 'OFFLINE',
                    "user_id": data['user_id']
                }
                await insertRegRenHistory(reqData)
                return res['rows'][0];
            }
        }
    }
    return null;
}

searchByArnNoApproved = async (data) => {
    let res = await pool.query(`select "id","arn_number","euin_number","pan_no" ,"email_id" ,"mobile_no","name_of_organisation","address1","address2","address3" ,"city" ,"state","pincode","first_name" ,"middle_name" ,"last_name" from amfi_distributer_master_approved where "arn_number"=$1`, [data.arn_number])

    if (res['rowCount'] > 0) {
        return res['rows'][0];
    }

    return null;
}

searchByEUINNoApproved = async (data) => {
    let res = await pool.query(`select "id","euin_number","pan_no" ,"email_id" ,"mobile_no","address1","address2","address3" ,"city" ,"state","pincode","first_name" ,"middle_name" ,"last_name","arn_id" from amfi_distributer_master_approved where "euin_number"=$1 and "application_type"='EUIN'`, [data.euin_number])

    if (res['rowCount'] > 0) {
        return res['rows'][0];
    }

    return null;
}

checkUserNameExists = async (data) => {
    let res = await pool.query(`select "user_id","user_name","first_login","user_profile","user_role" from amfi_user_login where "user_name"=$1`, [data.user_name])

    if (res['rowCount'] > 0) {
        return true;
    }
    return false;

}


loginFOBO = async (data) => {
    let res = await pool.query(`select "user_id","user_name","first_login","user_profile","user_role" from amfi_user_login where "user_name"=$1 and "password"=$2`, [data.user_name, data.password])

    if (res['rowCount'] > 0) {
        if (res['rows'][0]['user_id'] != null || res['rows'][0]['user_id'] != '') {
            if ('systemCode' in data) {
                await pool.query(`delete from amfi_user_session where "user_id"=$1 and "user_name"=$2`, [res['rows'][0]['user_id'], data.user_name])
                await pool.query(`INSERT INTO amfi_user_session
                    ( user_id, user_name, uuid)
                    VALUES( $1,$2,$3)`, [res['rows'][0]['user_id'], data.user_name, data.systemCode])
            }
            await pool.query(`update amfi_user_login set "last_login_datetime"=$1 where "user_id"=$2`, ['now()', res['rows'][0]['user_id']])
        }
        return res['rows'];
    }
    return null;
}

getRequestTypes = async (data) => {
    let res = await pool.query(`select "id","req_type","req_desc","category_code","cost","tax%"  from tbl_req_type_master where "status"=true and "req_type"=$1`, [data.request_type])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

getRejectReason = async (data) => {
    let res = await pool.query(`select "id","req_type","rej_code","rej_desc"  from tbl_req_rej_master where "status"=true and "req_type"=$1`, [data.request_type])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

getGender = async (data) => {
    let res = await pool.query(`select "id","req_type","req_code","req_desc"  from tbl_dropdown_master where "status"=true and "req_type"=$1`, [data.request_type])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}
isChangeRequestExists = async (pan_no, req_type) => {
    let changeres = await pool.query(`select * from tbl_chng_req_hist where "pan_no"=$1 and "req_type"=$2 and "status"=true`, [pan_no, req_type])

    if (changeres['rowCount'] > 0) {
        return true;
    }
    return false;
}
saveRequestedUpdate = async (data) => {

    let application_reference_no = ''
    // let select_counter = await pool.query(`select * from amfi_counter`)
    // if (select_counter['rowCount'] > 0) {
    //     let applicount = select_counter['rows'][0]['application_reference_count'] + 1
    //     application_reference_no = 'APP-REF' + applicount
    //     await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
    // }

    let uploaded_file = '';
    if ('uploaded_file' in data) {
        uploaded_file = data['uploaded_file'];
    }

    application_reference_no = await helper.generateApplicationNumber()
    let res = await pool.query(`INSERT INTO tbl_chng_req_hist(
        pan_no, req_type, appl_date, appl_uploads, req_status, key_value_edited, key_value_old, key_value_new, modified_date, application_reference_no,created_by,modified_by,source,"req_status_code") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) returning "id","application_reference_no"`, [data.pan_no, data.req_type, 'now()', uploaded_file, 'Start Entry', '', '', '', 'now()', application_reference_no, data.user_id, data.user_id, 'OFFLINE', 'START_ENTRY'])
    if (res['rowCount'] > 0) {
        let select_data = await pool.query(`select photo_filepath,gstn from amfi_distributer_master_approved where pan_no =$1`, [data.pan_no])

        let old_photofilepath;
        let gstn;
        if (select_data['rowCount'] > 0) {
            old_photofilepath = select_data['rows'][0]['photo_filepath']
            gstn = select_data['rows'][0]['gstn']
        }
        if (data.req_type == 'PH') {
            await pool.query(`update tbl_chng_req_hist set "key_value_edited"='Photo',"key_value_old"=$3 where "id"=$1 and "application_reference_no"=$2`, [res['rows'][0]['id'], application_reference_no, old_photofilepath])
        }
        if (data.req_type == 'GST') {
            await pool.query(`update tbl_chng_req_hist set "key_value_edited"='Gst',"key_value_old"=$3 where "id"=$1 and "application_reference_no"=$2`, [res['rows'][0]['id'], application_reference_no, gstn])
        }
        if (data.req_type != 'DUP' || data.req_type != 'PH') {
            await saveApproveToApprovehistory(data.pan_no, application_reference_no)
        }
        return res['rows'][0]
    }
    return null;


}

getOfflineUpdateById = async (data) => {
    let change_res = await pool.query(`select A.id,A.pan_no,A.req_type,A.application_reference_no,B.first_name, B.middle_name, B.last_name,B.arn_number,B.id as appr_id,B.application_type,B.euin_number,B.arn_id,B.category_of_corporation from tbl_chng_req_hist A,amfi_distributer_master_approved B where A."id"=$1 and A."pan_no"=B."pan_no" `, [data.id])

    if (change_res['rowCount'] > 0) {
        let req_type = change_res['rows'][0]['req_type']
        let appr_id = change_res['rows'][0]['appr_id']
        let application_type = change_res['rows'][0]['application_type']
        let reqtype_res = await pool.query(`select req_desc from tbl_req_type_master where "status"=true and "req_type"=$1 and "category_code"=$2 `, ['UPDATE', req_type])
        if (reqtype_res['rowCount'] > 0) {
            change_res['rows'][0]['request_type'] = reqtype_res['rows'][0]['req_desc']
        }
        if (application_type == 'ARN') {
            let category_res = await pool.query(`select "category_of_corporation" from amfi_distributer_master_approved where "id"=$1`, [appr_id])
            if (category_res['rowCount'] > 0) {
                change_res['rows'][0]['category'] = category_res['rows'][0]['category_of_corporation']
            }
        }
        else if (application_type == 'EUIN') {
            change_res['rows'][0]['category'] = 'EMP'
        }

        return change_res['rows'][0];
    }
    return null;
}

submitOfflineUpdate = async (data) => {
    let res = await pool.query(`update tbl_chng_req_hist set appl_uploads=$1,req_status=$2,modified_date=$3,"req_status_code"=$7 where id=$4 and  pan_no=$5 and application_reference_no=$6 RETURNING  "application_reference_no"`, [data.uploaded_file, "Start Entry", 'now()', data.id, data.pan_no, data.application_reference_no, 'START_ENTRY'])

    if (res['rowCount'] > 0) {
        // let select_data = await pool.query(`select req_type from tbl_chng_req_hist where id=$1 and  pan_no=$2 and application_reference_no=$3`, [data.id, data.pan_no, data.application_reference_no])
        // if (select_data['rowCount'] > 0) {
        //     await pool.query(`update tbl_chng_req_hist set "key_value_new"=$4 where id=$1 and  pan_no=$2 and application_reference_no=$3`, [data.id, data.pan_no, data.application_reference_no, data.uploaded_file])
        // }
        return res['rows'];
    }
    return null;
}

getOfflineUpdateQueueList = async (data) => {
    await updateAssignedChangeRequest()
    let res;
    if (data.req_type == 'DUP') {
        res = await pool.query(`select A.req_type, A.id,A.pan_no,A.application_reference_no,B.first_name, B.middle_name, B.last_name,B.arn_number,A.priority, A.source,A.req_status,B."euin_number",C.category_description as arn_type,to_char(B.validity_from,'YYYY-MM-DD') as validity_from, to_char(B.validity_to,'YYYY-MM-DD') as validity_to from tbl_chng_req_hist A,amfi_distributer_master_approved B,tbl_amfi_category_master C where A."pan_no"=B."pan_no" and B.category_of_corporation =C.category_code  and C.status =true and A.req_type=$1 and A.status=true and (A."req_status_code"='PENDING' or A."req_status_code"='START_ENTRY' OR A."req_status_code"='ASSIGNED_BO1')`, [data.req_type])
    }
    else {
        res = await pool.query(`select A.req_type, A.id,A.pan_no,A.application_reference_no,B.first_name, B.middle_name, B.last_name,B.arn_number,A.priority, A.source,A.req_status,B."euin_number",C.category_description as arn_type from tbl_chng_req_hist A,amfi_distributer_master_approved B,tbl_amfi_category_master C where A."pan_no"=B."pan_no" and B.category_of_corporation =C.category_code  and C.status =true and A.req_type=$1 and A.status=true and (A."req_status_code"='PENDING' or A."req_status_code"='START_ENTRY' OR A."req_status_code"='ASSIGNED_BO1')`, [data.req_type])
    }

    // ARN type Individual coporate Pending
    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

getOfflineUpdateAuthoriseList = async (data) => {
    await updateAssignedChangeRequest();
    if (data.req_type == 'DUP') {
        res = await pool.query(`select A.req_type, A.id,A.pan_no,A.application_reference_no,B.first_name, B.middle_name, B.last_name,B.arn_number,A.priority, A.source,A.req_status,B."euin_number",C.category_description as arn_type,to_char(B.validity_from,'YYYY-MM-DD') as validity_from, to_char(B.validity_to,'YYYY-MM-DD') as validity_to from tbl_chng_req_hist A,amfi_distributer_master_approved B,tbl_amfi_category_master C where A."pan_no"=B."pan_no" and B.category_of_corporation =C.category_code  and C.status =true and A.req_type=$1 and A.status=true and (A."req_status_code"='PENDING_AUTHORISE' OR A."req_status_code"='AUTHORISE' OR A."req_status_code"='ASSIGNED_BO2') `, [data.req_type])
    }
    else {
        res = await pool.query(`select A.req_type, A.id,A.pan_no,A.application_reference_no,B.first_name, B.middle_name, B.last_name,B.arn_number,A.priority, A.source,A.req_status,B."euin_number",C.category_description as arn_type from tbl_chng_req_hist A,amfi_distributer_master_approved B,tbl_amfi_category_master C where A."pan_no"=B."pan_no" and B.category_of_corporation =C.category_code  and C.status =true and A.req_type=$1 and A.status=true and (A."req_status_code"='PENDING_AUTHORISE' OR A."req_status_code"='AUTHORISE' OR A."req_status_code"='ASSIGNED_BO2')`, [data.req_type])
    }
    // ARN type Individual coporate Pending
    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

offlineUpdatedataBoAssign = async (data) => {
    let res = await pool.query(`UPDATE tbl_chng_req_hist SET 
"modified_date"=$2, "modified_by"=$3,"req_status"=$4,"bo1_verified"=$5,"req_status_code"=$7 where "application_reference_no" =$1 and "pan_no"=$6 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['user_id'], "Assigned", data['user_id'], data['pan_no'], 'ASSIGNED_BO1'])

    if (res['rowCount'] > 0) {
        return res['rows'][0].application_reference_no;
    }

    return null;
}


offlineUpdatedataBo2Assign = async (data) => {
    let resdata = await pool.query(`select "bo1_verified" from tbl_chng_req_hist where "application_reference_no" =$1 and "pan_no"=$2`, [data['application_reference_no'], data['pan_no']])
    if (resdata['rowCount'] > 0) {
        if (resdata['rows'][0]['bo1_verified'] == data.user_id) {
            return false;
        }
        else {
            let res = await pool.query(`UPDATE tbl_chng_req_hist SET 
            "modified_date"=$2, "modified_by"=$3,"req_status"=$4,"bo2_verified"=$5,"req_status_code"=$7 where "application_reference_no" =$1 and "pan_no"=$6 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['user_id'], "Assigned", data['user_id'], data['pan_no'], 'ASSIGNED_BO2'])

            if (res['rowCount'] > 0) {
                return res['rows'][0].application_reference_no;
            }
        }
    }
    return null;
}

getFinancialYear = async (data) => {
    let res = await pool.query(`select finace_year ,financeyear_from ,financeyear_to  from tbl_finance_year where active =true`)

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getAuthoriseSelfDeclareUpdated = async (data) => {
    let res = await pool.query(`select to_char(A.appl_date,'YYYY-MM-DD') AS date_of_submission,B.arn_number,B.first_name ,B.middle_name ,B.last_name,A.pan_no,A.appl_uploads,A."source"  from tbl_chng_req_hist A,amfi_distributer_master_approved_history B where A.application_reference_no=$1 and A.pan_no =B.pan_no and A.status =true and A."application_reference_no"=B."application_reference_no"`, [data.application_reference_no])

    if (res['rowCount'] > 0) {
        let file_uploadid = res['rows'][0]['appl_uploads'];
        res['rows'][0]['selfdeclare_filepath_base64'] = null;
        var num1 = parseInt(file_uploadid) || 0;
        if (num1 > 0) {
            let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_uploadid])
            if (file_res['rowCount'] > 0) {
                let imgBuff = file_res['rows'][0]['image'];
                res['rows'][0]['selfdeclare_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                res['rows'][0]['selfdeclare_filepath_image_type'] = file_res['rows'][0]['image_type'];
                res['rows'][0]['selfdeclare_filename'] = file_res['rows'][0]['file_name']

                return res['rows'];
            }
        }
    }
    return null;
}


authoriseSelfDeclaration = async (data) => {
    let res = await pool.query(`update amfi_distributer_master_approved set "declaration_time" =$2, modified_date=$3 ,modified_by=$4 where pan_no=$1`, [data.pan_no, 'now()', 'now()', data.user_id])

    if (res['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}

updateChangeReqHistryAuthorised = async (data) => {
    let res = await pool.query(`update tbl_chng_req_hist set req_status='Completed',status =false,modified_by =$4, modified_date =$3,"req_status_code"=$5 where application_reference_no =$1 and pan_no =$2 `, [data.application_reference_no, data.pan_no, 'now()', data.user_id, 'COMPLETED'])

    if (res['rowCount'] > 0) {
        return data.application_reference_no;
    }
    return null;
}

getAuthoriseSignatureUpdated = async (data) => {
    let res = await pool.query(`select to_char(A.appl_date,'YYYY-MM-DD') AS date_of_submission,B.arn_number,B.first_name ,B.middle_name ,B.last_name,A.pan_no,A.appl_uploads,A."source",B."signature_filepath"  from tbl_chng_req_hist A,amfi_distributer_master_approved_history B where A.application_reference_no=$1 and A.pan_no =B.pan_no and A.status =true and A."application_reference_no"=B."application_reference_no"`, [data.application_reference_no])

    if (res['rowCount'] > 0) {
        let file_uploadid = res['rows'][0]['appl_uploads'];
        let new_Sign_id = res['rows'][0]['signature_filepath'];
        res['rows'][0]['uploaded_filepath_base64'] = null;
        res['rows'][0]['new_signature_base64'] = null;
        var num1 = parseInt(file_uploadid) || 0;
        var num2 = parseInt(new_Sign_id) || 0;
        if (num1 > 0) {
            let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_uploadid])
            if (file_res['rowCount'] > 0) {
                let imgBuff = file_res['rows'][0]['image'];
                res['rows'][0]['uploaded_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                res['rows'][0]['uploaded_filepath_image_type'] = file_res['rows'][0]['image_type'];
                res['rows'][0]['uploaded_filename'] = file_res['rows'][0]['file_name']
            }
        }
        if (num2 > 0) {
            let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [new_Sign_id])
            if (file_res['rowCount'] > 0) {
                let imgBuff = file_res['rows'][0]['image'];
                res['rows'][0]['new_signature_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                res['rows'][0]['new_signature_image_type'] = file_res['rows'][0]['image_type'];
                res['rows'][0]['new_signature_filename'] = file_res['rows'][0]['file_name']


            }
        }

        return res['rows'];
    }
    return null;
}


submitForAuthoriseSignatureUpdate = async (data) => {
    let resdata = await pool.query(`update amfi_distributer_master_approved_history set "signature_filepath" =$2, modified_date=$3 ,modified_by=$4 where pan_no=$1 and "application_reference_no"=$5`, [data.pan_no, data.signature_filepath, 'now()', data.user_id, data.application_reference_no])
    if (resdata['rowCount'] > 0) {
        let res = await updateSubmitForAuthorise(data);
        return res;
    }
    return null;
}


authoriseSignature = async (data) => {
    let res = await pool.query(`update amfi_distributer_master_approved set "signature_filepath" =$2, modified_date=$3 ,modified_by=$4 where pan_no=$1`, [data.pan_no, data.signature_filepath, 'now()', data.user_id])

    if (res['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}

getAuthoriseBasicDetailsUpdated = async (data) => {
    let res = await pool.query(`select arn_number,first_name ,middle_name ,last_name,pan_no,gender,to_char(date_of_birth,'YYYY-MM-DD') AS date_of_birth,"address1","address2","address3","city","state","pincode" from amfi_distributer_master_approved_history where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])

    if (res['rowCount'] > 0) {
        let activeres = res['rows'][0]
        activeres['date_of_submission'] = ''
        activeres['address_filepath_base64'] = ''
        activeres['address_filepath_image_type'] = ''
        activeres['address_filename'] = ''
        activeres['source'] = ''
        activeres['address_proof_filepath'] = ''
        let fileres = await pool.query(`select to_char(appl_date,'YYYY-MM-DD') AS date_of_submission,appl_uploads,"source" from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads!='' or appl_uploads!=null) `, [data.application_reference_no])

        if (fileres['rowCount'] > 0) {
            activeres['date_of_submission'] = fileres['rows'][0]['date_of_submission']
            activeres['source'] = fileres['rows'][0]['source']
            let file_uploadid = fileres['rows'][0]['appl_uploads'];
            activeres['address_proof_filepath'] = file_uploadid;
            activeres['address_filepath_base64'] = null;
            var num1 = parseInt(file_uploadid) || 0;
            if (num1 > 0) {
                let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_uploadid])
                if (file_res['rowCount'] > 0) {
                    let imgBuff = file_res['rows'][0]['image'];
                    activeres['address_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                    activeres['address_filepath_image_type'] = file_res['rows'][0]['image_type'];
                    activeres['address_filename'] = file_res['rows'][0]['file_name']
                }
            }
        }
        // let datares = await pool.query(`select key_value_edited,key_value_old,key_value_new from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads='' or appl_uploads=null) `, [data.application_reference_no])

        // if (datares['rowCount'] > 0) {
        //     for (let i = 0; i < datares['rows'].length; i++) {
        //         if (datares['rows'][i]['key_value_edited'] == 'address1') {
        //             activeres['address1'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'address2') {
        //             activeres['address2'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'address3') {
        //             activeres['address3'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'city') {
        //             activeres['city'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'state') {
        //             activeres['state'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'pincode') {
        //             activeres['pincode'] = datares['rows'][i]['key_value_new'];
        //         }
        //     }
        // }
        return activeres;
    }
    return null;
}

submitForAuthoriseBasicDetailUpdate = async (data) => {
    let resdata = await pool.query(`update amfi_distributer_master_approved_history set  modified_date=$2 ,modified_by=$3,"first_name"=$4,"middle_name"=$5,"last_name"=$6,"address1"=$7,"address2"=$8,"address3"=$9,"city"=$10,"pincode"=$11,"state"=$12,"address_proof_filepath"=$13 where pan_no=$1 and "application_reference_no"=$14`, [data.pan_no, 'now()', data.user_id, data.first_name, data.middle_name, data.last_name, data.address1, data.address2, data.address3, data.city, data.pincode, data.state, data.address_proof_filepath, data.application_reference_no])
    if (resdata['rowCount'] > 0) {
        let res = await updateSubmitForAuthorise(data);
        return res;
    }
    return null;
}


authoriseBasicDetails = async (data) => {
    let res = await pool.query(`update amfi_distributer_master_approved set  modified_date=$2 ,modified_by=$3,"first_name"=$4,"middle_name"=$5,"last_name"=$6,"address1"=$7,"address2"=$8,"address3"=$9,"city"=$10,"pincode"=$11,"state"=$12,"address_proof_filepath"=$13 where pan_no=$1`, [data.pan_no, 'now()', data.user_id, data.first_name, data.middle_name, data.last_name, data.address1, data.address2, data.address3, data.city, data.pincode, data.state, data.address_proof_filepath])

    if (res['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}

getAuthoriseBankDetailsUpdated = async (data) => {
    let res = await pool.query(`select arn_number,first_name ,middle_name ,last_name,pan_no,gender,to_char(date_of_birth,'YYYY-MM-DD') AS date_of_birth,"account_Number","ifsc","name_of_bank","branch","bank_city","account_type" from amfi_distributer_master_approved_history where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])

    if (res['rowCount'] > 0) {
        let activeres = res['rows'][0]
        activeres['date_of_submission'] = ''
        activeres['bank_proof_filepath_base64'] = ''
        activeres['bank_proof_filepath_image_type'] = ''
        activeres['bank_proof_filename'] = ''
        activeres['source'] = ''
        activeres['bank_proof_filepath'] = ''
        let fileres = await pool.query(`select to_char(appl_date,'YYYY-MM-DD') AS date_of_submission,appl_uploads,"source" from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads!='' or appl_uploads!=null) `, [data.application_reference_no])

        if (fileres['rowCount'] > 0) {
            activeres['date_of_submission'] = fileres['rows'][0]['date_of_submission']
            activeres['source'] = fileres['rows'][0]['source']
            let file_uploadid = fileres['rows'][0]['appl_uploads'];
            activeres['bank_proof_filepath'] = file_uploadid
            activeres['bank_proof_filepath_base64'] = null;
            var num1 = parseInt(file_uploadid) || 0;
            if (num1 > 0) {
                let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_uploadid])
                if (file_res['rowCount'] > 0) {
                    let imgBuff = file_res['rows'][0]['image'];
                    activeres['bank_proof_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                    activeres['bank_proof_filepath_image_type'] = file_res['rows'][0]['image_type'];
                    activeres['bank_proof_filename'] = file_res['rows'][0]['file_name']
                }
            }
        }
        // let datares = await pool.query(`select key_value_edited,key_value_old,key_value_new from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads='' or appl_uploads=null) `, [data.application_reference_no])

        // if (datares['rowCount'] > 0) {
        //     for (let i = 0; i < datares['rows'].length; i++) {
        //         if (datares['rows'][i]['key_value_edited'] == 'account_Number') {
        //             activeres['account_Number'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'ifsc') {
        //             activeres['ifsc'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'name_of_bank') {
        //             activeres['name_of_bank'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'branch') {
        //             activeres['branch'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'bank_city') {
        //             activeres['bank_city'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'account_type') {
        //             activeres['account_type'] = datares['rows'][i]['key_value_new'];
        //         }
        //     }
        // }
        return activeres;
    }
    return null;
}

submitForAuthoriseBankDetailsUpdate = async (data) => {
    let resdata = await pool.query(`update amfi_distributer_master_approved_history set  modified_date=$2 ,modified_by=$3,"account_Number"=$4,"ifsc"=$5,"name_of_bank"=$6,"branch"=$7,"bank_city"=$8,"account_type"=$9,"bank_proof_filepath"=$10 where pan_no=$1  and "application_reference_no"=$11`, [data.pan_no, 'now()', data.user_id, data.account_Number, data.ifsc, data.name_of_bank, data.branch, data.bank_city, data.account_type, data.bank_proof_filepath, data.application_reference_no])
    if (resdata['rowCount'] > 0) {
        let res = await updateSubmitForAuthorise(data);
        return res;
    }
    return null;
}

authoriseBankDetails = async (data) => {
    let res = await pool.query(`update amfi_distributer_master_approved set  modified_date=$2 ,modified_by=$3,"account_Number"=$4,"ifsc"=$5,"name_of_bank"=$6,"branch"=$7,"bank_city"=$8,"account_type"=$9,"bank_proof_filepath"=$10 where pan_no=$1`, [data.pan_no, 'now()', data.user_id, data.account_Number, data.ifsc, data.name_of_bank, data.branch, data.bank_city, data.account_type, data.bank_proof_filepath])

    if (res['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}

getAuthoriseContactsUpdated = async (data) => {
    let res = await pool.query(`select arn_number,first_name ,middle_name ,last_name,pan_no,gender,to_char(date_of_birth,'YYYY-MM-DD') AS date_of_birth,"email_id","mobile_no" from amfi_distributer_master_approved_history where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])

    if (res['rowCount'] > 0) {
        let activeres = res['rows'][0]
        activeres['date_of_submission'] = ''
        activeres['contact_proof_filepath_base64'] = ''
        activeres['contact_proof_filepath_image_type'] = ''
        activeres['contact_proof_filename'] = ''
        activeres['source'] = ''
        activeres['new_email_id'] = activeres['email_id'];
        activeres['new_mobile_no'] = activeres['mobile_no'];

        let activedatares = await pool.query(`select arn_number,first_name ,middle_name ,last_name,pan_no,gender,to_char(date_of_birth,'YYYY-MM-DD') AS date_of_birth,"email_id","mobile_no" from amfi_distributer_master_approved where "pan_no"=$1`, [data.pan_no])

        if (activedatares['rowCount'] > 0) {
            activeres['old_email_id'] = activedatares['rows'][0]['email_id']
            activeres['old_mobile_no'] = activedatares['rows'][0]['mobile_no']
        }

        let fileres = await pool.query(`select to_char(appl_date,'YYYY-MM-DD') AS date_of_submission,appl_uploads,"source" from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads!='' or appl_uploads!=null) `, [data.application_reference_no])

        if (fileres['rowCount'] > 0) {
            activeres['date_of_submission'] = fileres['rows'][0]['date_of_submission']
            activeres['source'] = fileres['rows'][0]['source']
            let file_uploadid = fileres['rows'][0]['appl_uploads'];
            activeres['contact_proof_filepath_base64'] = null;
            var num1 = parseInt(file_uploadid) || 0;
            if (num1 > 0) {
                let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_uploadid])
                if (file_res['rowCount'] > 0) {
                    let imgBuff = file_res['rows'][0]['image'];
                    activeres['contact_proof_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                    activeres['contact_proof_filepath_image_type'] = file_res['rows'][0]['image_type'];
                    activeres['contact_proof_filename'] = file_res['rows'][0]['file_name']
                }
            }
        }
        // let datares = await pool.query(`select key_value_edited,key_value_old,key_value_new from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads='' or appl_uploads=null) `, [data.application_reference_no])

        // if (datares['rowCount'] > 0) {
        //     for (let i = 0; i < datares['rows'].length; i++) {
        //         if (datares['rows'][i]['key_value_edited'] == 'email_id') {
        //             activeres['email_id'] = datares['rows'][i]['key_value_new'];
        //         }
        //         if (datares['rows'][i]['key_value_edited'] == 'mobile_no') {
        //             activeres['mobile_no'] = datares['rows'][i]['key_value_new'];
        //         }
        //     }
        // }
        return activeres;
    }
    return null;
}

submitForAuthoriseContactsUpdate = async (data) => {
    let resdata = await pool.query(`update amfi_distributer_master_approved_history set   modified_date=$2 ,modified_by=$3,"email_id"=$4,"mobile_no"=$5 where pan_no=$1  and "application_reference_no"=$6`, [data.pan_no, 'now()', data.user_id, data.email_id, data.mobile_no, data.application_reference_no])
    if (resdata['rowCount'] > 0) {
        let res = await updateSubmitForAuthorise(data);
        return res;
    }
    return null;
}

authoriseContacts = async (data) => {
    let res = await pool.query(`update amfi_distributer_master_approved set  modified_date=$2 ,modified_by=$3,"email_id"=$4,"mobile_no"=$5 where pan_no=$1`, [data.pan_no, 'now()', data.user_id, data.email_id, data.mobile_no])

    if (res['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}

getAuthoriseGSTDetailsUpdated = async (data) => {
    let res = await pool.query(`select arn_number,first_name ,middle_name ,last_name,pan_no,gender,to_char(date_of_birth,'YYYY-MM-DD') AS date_of_birth,"gst_filepath" from amfi_distributer_master_approved_history where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])

    if (res['rowCount'] > 0) {
        let activeres = res['rows'][0]
        activeres['date_of_submission'] = ''
        activeres['contact_proof_filepath_base64'] = ''
        activeres['contact_proof_filepath_image_type'] = ''
        activeres['contact_proof_filename'] = ''
        activeres['source'] = '';
        activeres['old_gstn'] = ''
        activeres['new_gstn'] = ''
        let fileres = await pool.query(`select to_char(appl_date,'YYYY-MM-DD') AS date_of_submission,appl_uploads,"source",key_value_old,key_value_new from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads!='' or appl_uploads!=null) `, [data.application_reference_no])

        if (fileres['rowCount'] > 0) {
            activeres['old_gstn'] = fileres['rows'][0]['key_value_old']
            activeres['new_gstn'] = fileres['rows'][0]['key_value_new']
            activeres['date_of_submission'] = fileres['rows'][0]['date_of_submission']
            activeres['source'] = fileres['rows'][0]['source']
            let file_uploadid = fileres['rows'][0]['appl_uploads'];
            activeres['gst_filepath'] = file_uploadid;
            activeres['gst_filepath_base64'] = null;
            var num1 = parseInt(file_uploadid) || 0;
            if (num1 > 0) {
                let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_uploadid])
                if (file_res['rowCount'] > 0) {
                    let imgBuff = file_res['rows'][0]['image'];
                    activeres['gst_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                    activeres['gst_filepath_image_type'] = file_res['rows'][0]['image_type'];
                    activeres['gst_filename'] = file_res['rows'][0]['file_name']
                }
            }
        }
        // let datares = await pool.query(`select key_value_edited,key_value_old,key_value_new from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads='' or appl_uploads=null) `, [data.application_reference_no])

        // if (datares['rowCount'] > 0) {
        //     for (let i = 0; i < datares['rows'].length; i++) {
        //         if (datares['rows'][i]['key_value_edited'] == 'gstn') {
        //             activeres['gstn'] = datares['rows'][i]['key_value_new'];
        //         }

        //     }
        // }
        return activeres;
    }
    return null;
}

submitForAuthoriseGstUpdate = async (data) => {
    let resdata = await pool.query(`update amfi_distributer_master_approved_history set  modified_date=$2 ,modified_by=$3,"gstn"=$4,"gst_filepath"=$5 where pan_no=$1  and "application_reference_no"=$6`, [data.pan_no, 'now()', data.user_id, data.gstn, data.gst_filepath, data.application_reference_no])
    if (resdata['rowCount'] > 0) {
        // let res = await updateSubmitForAuthorise(data);
        // return res;
        let res = await pool.query(`update tbl_chng_req_hist set req_status='Authorise',modified_by =$4, modified_date =$3,"req_status_code"=$5,"key_value_new"=$6 where application_reference_no =$1 and pan_no =$2 `, [data.application_reference_no, data.pan_no, 'now()', data.user_id, 'AUTHORISE', data.gstn])
        return data.application_reference_no;
    }
    return null;
}


authoriseGSTDetails = async (data) => {
    let res = await pool.query(`update amfi_distributer_master_approved set  modified_date=$2 ,modified_by=$3,"gstn"=$4,"gst_filepath"=$5 where pan_no=$1`, [data.pan_no, 'now()', data.user_id, data.gstn, data.gst_filepath])

    if (res['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}

getAuthorisephotoUpdated = async (data) => {
    let res = await pool.query(`select arn_number,first_name ,middle_name ,last_name,pan_no,photo_thumbnail as old_photo from amfi_distributer_master_approved where "pan_no"=$1 `, [data.pan_no])
    if (res['rowCount'] > 0) {
        let activeres = res['rows'][0]
        activeres['date_of_submission'] = ''
        activeres['new_photo_filepath_base64'] = ''
        activeres['new_photo_filepath_image_type'] = ''
        activeres['new_photo_filename'] = ''
        activeres['source'] = ''
        let fileres = await pool.query(`select to_char(appl_date,'YYYY-MM-DD') AS date_of_submission,appl_uploads,"source","key_value_new" from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads!='' or appl_uploads!=null) `, [data.application_reference_no])

        if (fileres['rowCount'] > 0) {
            activeres['date_of_submission'] = fileres['rows'][0]['date_of_submission']
            activeres['source'] = fileres['rows'][0]['source']
            let newphotoid = fileres['rows'][0]['key_value_new'];
            let uploaded_fileid = fileres['rows'][0]['appl_uploads'];
            activeres['photo_filepath'] = newphotoid;
            activeres['new_photo_filepath_base64'] = null;
            activeres['uploaded_filepath_base64'] = null;
            var num1 = parseInt(newphotoid) || 0;
            if (num1 > 0) {
                let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [newphotoid])
                if (file_res['rowCount'] > 0) {
                    let imgBuff = file_res['rows'][0]['image'];
                    activeres['new_photo_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                    activeres['new_photo_filepath_image_type'] = file_res['rows'][0]['image_type'];
                    activeres['new_photo_filename'] = file_res['rows'][0]['file_name']
                }
            }
            var num2 = parseInt(uploaded_fileid) || 0;
            if (num2 > 0) {
                let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [uploaded_fileid])
                if (file_res['rowCount'] > 0) {
                    let imgBuff = file_res['rows'][0]['image'];
                    activeres['uploaded_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                    activeres['uploaded_filepath_image_type'] = file_res['rows'][0]['image_type'];
                    activeres['uploaded_filename'] = file_res['rows'][0]['file_name']
                }
            }
        }
        return activeres;
    }
    return null;
}


submitForAuthorisePhotoUpdate = async (data) => {
    // let buff = await helper.base64ToThumbnail(data['photo_filepath']);
    // let resdata = await pool.query(`update amfi_distributer_master_approved_history set  "photo_filepath"=$4,"modified_date"=$2,"modified_by"=$3,"photo_thumbnail"=$5 where pan_no=$1  and "application_reference_no"=$6`, [data.pan_no, 'now()', data['user_id'], data['photo_filepath'], buff, data.application_reference_no])
    // if (resdata['rowCount'] > 0) {
    //     let res = await updateSubmitForAuthorise(data);
    //     return res;
    // }
    // return null;

    let res = await pool.query(`update tbl_chng_req_hist set req_status='Authorise',modified_by =$4, modified_date =$3,"req_status_code"=$5,"key_value_new"=$6 where application_reference_no =$1 and pan_no =$2 `, [data.application_reference_no, data.pan_no, 'now()', data.user_id, 'AUTHORISE', data['photo_filepath']])
    if (res['rowCount'] > 0) {
        return data.application_reference_no;
    }
    return null;


}

authorisePhoto = async (data) => {
    let buff = await helper.base64ToThumbnail(data['photo_filepath']);
    let res = await pool.query(`UPDATE amfi_distributer_master_approved SET "photo_filepath"=$4,"modified_date"=$2,"modified_by"=$3,"photo_thumbnail"=$5  where  pan_no=$1`, [data.pan_no, 'now()', data['user_id'], data['photo_filepath'], buff]);

    if (res['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}

getAuthoriseOptionUpdated = async (data) => {
    let res = await pool.query(`select arn_number,first_name ,middle_name ,last_name,pan_no from amfi_distributer_master_approved_history where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])
    if (res['rowCount'] > 0) {
        let activeres = res['rows'][0]
        activeres['date_of_submission'] = ''
        activeres['option_filepath_base64'] = ''
        activeres['option_filepath_image_type'] = ''
        activeres['option_filename'] = ''
        activeres['source'] = ''
        let fileres = await pool.query(`select to_char(appl_date,'YYYY-MM-DD') AS date_of_submission,appl_uploads,"source" from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads!='' or appl_uploads!=null) `, [data.application_reference_no])

        if (fileres['rowCount'] > 0) {
            activeres['date_of_submission'] = fileres['rows'][0]['date_of_submission']
            activeres['source'] = fileres['rows'][0]['source']
            let file_uploadid = fileres['rows'][0]['appl_uploads'];
            activeres['option_filepath_base64'] = null;
            var num1 = parseInt(file_uploadid) || 0;
            if (num1 > 0) {
                let file_res = await pool.query(`select * from amfi_file where "id"=$1 
        `, [file_uploadid])
                if (file_res['rowCount'] > 0) {
                    let imgBuff = file_res['rows'][0]['image'];
                    activeres['option_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                    activeres['option_filepath_image_type'] = file_res['rows'][0]['image_type'];
                    activeres['option_filename'] = file_res['rows'][0]['file_name']
                }
            }
        }
        return activeres;
    }
    return null;
}


submitForAuthoriseOptionUpdate = async (data) => {
    let opin_codes = []
    for (let i = 0; i < data.opin.length; i++) {
        if (data.opin[i]['checked'])
            opin_codes.push(data.opin[i]['op_code'])
    }
    let active_opin = await pool.query(`select * from tbl_user_opin where "pan_no"=$1 and "status"=true`, [data.pan_no])
    if (active_opin['rowCount'] > 0) {
        var res = await pool.query(`update tbl_user_opin set "opin_codes"=$1,"modified_by"=$2, "modified_date"=$3 where "pan_no"=$4`, [opin_codes.toString(), data.user_id, 'now()', data.pan_no])
    }
    else {
        var res = await pool.query(`INSERT INTO tbl_user_opin
        ("pan_no", "opin_codes", "last_opin_date", "opin_prev", created_by,  modified_by, modified_date)VALUES($1,$2,$3,$4,$5,$6,$7)returning "id"`, [data.pan_no, opin_codes.toString(), null, '', data.user_id, data.user_id, 'now()'])

    }
    if (res['rowCount'] > 0) {
        await updateSubmitForAuthorise(data);
        return data.application_reference_no;
    }
    return null;
}

authoriseOption = async (data) => {
    let opin_codes = []
    for (let i = 0; i < data.opin.length; i++) {
        if (data.opin[i]['checked'])
            opin_codes.push(data.opin[i]['op_code'])
    }
    let active_opin = await pool.query(`select * from tbl_user_opin where "pan_no"=$1 and "status"=true`, [data.pan_no])
    if (active_opin['rowCount'] > 0) {
        var res = await pool.query(`update tbl_user_opin set "opin_codes"=$1,"modified_by"=$2, "modified_date"=$3 where "pan_no"=$4`, [opin_codes.toString(), data.user_id, 'now()', data.pan_no])
    }
    else {
        var res = await pool.query(`INSERT INTO tbl_user_opin
        ("pan_no", "opin_codes", "last_opin_date", "opin_prev", created_by,  modified_by, modified_date)VALUES($1,$2,$3,$4,$5,$6,$7)returning "id"`, [data.pan_no, opin_codes.toString(), null, '', data.user_id, data.user_id, 'now()'])

    }
    if (res['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }
    return null;
}

getAuthoriseMappingUpdated = async (data) => {
    let res = await pool.query(`select "arn_number","first_name" ,"middle_name" ,"last_name","pan_no","euin_number" from amfi_distributer_master_approved_history where "pan_no"=$1 and "application_reference_no"=$2 `, [data.pan_no, data.application_reference_no])
    if (res['rowCount'] > 0) {
        let activeres = res['rows'][0]
        activeres['date_of_submission'] = ''
        activeres['mapping_filepath_base64'] = ''
        activeres['mapping_filepath_image_type'] = ''
        activeres['mapping_filename'] = ''
        activeres['source'] = ''
        let fileres = await pool.query(`select to_char(appl_date,'YYYY-MM-DD') AS date_of_submission,appl_uploads,"source" from tbl_chng_req_hist where application_reference_no=$1 and (appl_uploads!='' or appl_uploads!=null) `, [data.application_reference_no])

        if (fileres['rowCount'] > 0) {
            activeres['date_of_submission'] = fileres['rows'][0]['date_of_submission']
            activeres['source'] = fileres['rows'][0]['source']
            let file_uploadid = fileres['rows'][0]['appl_uploads'];
            activeres['mapping_filepath_base64'] = null;
            var num1 = parseInt(file_uploadid) || 0;
            if (num1 > 0) {
                let file_res = await pool.query(`select * from amfi_file where "id"=$1 
        `, [file_uploadid])
                if (file_res['rowCount'] > 0) {
                    let imgBuff = file_res['rows'][0]['image'];
                    activeres['mapping_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                    activeres['mapping_filepath_image_type'] = file_res['rows'][0]['image_type'];
                    activeres['mapping_filename'] = file_res['rows'][0]['file_name']
                }
            }
        }
        return activeres;
    }
    return null;
}

submitForAuthoriseMappingUpdate = async (data) => {
    let resdata = await pool.query(`update amfi_distributer_master_approved_history set  "arn_id"=$4,"modified_date"=$2,"modified_by"=$3 where pan_no=$1  and "application_reference_no"=$5`, [data.pan_no, 'now()', data['user_id'], data['new_arn_number'], data.application_reference_no])
    if (resdata['rowCount'] > 0) {
        let res = await updateSubmitForAuthorise(data);
        return res;
    }
    return null;
}

authoriseMapping = async (data) => {
    // let res = await pool.query(`UPDATE amfi_distributer_master_approved SET "arn_id"=$4,"modified_date"=$2,"modified_by"=$3  where  pan_no=$1`, [data.pan_no, 'now()', data['user_id'], data['new_arn_number']]);
    await pool.query(`update map_hist set "status"=false where "pan_no"=$1`, [data.pan_no])

    let maphis_insert = await pool.query(`INSERT INTO map_hist
    ( pan_no, brkcod, old_arn, new_arn, old_appr_rej_date, new_apprv_rej_date, old_rem, new_rem, created_by,  modified_by, modified_date,"source")
    VALUES($1,$2,$3, $4,$5,$6,$7,$8, $9, $10, $11,$12) returning "id"`, [data.pan_no, '', data.old_arn, data.new_arn, null, null, data.remarks, '', data.user_id, data.user_id, 'now()', 'Offline'])

    if (maphis_insert['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}


getNigoList = async (data) => {
    await updateAssignedNigoRequest();
    let res = await pool.query(`select A.id,A.pan_no,A.nigo_ref,B.first_name, B.middle_name, B.last_name,B.arn_number,A.priority, A.source,A.req_status,B."euin_number",B.application_type,C.category_description  from tbl_reg_ren_nigo A,amfi_distributer_master_pending B,tbl_amfi_category_master C where A."pan_no"=B."pan_no" and  C.status =true and B.category_of_corporation =C.category_code and A.status=true and (A."req_status_code"='PENDING' or A."req_status_code"='START_ENTRY' OR A."req_status_code"='ASSIGNED_BO1')`)
    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

getNigoAuthorisationList = async (data) => {
    await updateAssignedNigoRequest();
    let res = await pool.query(`select A.id,A.pan_no,A.nigo_ref,B.first_name, B.middle_name, B.last_name,B.arn_number,A.priority, A.source,A.req_status,B."euin_number",B.application_type,C.category_description  from tbl_reg_ren_nigo A,amfi_distributer_master_pending B,tbl_amfi_category_master C where A."pan_no"=B."pan_no" and  C.status =true and B.category_of_corporation =C.category_code and A.status=true and (A."req_status_code"='PENDING_AUTHORISE' OR A."req_status_code"='AUTHORISE' OR A."req_status_code"='ASSIGNED_BO2')`)
    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

searchNigoDetails = async (data) => {
    let select_data = await pool.query(`select "reg_ren_req_ref","nigo_ref" ,"pan_no" ,"documents_clob",register_type from tbl_reg_ren_nigo where "status" =true and "req_type" ='nigo' and "pan_no" =$1`, [data.pan_no])

    if (select_data['rowCount'] > 0) {
        let resp_data = select_data['rows'][0]
        let res = {}
        res['application_ref_no'] = resp_data['nigo_ref'];
        res['applicant_type'] = '';
        res['pan_no'] = resp_data['pan_no'];
        res['first_name'] = '';
        res['middle_name'] = '';
        res['last_name'] = '';
        res['mobile_no'] = '';
        res['email_id'] = '';
        res['reason_for_nigo'] = [];
        res['reason_for_nigo_id'] = [];
        res['document_to_reupload'] = resp_data['documents_clob'].split(',')
        // res['photo_filepath'] = '';
        // res['signature_filepath'] = '';
        // res['address_proof_filepath'] = '';
        // res['nism_certificate_filepath'] = '';
        // res['kyd_acknowledge_filepath'] = '';

        // let pending_res = await pool.query(`select A."id",A."first_name",A."middle_name",A."last_name",A."mobile_no",A."email_id",A."application_type",A."photo_filepath",A."signature_filepath",A."address_proof_filepath",A."nism_certificate_filepath",A."kyd_acknowledge_filepath",B.category_description as applicant_type  from amfi_distributer_master_pending A,tbl_amfi_category_master B where "pan_no"=$1 and "nigo"=true and A.category_of_corporation =B.category_code and B.status =true`, [data.pan_no])

        let pending_res = await pool.query(`select A."id",A."first_name",A."middle_name",A."last_name",A."mobile_no",A."email_id",A.single_merged_doc,B.category_description as applicant_type  from amfi_distributer_master_pending A,tbl_amfi_category_master B where "pan_no"=$1 and "nigo"=true and A.category_of_corporation =B.category_code and B.status =true`, [data.pan_no])
        if (pending_res['rowCount'] > 0) {
            res['first_name'] = pending_res['rows'][0]['first_name'];
            res['middle_name'] = pending_res['rows'][0]['middle_name'];
            res['last_name'] = pending_res['rows'][0]['last_name'];
            res['mobile_no'] = pending_res['rows'][0]['mobile_no'];
            res['email_id'] = pending_res['rows'][0]['email_id'];
            res['single_merged_doc'] = pending_res['rows'][0]['single_merged_doc'];
            //  res['photo_filepath'] = pending_res['rows'][0]['photo_filepath'];
            // res['signature_filepath'] = pending_res['rows'][0]['signature_filepath'];
            // res['address_proof_filepath'] = pending_res['rows'][0]['address_proof_filepath'];
            // res['nism_certificate_filepath'] = pending_res['rows'][0]['nism_certificate_filepath'];
            // res['kyd_acknowledge_filepath'] = pending_res['rows'][0]['kyd_acknowledge_filepath'];

        }
        else {
            // let active_res = await pool.query(`select A."id",A."first_name",A."middle_name",A."last_name",A."mobile_no",A."email_id",A."application_type",A."photo_filepath",A."signature_filepath",A."address_proof_filepath",A."nism_certificate_filepath",A."kyd_acknowledge_filepath",B.category_description as applicant_type  from amfi_distributer_master_approved_history A,tbl_amfi_category_master B where "pan_no"=$1 and "nigo"=true and A.category_of_corporation =B.category_code and B.status =true`, [data.pan_no])

            let active_res = await pool.query(`select A."id",A."first_name",A."middle_name",A."last_name",A."mobile_no",A."email_id",A."application_type",A.single_merged_doc,B.category_description as applicant_type  from amfi_distributer_master_approved_history A,tbl_amfi_category_master B where "pan_no"=$1 and "nigo"=true and A.category_of_corporation =B.category_code and B.status =true`, [data.pan_no])



            if (active_res['rowCount'] > 0) {
                res['first_name'] = active_res['rows'][0]['first_name'];
                res['middle_name'] = active_res['rows'][0]['middle_name'];
                res['last_name'] = active_res['rows'][0]['last_name'];
                res['mobile_no'] = active_res['rows'][0]['mobile_no'];
                res['email_id'] = active_res['rows'][0]['email_id'];
                res['single_merged_doc'] = active_res['rows'][0]['single_merged_doc']
                // res['photo_filepath'] = pending_res['rows'][0]['photo_filepath'];
                // res['signature_filepath'] = pending_res['rows'][0]['signature_filepath'];
                // res['address_proof_filepath'] = pending_res['rows'][0]['address_proof_filepath'];
                // res['nism_certificate_filepath'] = pending_res['rows'][0]['nism_certificate_filepath'];
                // res['kyd_acknowledge_filepath'] = pending_res['rows'][0]['kyd_acknowledge_filepath'];

            }
        }



        let reason_arr = resp_data['reg_ren_req_ref'].split(',');
        res['reason_for_nigo_id'] = reason_arr;
        let reason_str = '';
        for (let i = 0; i < reason_arr.length; i++) {
            let reasonid = reason_arr[i]
            reason_str += '\'' + reasonid + '\'' + ','
        }
        reason_str = reason_str.slice(0, reason_str.length - 1);

        let select_reason = await pool.query(`select "req_desc" from tbl_dropdown_master  where "status" =true and "req_code" in(${reason_str}) and "req_type"='TYPEOFISSUE' `)

        if (select_reason['rowCount'] > 0) {
            for (let i = 0; i < select_reason['rows'].length; i++) {
                res['reason_for_nigo'].push(select_reason['rows'][i]['req_desc']);
            }
        }

        return res;
    }

    return null;
}

submitNigoApplicationByFo = async (data) => {
    let select_nigo = await pool.query(`select "register_type" from tbl_reg_ren_nigo where "pan_no"=$1 and "nigo_ref"=$2`, [data.pan_no, data.application_reference_no])

    if (select_nigo['rowCount'] > 0) {

        let single_merged_doc_id = data['single_merged_doc']
        // let file_blobArray = []
        // let amfipen_res = await pool.query(`select "single_merged_doc" from  amfi_distributer_master_pending  where "application_reference_no"=$1  and "pan_no"=$2`, [data['application_reference_no'], data['pan_no']])

        // if (amfipen_res['rowCount'] > 0) {
        //     let image_res = await pool.query(`select image_type ,image  from amfi_file where "id"=$1`, [amfipen_res['rows'][0]['single_merged_doc']])
        //     if (image_res['rowCount'] > 0) {
        //         if (image_res['rows'][0]['image_type'] == 'pdf') {
        //             file_blobArray.push(image_res['rows'][0]['image'])
        //         }
        //     }
        // }

        // let image_frontres = await pool.query(`select image_type ,image  from amfi_file where "id"=$1`, [data['single_merged_doc']])
        // if (image_frontres['rowCount'] > 0) {
        //     if (image_frontres['rows'][0]['image_type'] == 'pdf') {
        //         file_blobArray.push(image_frontres['rows'][0]['image'])
        //     }
        // }
        // let file_base64 = await mergeSinglePdf.mergeSinglePdf(file_blobArray);

        // if (file_base64 != null) {
        //     let req_data = {
        //         "file_name": data['pan_no'] + "_" + Date.now() + ".pdf",
        //         "image_type": "pdf",
        //         "image": file_base64
        //     }

        //     let fileid = await helper.upload_file(req_data);
        //     if (fileid != null) {
        //         single_merged_doc_id = fileid;
        //     }
        // }


        // let buff = await helper.base64ToThumbnail(data['photo_filepath']);
        // if (select_nigo['rows'][0]['register_type'] == 'REGRENEWAL') {
        //     await pool.query(`UPDATE amfi_distributer_master_pending SET 
        //     "photo_filepath"=$4,"signature_filepath"=$5,"address_proof_filepath"=$6,"nism_certificate_filepath"=$7,"kyd_acknowledge_filepath"=$8,"current_action"=$10,"modified_date"=$2, "modified_by"=$9,"photo_thumbnail"=$11,"current_action_code"=$12 where "application_reference_no"=$1  and "pan_no"=$3 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['pan_no'], data['photo_filepath'], data['signature_filepath'], data['address_proof_filepath'], data['nism_certificate_filepath'], data['kyd_acknowledge_filepath'], data['user_id'], "Start Entry", buff, 'START_ENTRY'])


        if (select_nigo['rows'][0]['register_type'] == 'REGRENEWAL') {
            await pool.query(`UPDATE amfi_distributer_master_pending SET 
                "current_action"=$5,"modified_date"=$2, "modified_by"=$4,"current_action_code"=$6,"single_merged_doc"=$7 where "application_reference_no"=$1  and "pan_no"=$3 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['pan_no'], data['user_id'], "Start Entry", 'START_ENTRY', single_merged_doc_id])
        }
        else {
            // await pool.query(`UPDATE amfi_distributer_master_approved_history SET 
            // "photo_filepath"=$4,"signature_filepath"=$5,"address_proof_filepath"=$6,"nism_certificate_filepath"=$7,"kyd_acknowledge_filepath"=$8,"current_action"=$10,"modified_date"=$2, "modified_by"=$9,"photo_thumbnail"=$11,"current_action_code"=$12 where "application_reference_no"=$1  and "pan_no"=$3 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['pan_no'], data['photo_filepath'], data['signature_filepath'], data['address_proof_filepath'], data['nism_certificate_filepath'], data['kyd_acknowledge_filepath'], data['user_id'], "Start Entry", buff, 'START_ENTRY'])

            await pool.query(`UPDATE amfi_distributer_master_approved_history SET 
            "current_action"=$5,"modified_date"=$2, "modified_by"=$4,"current_action_code"=$6,"single_merged_doc"=$7 where "application_reference_no"=$1  and "pan_no"=$3 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['pan_no'], data['user_id'], "Start Entry", 'START_ENTRY', single_merged_doc_id])
        }

        await pool.query(`UPDATE tbl_reg_ren_nigo SET "modified_date"=$2, "modified_by"=$3,"req_status"=$4,"req_status_code"=$6 where "nigo_ref" =$1 and "pan_no"=$5 returning "nigo_ref"`, [data['application_reference_no'], 'now()', data['user_id'], "Start Entry", data['pan_no'], 'START_ENTRY']);

        return data.application_reference_no;
    }
    return null;
}

submitForAuthoriseSelfdeclareUpdate = async (data) => {
    let res = await updateSubmitForAuthorise(data);
    return res;
}


updateSubmitForAuthorise = async (data) => {
    let res = await pool.query(`update tbl_chng_req_hist set req_status='Authorise',modified_by =$4, modified_date =$3,"req_status_code"=$5 where application_reference_no =$1 and pan_no =$2 `, [data.application_reference_no, data.pan_no, 'now()', data.user_id, 'AUTHORISE'])

    if (res['rowCount'] > 0) {
        return data.application_reference_no;
    }
    return null;
}



saveApproveToApprovehistory = async (pan_no, application_reference_no) => {
    let activeresdata = await pool.query(`select *  from amfi_distributer_master_approved where "pan_no"=$1`, [pan_no])

    if (activeresdata['rowCount'] > 0) {
        let activeres = activeresdata['rows'][0]
        let insert_approved = `INSERT INTO amfi_distributer_master_approved_history( first_name, middle_name, last_name, gender, date_of_birth, pan_no, gstn, "whether_kyd_Compliant", certificate_number, date_of_passing_test, address1, address2, address3, city, pincode, state, country, telephone_number, fax, mobile_no, email_id, qualification, university, year_of_passing, name_of_bank, branch, bank_city, "account_Number", ifsc, account_type, micr, dd_cheque_number, dd_cheque_date, amount, drawn_on_bank_branch, signature, place, sign_date, undertaking_consent, kyd_source, cpe_certificate_number, date_of_cpe_from, distributor_category, arn_id, name_of_organisation, utr_no, type_of_distributor, distributer_master_status, created_by, modified_by, modified_date, application_type, date_of_cpe_to, bank_proof_filepath, pancard_filepath, adharcard_filepath, photo_filepath, signature_filepath, registration_type, date_of_appointment, designation, description_of_responsibilities, company_address1, company_address2, company_address3, company_pincode, company_city, company_state, arn_number, euin_number, gst_filepath, application_reference_no, document_checklist, address_proof_filepath, nism_certificate_filepath, kyd_acknowledge_filepath, priority, current_action, fo1_verified, fo2_verified, gst_verified, gst_verified_by, renewal_type,photo_thumbnail,category_of_corporation,"user_id",validity_from, validity_to,single_merged_doc)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42,$43,$44,$45,$46,$47,$48,$49,$50,$51,$52,$53,$54,$55,$56,$57,$58,$59,$60,$61,$62,$63,$64,$65,$66,$67,$68,$69,$70,$71,$72,$73,$74,$75,$76,$77,$78,$79,$80,$81,$82,$83,$84,$85,$86,$87,$88,$89) returning "id","arn_number","euin_number"`

        let dis_ins = await pool.query(insert_approved, [activeres['first_name'], activeres['middle_name'], activeres['last_name'], activeres['gender'], activeres['date_of_birth'], activeres['pan_no'], activeres['gstn'], activeres['whether_kyd_Compliant'], activeres['certificate_number'], activeres['date_of_passing_test'], activeres['address1'], activeres['address2'], activeres['address3'], activeres['city'], activeres['pincode'], activeres['state'], activeres['country'], activeres['telephone_number'], activeres['fax'], activeres['mobile_no'], activeres['email_id'], activeres['qualification'], activeres['university'], activeres['year_of_passing'], activeres['name_of_bank'], activeres['branch'], activeres['bank_city'], activeres['account_Number'], activeres['ifsc'], activeres['account_type'], activeres['micr'], activeres['dd_cheque_number'], activeres['dd_cheque_date'], activeres['amount'], activeres['drawn_on_bank_branch'], activeres['signature'], activeres['place'], activeres['sign_date'], activeres['undertaking_consent'], activeres['kyd_source'], activeres['cpe_certificate_number'], activeres['date_of_cpe_from'], activeres['distributor_category'], activeres['arn_id'], activeres['name_of_organisation'], activeres['utr_no'], activeres['type_of_distributor'], 'Active', null, null, 'now()', activeres['application_type'], activeres['date_of_cpe_to'], activeres['bank_proof_filepath'], activeres['pancard_filepath'], activeres['adharcard_filepath'], activeres['photo_filepath'], activeres['signature_filepath'], activeres['registration_type'], activeres['date_of_appointment'], activeres['designation'], activeres['description_of_responsibilities'], activeres['company_address1'], activeres['company_address2'], activeres['company_address3'], activeres['company_pincode'], activeres['company_city'], activeres['company_state'], activeres['arn_number'], activeres['euin_number'], activeres['gst_filepath'], application_reference_no, activeres['document_checklist'], activeres['address_proof_filepath'], activeres['nism_certificate_filepath'], activeres['kyd_acknowledge_filepath'], activeres['priority'], activeres['current_action'], activeres['fo1_verified'], activeres['fo2_verified'], activeres['gst_verified'], activeres['gst_verified_by'], activeres['renewal_type'], activeres['photo_thumbnail'], activeres['category_of_corporation'], activeres['user_id'], activeres['validity_from'], activeres['validity_to'], activeres['single_merged_doc']])

    }
}


nigoBo1Assign = async (data) => {
    let res = await pool.query(`UPDATE tbl_reg_ren_nigo SET 
"modified_date"=$2, "modified_by"=$3,"req_status"=$4,"bo1_verified"=$5,"req_status_code"=$7 where "nigo_ref" =$1 and "pan_no"=$6 returning "nigo_ref"`, [data['application_reference_no'], 'now()', data['user_id'], "Assigned", data['user_id'], data['pan_no'], 'ASSIGNED_BO1'])

    if (res['rowCount'] > 0) {
        return res['rows'][0].nigo_ref;
    }

    return null;
}

nigoBo2Assign = async (data) => {
    let resdata = await pool.query(`select "bo1_verified" from tbl_reg_ren_nigo where "nigo_ref" =$1 and "pan_no"=$2`, [data['application_reference_no'], data['pan_no']])
    if (resdata['rowCount'] > 0) {
        if (resdata['rows'][0]['bo1_verified'] == data.user_id) {
            return false;
        }
        else {
            let res = await pool.query(`UPDATE tbl_reg_ren_nigo SET 
            "modified_date"=$2, "modified_by"=$3,"req_status"=$4,"bo2_verified"=$5,"req_status_code"=$7 where "nigo_ref" =$1 and "pan_no"=$6 returning "nigo_ref"`, [data['application_reference_no'], 'now()', data['user_id'], "Assigned", data['user_id'], data['pan_no'], 'ASSIGNED_BO2'])

            if (res['rowCount'] > 0) {
                return res['rows'][0].nigo_ref;
            }
        }
    }
    return null;
}

authoriseRegisterRenewal = async (data) => {
    await helper.saveErrorAuditLogs(data, '', 'OFFLINESERVI')
    let select_type = await pool.query(`select "application_type","registration_type","renewal_type"  from amfi_distributer_master_pending where pan_no =$1 and "id"=$2`, [data.pan_no, data.id])
    if (select_type['rowCount'] > 0) {
        return select_type['rows'][0];
    }
    return null;
}

rejectUpdates = async (data) => {
    let res = await pool.query(`update tbl_chng_req_hist set "req_status"='Rejected',"req_status_code"='REJECTED',"status"=false,"reject_remarks"=$3 where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no, data.reject_reason])

    if (res['rowCount'] > 0) {
        return data.application_reference_no;
    }
    return null;
}


rejectRegisterRenewalToNigo = async (data) => {
    let select_nigo = await pool.query(`select * from tbl_reg_ren_nigo where "pan_no"=$1 and "nigo_ref"=$2 and "status"=true`, [data.pan_no, data.application_reference_no])

    if (select_nigo['rowCount'] > 0) {
        let res = await pool.query(`update tbl_reg_ren_nigo set
        "reg_ren_req_ref"=$3, "nigo_upda_date" =$4, "documents_clob"=$5, "documents"=$6, modified_date=$7,"remarks"=$8,"req_status"=$9,"req_status_code"=$10 where "pan_no"=$2 and "nigo_ref"=$1 returning "id"`, [data.application_reference_no, data.pan_no, data['type_of_issue'].toString(), 'now()', data['documents_to_reupload'].toString(), '', 'now()', data.remarks, 'Pending', 'PENDING'])
        if (res['rowCount'] > 0) {
            return res['rows'][0]['id'];
        }
    }
    else {
        let res = await pool.query(`INSERT INTO tbl_reg_ren_nigo
    ("reg_ren_req_ref", "nigo_ref", "pan_no", "nigo_upda_date", "documents_clob", "documents", created_by, modified_by, modified_date,"remarks","req_type","source",register_type)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)returning "id"`, [data['type_of_issue'].toString(), data.application_reference_no, data.pan_no, 'now()', data['documents_to_reupload'].toString(), '', null, null, 'now()', data.remarks, 'nigo', 'OFFLINE', 'REGRENEWAL'])

        if (res['rowCount'] > 0) {
            let penres = await pool.query(`select * from amfi_distributer_master_pending where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])

            if (penres['rowCount'] > 0) {
                await pool.query(`update amfi_distributer_master_pending set "nigo"=true,modified_date='now()' where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])
            }

            return res['rows'][0]['id'];
        }
    }
    return null;
}

rejectUpdatesToNigo = async (data) => {
    let res = await pool.query(`INSERT INTO tbl_reg_ren_nigo
    ("reg_ren_req_ref", "nigo_ref", "pan_no", "nigo_upda_date", "documents_clob", "documents", created_by, modified_by, modified_date,"remarks","req_type","source",register_type)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)returning "id"`, [data['type_of_issue'].toString(), data.application_reference_no, data.pan_no, 'now()', data['documents_to_reupload'].toString(), '', null, null, 'now()', data.remarks, 'nigo', 'OFFLINE', 'UPDATE'])

    if (res['rowCount'] > 0) {
        return res['rows'][0]['id'];
    }
    return null;
}

registrationActivate = async (data) => {
    helper.saveErrorAuditLogs(data, '', 'ACTIVATE1')
    let pending_res_data = await pool.query(`select *  from amfi_distributer_master_pending where "id"=$1`, [data.id])
    if (pending_res_data['rowCount'] > 0) {
        let pendingres = pending_res_data['rows'][0]
        let arn_no = 0;
        let euin_no = 0;
        let arn_number = '';
        let euin_number = ''
        let coporate_res = null;
        let date_of_passing_test = null
        let certificate_number = ''
        let validity_from = null;
        let validity_to = null;

        if (pendingres['application_type'] == 'ARN') {
            let pending_coporate_res = await pool.query(`select * from amfi_corporate_master_pending where "distributer_master_id" =$1`, [data.id])
            if (pending_coporate_res['rowCount'] > 0) {
                coporate_res = pending_coporate_res['rows'][0]
            }
        }
        if (pendingres['renewal_type'] == 'RENEWAL') {
            arn_number = pendingres['arn_number']
            euin_number = pendingres['euin_number']

            let app_res = await pool.query(`select "id" from amfi_distributer_master_approved where "pan_no"=$1`, [pendingres['pan_no']])
            if (app_res['rowCount'] > 0) {
                await pool.query(`delete from amfi_corporate_master_approved where "distributer_master_id"=$1`, [app_res['rows'][0]['id']]);
                await pool.query(`delete from amfi_distributer_master_approved where "pan_no"=$1`, [pendingres['pan_no']]);
            }

        }
        else {

            let select_counter = await pool.query(`select * from amfi_counter`)
            if (select_counter['rowCount'] > 0) {
                if (pendingres['application_type'] == 'ARN') {
                    arn_no = select_counter['rows'][0]['arncount'] + 1
                    arn_number = 'ARN' + '-' + arn_no
                }
                else if (pendingres['application_type'] == 'EUIN') {
                    arn_no = select_counter['rows'][0]['arncount']
                }
                euin_no = select_counter['rows'][0]['euincount'] + 1
                euin_number = 'EUIN' + '-' + euin_no;
                await pool.query(`update amfi_counter set "arncount"='${arn_no}',"euincount"='${euin_no}'`)

            }
        }


        let category_res = await pool.query(`select "exam_code" from tbl_amfi_category_master where "category_code"=$1`, [pendingres['category_of_corporation']])

        if (category_res['rowCount'] > 0) {
            let nism_res = await pool.query(`select  to_char("nism_certificate_date",'YYYY-MM-DD') as date_of_passing_test,"nism_certificate_no" as certificate_number,to_char("validity_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("validity_to",'YYYY-MM-DD') AS date_of_cpe_to  from tbl_user_nism_details  where "nism_category"=$1 and "pan_no"=$2 order by "created_date" desc`, [category_res['rows'][0]['exam_code'], data['pan_no']])


            if (nism_res['rowCount'] > 0) {
                // date_of_passing_test = nism_res['rows'][0]['date_of_passing_test']
                // certificate_number = nism_res['rows'][0]['certificate_number']
                // validity_from = nism_res['rows'][0]['date_of_cpe_from']
                // validity_to = nism_res['rows'][0]['date_of_cpe_to']
            }
        }

        // if (pendingres['renewal_type'] == 'RENEWAL') {
        //     let current_date = moment().format('YYYY-MM-DD');
        //     validity_from = current_date;
        //     // validity_to = moment(current_date, 'YYYY-MM-DD').add(3, 'years');
        // }


        let insert_approved = `INSERT INTO amfi_distributer_master_approved( first_name, middle_name, last_name, gender, date_of_birth, pan_no, gstn, "whether_kyd_Compliant", certificate_number, date_of_passing_test, address1, address2, address3, city, pincode, state, country, telephone_number, fax, mobile_no, email_id, qualification, university, year_of_passing, name_of_bank, branch, bank_city, "account_Number", ifsc, account_type, micr, dd_cheque_number, dd_cheque_date, amount, drawn_on_bank_branch, signature, place, sign_date, undertaking_consent, kyd_source, cpe_certificate_number, date_of_cpe_from, distributor_category, arn_id, name_of_organisation, utr_no, type_of_distributor, distributer_master_status, created_by, modified_by, modified_date, application_type, date_of_cpe_to, bank_proof_filepath, pancard_filepath, adharcard_filepath, photo_filepath, signature_filepath, registration_type, date_of_appointment, designation, description_of_responsibilities, company_address1, company_address2, company_address3, company_pincode, company_city, company_state, arn_number, euin_number, gst_filepath, application_reference_no, document_checklist, address_proof_filepath, nism_certificate_filepath, kyd_acknowledge_filepath, priority, current_action, fo1_verified, fo2_verified, gst_verified, gst_verified_by, renewal_type,photo_thumbnail,category_of_corporation,validity_from, validity_to,single_merged_doc)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42,$43,$44,$45,$46,$47,$48,$49,$50,$51,$52,$53,$54,$55,$56,$57,$58,$59,$60,$61,$62,$63,$64,$65,$66,$67,$68,$69,$70,$71,$72,$73,$74,$75,$76,$77,$78,$79,$80,$81,$82,$83,$84,$85,$86,$87,$88) returning "id","arn_number","euin_number"`

        let dis_ins = await pool.query(insert_approved, [pendingres['first_name'], pendingres['middle_name'], pendingres['last_name'], pendingres['gender'], pendingres['date_of_birth'], pendingres['pan_no'], pendingres['gstn'], pendingres['whether_kyd_Compliant'], pendingres['certificate_number'], pendingres['date_of_passing_test'], pendingres['address1'], pendingres['address2'], pendingres['address3'], pendingres['city'], pendingres['pincode'], pendingres['state'], pendingres['country'], pendingres['telephone_number'], pendingres['fax'], pendingres['mobile_no'], pendingres['email_id'], pendingres['qualification'], pendingres['university'], pendingres['year_of_passing'], pendingres['name_of_bank'], pendingres['branch'], pendingres['bank_city'], pendingres['account_Number'], pendingres['ifsc'], pendingres['account_type'], pendingres['micr'], pendingres['dd_cheque_number'], pendingres['dd_cheque_date'], pendingres['amount'], pendingres['drawn_on_bank_branch'], pendingres['signature'], pendingres['place'], pendingres['sign_date'], pendingres['undertaking_consent'], pendingres['kyd_source'], pendingres['cpe_certificate_number'], pendingres['date_of_cpe_from'], pendingres['distributor_category'], pendingres['arn_id'], pendingres['name_of_organisation'], pendingres['utr_no'], pendingres['type_of_distributor'], 'Active', data.user_id, data.user_id, 'now()', pendingres['application_type'], pendingres['date_of_cpe_to'], pendingres['bank_proof_filepath'], pendingres['pancard_filepath'], pendingres['adharcard_filepath'], pendingres['photo_filepath'], pendingres['signature_filepath'], pendingres['registration_type'], pendingres['date_of_appointment'], pendingres['designation'], pendingres['description_of_responsibilities'], pendingres['company_address1'], pendingres['company_address2'], pendingres['company_address3'], pendingres['company_pincode'], pendingres['company_city'], pendingres['company_state'], arn_number, euin_number, pendingres['gst_filepath'], pendingres['application_reference_no'], pendingres['document_checklist'], pendingres['address_proof_filepath'], pendingres['nism_certificate_filepath'], pendingres['kyd_acknowledge_filepath'], pendingres['priority'], pendingres['current_action'], pendingres['fo1_verified'], pendingres['fo2_verified'], pendingres['gst_verified'], pendingres['gst_verified_by'], pendingres['renewal_type'], pendingres['photo_thumbnail'], pendingres['category_of_corporation'], pendingres['validity_from'], pendingres['validity_to'], pendingres['single_merged_doc']])


        if (dis_ins['rowCount'] > 0) {

            if (coporate_res != null) {
                let insert_cop_approved = await pool.query(`INSERT INTO amfi_corporate_master_approved("pan_no", engaged_as_insurance_agent, registered_insurance_company, "whether_group_company_has_arn", name_of_group_company, "arn_of_group_company", no_of_proposed_branches_for_sales, "no_of_proposed_employees_for_sales",no_of_certified_employees, no_of_employess_under_coporate, name_of_signatory, designation_of_signatory, "mobile_no_of_signatory", structure_of_corporate, countries_proposed_for_distribution, list_of_activities_other_than_mf_distribution, group_company_has_arn, "name_of_prop_firm", corporate_master_status, created_by, modified_by, modified_date, distributer_master_id,new_cadre_category)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)`, [pendingres['pan_no'], coporate_res['engaged_as_insurance_agent'], coporate_res['registered_insurance_company'], coporate_res['whether_group_company_has_arn'], coporate_res['name_of_group_company'], coporate_res['ARN_of_group_company'], coporate_res['no_of_proposed_branches_for_sales'], coporate_res['no_of_proposed_employees_for_sales'], coporate_res['no_of_certified_employees'], coporate_res['no_of_employess_under_coporate'], coporate_res['name_of_signatory'], coporate_res['designation_of_signatory'], coporate_res['mobile_no_of_signatory'], coporate_res['structure_of_corporate'], coporate_res['countries_proposed_for_distribution'], coporate_res['list_of_activities_other_than_mf_distribution'], coporate_res['group_company_has_arn'], coporate_res['name_of_prop_firm'], 'Active', null, null, 'now()', dis_ins['rows'][0]['id'], coporate_res['new_cadre_category']])
            }

            if (pendingres['renewal_type'] == 'REGISTRATION') {
                let password = '12345678'
                let user_profile = pendingres['application_type']
                // let str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$';
                // for (let i = 1; i <= 8; i++) {
                //     var char = Math.floor(Math.random() * str.length + 1);
                //     password += str.charAt(char)
                // }
                let user_name = ''
                if (user_profile == 'ARN') {
                    user_name = arn_number;
                }
                else if (user_profile == 'EUIN') {
                    user_name = euin_number;
                }

                let insert_user = await pool.query(`INSERT INTO amfi_user_login ( user_name, "password", last_login_datetime, active, user_profile, first_login, status, modified_date,"pan_no")VALUES($1,$2,$3, $4,$5,$6, $7, $8,$9) RETURNING "user_id"`, [user_name, password, 'now()', true, user_profile, true, true, 'now()', pendingres['pan_no']]
                )

                if (insert_user['rowCount'] > 0) {
                    await pool.query(`update amfi_distributer_master_approved set "user_id"=$1 where "id"=$2`, [insert_user['rows'][0]['user_id'], dis_ins['rows'][0]['id']])
                }
            }
            else {
                let login_res = await pool.query(`select "user_id" from amfi_user_login where "user_name"=$1`, [pendingres['pan_no']])
                if (login_res['rowCount'] > 0) {
                    await pool.query(`update amfi_distributer_master_approved set "user_id"=$1 where "id"=$2`, [login_res['rows'][0]['user_id'], dis_ins['rows'][0]['id']])
                }
            }
            await pool.query(`delete from amfi_corporate_master_pending where "distributer_master_id"=$1`, [data.id]);
            await pool.query(`delete from amfi_distributer_master_pending where "id"=$1`, [data.id]);
            await helper.saveErrorAuditLogs(data, '', 'ACTIVATE2')

            await saveApproveToApprovehistory(pendingres['pan_no'], pendingres['application_reference_no'])

            await helper.saveErrorAuditLogs(data, dis_ins, 'ACTIVATE3')

            let reqData = {
                "pan_no": pendingres['pan_no'],
                "application_reference_no": pendingres['application_reference_no'],
                "req_status": "Active",
            }
            await updateRegRenHistory(reqData);

            await pool.query(`INSERT INTO tbl_chng_req_hist(
           pan_no, req_type, appl_date, appl_uploads, req_status, key_value_edited, key_value_old, key_value_new, modified_date, application_reference_no,created_by,modified_by,source,"req_status_code",is_amount_paid) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) returning "id","application_reference_no"`, [pendingres['pan_no'], 'DUP', 'now()', '', 'Completed', '', '', '', 'now()', pendingres['application_reference_no'], null, null, 'OFFLINE', 'COMPLETED', true])

            return dis_ins['rows'][0];
        }

        return null;
    }
}

getNigoApplicantDetails = async (data) => {
    let select_type = await pool.query(`select "register_type","documents_clob","reg_ren_req_ref" from tbl_reg_ren_nigo where "pan_no"=$1 and "nigo_ref"=$2 and "status"=true`, [data.pan_no, data.application_reference_no])
    if (select_type['rowCount'] > 0) {
        let res;
        if (select_type['rows'][0]['register_type'] == 'REGRENEWAL') {
            res = await pool.query(`select "id","pan_no","first_name","middle_name","last_name","gender",to_char("date_of_birth",'YYYY-MM-DD') AS date_of_birth,"gstn","whether_kyd_Compliant","certificate_number",to_char("date_of_passing_test",'YYYY-MM-DD') AS date_of_passing_test,"cpe_certificate_number",to_char("date_of_cpe_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("date_of_cpe_to",'YYYY-MM-DD') as date_of_cpe_to,address1,address2,address3,city,pincode,state,telephone_number,"qualification","university","year_of_passing" ,"name_of_bank","branch","account_Number","micr","account_type","dd_cheque_number",to_char("dd_cheque_date",'YYYY-MM-DD') AS dd_cheque_date,"amount","drawn_on_bank_branch","document_checklist" AS checklist,"ifsc",to_char("date_of_appointment",'YYYY-MM-DD') as date_of_appointment,"arn_id" as arn_of_organisation,"name_of_organisation","designation","registration_type","application_reference_no","address_proof_filepath","nism_certificate_filepath","photo_filepath","signature_filepath","kyd_acknowledge_filepath","single_merged_doc" from amfi_distributer_master_pending where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])
        }
        else {
            res = await pool.query(`select "id","pan_no","first_name","middle_name","last_name","gender",to_char("date_of_birth",'YYYY-MM-DD') AS date_of_birth,"gstn","whether_kyd_Compliant","certificate_number",to_char("date_of_passing_test",'YYYY-MM-DD') AS date_of_passing_test,"cpe_certificate_number",to_char("date_of_cpe_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("date_of_cpe_to",'YYYY-MM-DD') as date_of_cpe_to,address1,address2,address3,city,pincode,state,telephone_number,"qualification","university","year_of_passing" ,"name_of_bank","branch","account_Number","micr","account_type","dd_cheque_number",to_char("dd_cheque_date",'YYYY-MM-DD') AS dd_cheque_date,"amount","drawn_on_bank_branch","document_checklist" AS checklist,"ifsc",to_char("date_of_appointment",'YYYY-MM-DD') as date_of_appointment,"arn_id" as arn_of_organisation,"name_of_organisation","designation","registration_type","application_reference_no","address_proof_filepath","nism_certificate_filepath","photo_filepath","signature_filepath","kyd_acknowledge_filepath","single_merged_doc" from amfi_distributer_master_approved_history where "pan_no"=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])
        }

        if (res['rowCount'] > 0) {
            if (res['rows'][0]['checklist'] != null) {
                res['rows'][0]['document_checkList'] = res['rows'][0]['checklist'].split(',')
            }
            if (select_type['rows'][0]['documents_clob'] != null) {
                res['rows'][0]['document_to_reupload'] = select_type['rows'][0]['documents_clob'].split(',')
            }

            let reason_arr = select_type['rows'][0]['reg_ren_req_ref'].split(',');
            res['rows'][0]['reason_for_nigo_id'] = reason_arr;
            let reason_str = '';
            for (let i = 0; i < reason_arr.length; i++) {
                let reasonid = reason_arr[i]
                reason_str += '\'' + reasonid + '\'' + ','
            }
            reason_str = reason_str.slice(0, reason_str.length - 1);

            let select_reason = await pool.query(`select "req_desc" from tbl_dropdown_master  where "status" =true and "req_code" in(${reason_str}) and "req_type"='TYPEOFISSUE' `)

            if (select_reason['rowCount'] > 0) {
                res['rows'][0]['reason_for_nigo'] = []
                for (let i = 0; i < select_reason['rows'].length; i++) {
                    res['rows'][0]['reason_for_nigo'].push(select_reason['rows'][i]['req_desc']);
                }
            }

            return res['rows'];
        }
        return null;
    }
    return null;
}

submitNigoForAuthorisation = async (data, current_action, current_action_code) => {
    let document_checklist = null;
    if (data['document_checkList'] !== null && data['document_checkList'] !== undefined && data['document_checkList'] !== '') {
        document_checklist = data['document_checkList'].toString()
    }

    let select_type = await pool.query(`select "register_type" from tbl_reg_ren_nigo where "pan_no"=$1 and "nigo_ref"=$2 and "status"=true`, [data.pan_no, data.application_reference_no])
    if (select_type['rowCount'] > 0) {
        let res;
        if (select_type['rows'][0]['register_type'] == 'REGRENEWAL') {

            res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
         "modified_date"=$2, "modified_by"=$3,"current_action"=$4 ,"first_name"=$6,"middle_name"=$7,"last_name"=$8,"gender"=$9 ,"date_of_birth"=$10,"gstn"=$11,"whether_kyd_Compliant"=$12,"certificate_number"=$13,"date_of_passing_test"=$14,"cpe_certificate_number"=$15,"date_of_cpe_from"=$16,"date_of_cpe_to"=$17,"address1"=$18,"address2"=$19,"address3"=$20,"city"=$21,"pincode"=$22,"state"=$23,"telephone_number"=$24,"qualification"=$25,"university"=$26,"year_of_passing"=$27,"name_of_bank"=$28,"branch"=$29,"account_Number"=$30,"micr"=$31 ,"account_type"=$32,"dd_cheque_number"=$33,"dd_cheque_date"=$34,"amount"=$35,"drawn_on_bank_branch"=$36,"document_checklist"=$37,"current_action_code"=$38,"ifsc"=$39,"arn_id"=$40,"date_of_appointment"=$41,"name_of_organisation"=$42,"designation"=$43,"address_proof_filepath"=$44,"nism_certificate_filepath"=$45,"photo_filepath"=$46,"signature_filepath"=$47,"kyd_acknowledge_filepath"=$48,"single_merged_doc"=$49 where "application_reference_no"=$1  and "pan_no"=$5 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['user_id'], current_action, data['pan_no'], data['first_name'], data['middle_name'], data['last_name'], data['gender'], data['date_of_birth'], data['gstn'], data['whether_kyd_Compliant'], data['certificate_number'], data['date_of_passing_test'], data['cpe_certificate_number'], data['date_of_cpe_from'], data['date_of_cpe_to'], data['address1'], data['address2'], data['address3'], data['city'], data['pincode'], data['state'], data['telephone_number'], data['qualification'], data['university'], data['year_of_passing'], data['name_of_bank'], data['branch'], data['account_Number'], data['micr'], data['account_type'], data['dd_cheque_number'], data['dd_cheque_date'], data['amount'], data['drawn_on_bank_branch'], document_checklist, current_action_code, data['ifsc'], data['arn_of_organisation'], data['date_of_appointment'], data['name_of_organisation'], data['designation'], data['address_proof_filepath'], data['nism_certificate_filepath'], data['photo_filepath'], data['signature_filepath'], data['kyd_acknowledge_filepath'], data['single_merged_doc']])
        }
        else {
            res = await pool.query(`UPDATE amfi_distributer_master_approved_history SET 
            "modified_date"=$2, "modified_by"=$3,"current_action"=$4 ,"first_name"=$6,"middle_name"=$7,"last_name"=$8,"gender"=$9 ,"date_of_birth"=$10,"gstn"=$11,"whether_kyd_Compliant"=$12,"certificate_number"=$13,"date_of_passing_test"=$14,"cpe_certificate_number"=$15,"date_of_cpe_from"=$16,"date_of_cpe_to"=$17,"address1"=$18,"address2"=$19,"address3"=$20,"city"=$21,"pincode"=$22,"state"=$23,"telephone_number"=$24,"qualification"=$25,"university"=$26,"year_of_passing"=$27,"name_of_bank"=$28,"branch"=$29,"account_Number"=$30,"micr"=$31 ,"account_type"=$32,"dd_cheque_number"=$33,"dd_cheque_date"=$34,"amount"=$35,"drawn_on_bank_branch"=$36,"document_checklist"=$37,"current_action_code"=$38,"ifsc"=$39,"arn_id"=$40,"date_of_appointment"=$41,"name_of_organisation"=$42,"designation"=$43,"address_proof_filepath"=$44,"nism_certificate_filepath"=$45,"photo_filepath"=$46,"signature_filepath"=$47,"kyd_acknowledge_filepath"=$48 ,"single_merged_doc"=$49 where "application_reference_no"=$1  and "pan_no"=$5 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['user_id'], current_action, data['pan_no'], data['first_name'], data['middle_name'], data['last_name'], data['gender'], data['date_of_birth'], data['gstn'], data['whether_kyd_Compliant'], data['certificate_number'], data['date_of_passing_test'], data['cpe_certificate_number'], data['date_of_cpe_from'], data['date_of_cpe_to'], data['address1'], data['address2'], data['address3'], data['city'], data['pincode'], data['state'], data['telephone_number'], data['qualification'], data['university'], data['year_of_passing'], data['name_of_bank'], data['branch'], data['account_Number'], data['micr'], data['account_type'], data['dd_cheque_number'], data['dd_cheque_date'], data['amount'], data['drawn_on_bank_branch'], document_checklist, current_action_code, data['ifsc'], data['arn_of_organisation'], data['date_of_appointment'], data['name_of_organisation'], data['designation'], data['address_proof_filepath'], data['nism_certificate_filepath'], data['photo_filepath'], data['signature_filepath'], data['kyd_acknowledge_filepath'], data['single_merged_doc']])
        }

        if (res['rowCount'] > 0) {
            let status = true;
            if (current_action_code == 'COMPLETED') {
                status = false;
            }

            await pool.query(`UPDATE tbl_reg_ren_nigo SET "modified_date"=$2, "modified_by"=$3,"req_status"=$4,"req_status_code"=$6,"status"=$7 where "nigo_ref" =$1 and "pan_no"=$5 returning "nigo_ref"`, [data['application_reference_no'], 'now()', data['user_id'], current_action, data['pan_no'], current_action_code, status]);
            return res['rows'][0]['application_reference_no'];
        }

        return null;
    }

    return null;
}

authoriseNigoApplication = async (data) => {
    let resObj = {};
    let select_register_type = await pool.query(`select "register_type" from tbl_reg_ren_nigo where "pan_no"=$1 and "nigo_ref"=$2 and "status"=true`, [data.pan_no, data.application_reference_no])
    if (select_register_type['rowCount'] > 0) {
        resObj['nigoTypedata'] = select_register_type['rows'][0];
    }

    let select_type = await pool.query(`select "application_type","registration_type","renewal_type","id"  from amfi_distributer_master_pending where "pan_no" =$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no])
    if (select_type['rowCount'] > 0) {
        resObj['dis_pendingdata'] = select_type['rows'][0];
    }


    return resObj;
}

updateNigoApproved = async (data, current_action, current_action_code) => {
    let document_checklist = null;
    if (data['document_checkList'] !== null && data['document_checkList'] !== undefined && data['document_checkList'] !== '') {
        document_checklist = data['document_checkList'].toString()
    }
    res = await pool.query(`UPDATE amfi_distributer_master_approved_history SET 
            "modified_date"=$2, "modified_by"=$3,"current_action"=$4 ,"first_name"=$6,"middle_name"=$7,"last_name"=$8,"gender"=$9 ,"date_of_birth"=$10,"gstn"=$11,"whether_kyd_Compliant"=$12,"certificate_number"=$13,"date_of_passing_test"=$14,"cpe_certificate_number"=$15,"date_of_cpe_from"=$16,"date_of_cpe_to"=$17,"address1"=$18,"address2"=$19,"address3"=$20,"city"=$21,"pincode"=$22,"state"=$23,"telephone_number"=$24,"qualification"=$25,"university"=$26,"year_of_passing"=$27,"name_of_bank"=$28,"branch"=$29,"account_Number"=$30,"micr"=$31 ,"account_type"=$32,"dd_cheque_number"=$33,"dd_cheque_date"=$34,"amount"=$35,"drawn_on_bank_branch"=$36,"document_checklist"=$37,"current_action_code"=$38,"ifsc"=$39,"arn_id"=$40,"date_of_appointment"=$41,"name_of_organisation"=$42,"designation"=$43,"address_proof_filepath"=$44,"nism_certificate_filepath"=$45,"photo_filepath"=$46,"signature_filepath"=$47,"kyd_acknowledge_filepath"=$48,"single_merged_doc"=$49 where "application_reference_no"=$1  and "pan_no"=$5 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['user_id'], current_action, data['pan_no'], data['first_name'], data['middle_name'], data['last_name'], data['gender'], data['date_of_birth'], data['gstn'], data['whether_kyd_Compliant'], data['certificate_number'], data['date_of_passing_test'], data['cpe_certificate_number'], data['date_of_cpe_from'], data['date_of_cpe_to'], data['address1'], data['address2'], data['address3'], data['city'], data['pincode'], data['state'], data['telephone_number'], data['qualification'], data['university'], data['year_of_passing'], data['name_of_bank'], data['branch'], data['account_Number'], data['micr'], data['account_type'], data['dd_cheque_number'], data['dd_cheque_date'], data['amount'], data['drawn_on_bank_branch'], document_checklist, current_action_code, data['ifsc'], data['arn_of_organisation'], data['date_of_appointment'], data['name_of_organisation'], data['designation'], data['address_proof_filepath'], data['nism_certificate_filepath'], data['photo_filepath'], data['signature_filepath'], data['kyd_acknowledge_filepath'], data['single_merged_doc']])


    if (res['rowCount'] > 0) {
        return res['rows'][0]['application_reference_no'];
    }
}

searchDetailsByPanNoForNigo = async (data) => {
    let res = await pool.query(`select arn_number ,euin_number ,mobile_no ,email_id  from amfi_distributer_master_pending where pan_no =$1`, [data.pan_no])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

cancelAssignedRegisration = async (data) => {
    let select_data = await pool.query(`select "current_action_code","fo1_verified"
     from amfi_distributer_master_pending where "application_reference_no"=$1 and "pan_no"=$2`, [data.application_reference_no, data.pan_no])

    if (select_data['rowCount'] > 0) {
        let current_action = ''
        let current_action_code = ''
        let fo1_verified = null;
        let fo2_verified = null;
        if (select_data['rows'][0]['current_action_code'] == 'ASSIGNED_BO1') {
            current_action = 'Start Entry'
            current_action_code = 'START_ENTRY'
            fo1_verified = null;
            fo2_verified = null;
        }
        else if (select_data['rows'][0]['current_action_code'] == 'ASSIGNED_BO2') {
            current_action = 'Authorise';
            current_action_code = 'AUTHORISE';
            fo1_verified = select_data['rows'][0]['fo1_verified'];
            fo2_verified = null
        }
        let res = await pool.query(`UPDATE amfi_distributer_master_pending SET 
            "modified_date"=$3, "modified_by"=$4,"current_action"=$5,"fo1_verified"=$6,"current_action_code"=$7,"fo2_verified"=$8 where "application_reference_no"=$1 and "pan_no"=$2 returning "id"`, [data.application_reference_no, data.pan_no, 'now()', data['user_id'], current_action, fo1_verified, current_action_code, fo2_verified])
        if (res['rowCount'] > 0) {
            return res['rows'][0]['id'];
        }
    }
    return null;
}

cancelAssignedUpdate = async (data) => {
    let select_data = await pool.query(`select req_status_code ,req_status ,bo1_verified ,bo2_verified  from tbl_chng_req_hist where application_reference_no=$1 and pan_no=$2 and status=true`, [data.application_reference_no, data.pan_no])

    if (select_data['rowCount'] > 0) {
        let req_status = ''
        let req_status_code = ''
        let bo1_verified = null;
        let bo2_verified = null;
        if (select_data['rows'][0]['req_status_code'] == 'ASSIGNED_BO1') {
            req_status = 'Start Entry'
            req_status_code = 'START_ENTRY'
            bo1_verified = null;
            bo2_verified = null;
        }
        else if (select_data['rows'][0]['req_status_code'] == 'ASSIGNED_BO2') {
            req_status = 'Authorise';
            req_status_code = 'AUTHORISE';
            bo1_verified = select_data['rows'][0]['bo1_verified'];
            bo2_verified = null
        }
        let res = await pool.query(`UPDATE tbl_chng_req_hist SET 
       "modified_date"=$2, "modified_by"=$3,"req_status"=$4,"bo1_verified"=$5,"req_status_code"=$7,"bo2_verified"=$8 where "application_reference_no" =$1 and "pan_no"=$6 returning "application_reference_no"`, [data['application_reference_no'], 'now()', data['user_id'], req_status, bo1_verified, data['pan_no'], req_status_code, bo2_verified])

        if (res['rowCount'] > 0) {
            return res['rows'][0].application_reference_no;
        }
    }
    return null;

}

cancelAssignedNigo = async (data) => {
    let select_data = await pool.query(`select req_status_code ,req_status ,bo1_verified ,bo2_verified  from tbl_reg_ren_nigo where nigo_ref=$1 and pan_no=$2 and status=true`, [data.application_reference_no, data.pan_no])
    if (select_data['rowCount'] > 0) {
        let req_status = ''
        let req_status_code = ''
        let bo1_verified = null;
        let bo2_verified = null;
        if (select_data['rows'][0]['req_status_code'] == 'ASSIGNED_BO1') {
            req_status = 'Start Entry'
            req_status_code = 'START_ENTRY'
            bo1_verified = null;
            bo2_verified = null;
        }
        else if (select_data['rows'][0]['req_status_code'] == 'ASSIGNED_BO2') {
            req_status = 'Authorise';
            req_status_code = 'AUTHORISE';
            bo1_verified = select_data['rows'][0]['bo1_verified'];
            bo2_verified = null
        }

        let res = await pool.query(`UPDATE tbl_reg_ren_nigo SET 
        "modified_date"=$2, "modified_by"=$3,"req_status"=$4,"bo1_verified"=$5,"req_status_code"=$7,"bo2_verified"=$8 where "nigo_ref" =$1 and "pan_no"=$6 returning "nigo_ref"`, [data['application_reference_no'], 'now()', data['user_id'], req_status, bo1_verified, data['pan_no'], req_status_code, bo2_verified])

        if (res['rowCount'] > 0) {
            return res['rows'][0].nigo_ref;
        }

    }
    return null;
}


getAuthoriseDuplicateCardUpdated = async (data) => {
    let res = await pool.query(`select to_char(A.appl_date,'YYYY-MM-DD') AS date_of_submission,B.arn_number,B.first_name ,B.middle_name ,B.last_name,A.pan_no,A.appl_uploads,A."source",A."key_value_new" as reason_for_duplicate from tbl_chng_req_hist A,amfi_distributer_master_approved B where A.application_reference_no=$1 and A.pan_no =B.pan_no and A.status =true`, [data.application_reference_no])

    if (res['rowCount'] > 0) {
        let file_uploadid = res['rows'][0]['appl_uploads'];
        res['rows'][0]['duplicate_filepath_base64'] = null;
        var num1 = parseInt(file_uploadid) || 0;
        if (num1 > 0) {
            let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_uploadid])
            if (file_res['rowCount'] > 0) {
                let imgBuff = file_res['rows'][0]['image'];
                res['rows'][0]['duplicate_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                res['rows'][0]['duplicate_filepath_image_type'] = file_res['rows'][0]['image_type'];
                res['rows'][0]['duplicate_filename'] = file_res['rows'][0]['file_name']

                return res['rows'];
            }
        }
    }
    return null;
}

submitForAuthoriseDupCardUpdated = async (data) => {
    let res = await pool.query(`update tbl_chng_req_hist set req_status='Authorise',modified_by =$4, modified_date =$3,"req_status_code"=$5, key_value_new=$6,is_amount_paid=$7 where application_reference_no =$1 and pan_no =$2 `, [data.application_reference_no, data.pan_no, 'now()', data.user_id, 'AUTHORISE', data.reason_for_duplicate, true])

    if (res['rowCount'] > 0) {
        return data.application_reference_no;

    }

    return null;
}

authoriseDupCardUpdated = async (data) => {
    return await updateChangeReqHistryAuthorised(data);
}

getCardPrintingList = async (data) => {
    let res = await pool.query(`select A.req_type, A.id,A.pan_no,A.application_reference_no,B.first_name, B.middle_name, B.last_name,B.arn_number,A.priority, A.source,A.req_status,B."euin_number",C.category_description as arn_type,to_char(B.validity_from,'YYYY-MM-DD') as validity_from, to_char(B.validity_to,'YYYY-MM-DD') as validity_to,B.address1 ,B.address2 ,B.address3 ,B.state ,B.city, B.pincode,B.photo_thumbnail,B.signature_filepath,B.mobile_no ,B.renewal_type from tbl_chng_req_hist A,amfi_distributer_master_approved B,tbl_amfi_category_master C where A."pan_no"=B."pan_no" and B.category_of_corporation =C.category_code  and C.status =true and A.req_type=$1 and (A."req_status_code"='COMPLETED')  and A."is_amount_paid"=true`, ['DUP'])

    if (res['rowCount'] > 0) {
        for (let i = 0; i < res['rows'].length; i++) {
            res['rows'][i]['type'] = 'Duplicate'
        }
        return res['rows'];
    }

    return null;
}

payForIssueDuplicate = async (data) => {
    let application_reference_no = ''
    // let select_counter = await pool.query(`select * from amfi_counter`)
    // if (select_counter['rowCount'] > 0) {
    //     let applicount = select_counter['rows'][0]['application_reference_count'] + 1
    //     application_reference_no = 'APP-REF' + applicount
    //     await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
    // }
    application_reference_no = await helper.generateApplicationNumber()
    let res = await pool.query(`INSERT INTO tbl_chng_req_hist(
        pan_no, req_type, appl_date, appl_uploads, req_status, key_value_edited, key_value_old, key_value_new, modified_date, application_reference_no,created_by,modified_by,source,"req_status_code","is_amount_paid") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) returning "application_reference_no"`, [data.pan_no, 'DUP', 'now()', '', 'Completed', '', '', data.reason_for_duplicate, 'now()', application_reference_no, data.user_id, data.user_id, 'ONLINE', 'COMPLETED', true])

    if (res['rowCount'] > 0) {
        return res['rows'][0]['application_reference_no']
    }
    return null;
}

getCardIssueStatus = async (data) => {

}

updateFOBOtoken = async (user_id, user_name, token) => {
    await pool.query(`update amfi_user_login set "token_key"=$1 where "user_id"=$2 and "user_name"=$3 `, [token, user_id, user_name])
}

logoutFOBO = async (data) => {
    let res = await pool.query(`select "user_id","user_name","first_login","user_profile","user_role" from amfi_user_login where "user_name"=$1 and "user_id"=$2`, [data.user_name, data.user_id])

    if (res['rowCount'] > 0) {
        await pool.query(`delete from amfi_user_session where "user_id"=$1 and "user_name"=$2`, [data.user_id, data.user_name])

        await pool.query(`update amfi_user_login set "token_key"=$1 where "user_id"=$2 and "user_name"=$3`, ['', res['rows'][0]['user_id'], data.user_name])

        return res['rows'][0];
    }
    return null;
}

getAuthoriseSignatoryUpdated = async (data) => {
    let res = await pool.query(`select to_char(A.appl_date,'YYYY-MM-DD') AS date_of_submission,B.arn_number,B.first_name ,B.middle_name ,B.last_name,A.pan_no,A.appl_uploads,A."source",B."signatory_filepath"  from tbl_chng_req_hist A,amfi_distributer_master_approved_history B where A.application_reference_no=$1 and A.pan_no =B.pan_no and A.status =true and A."application_reference_no"=B."application_reference_no"`, [data.application_reference_no])

    if (res['rowCount'] > 0) {
        let file_uploadid = res['rows'][0]['appl_uploads'];
        let new_Sign_id = res['rows'][0]['signatory_filepath'];
        res['rows'][0]['uploaded_filepath_base64'] = null;
        res['rows'][0]['new_signature_base64'] = null;
        var num1 = parseInt(file_uploadid) || 0;
        var num2 = parseInt(new_Sign_id) || 0;
        if (num1 > 0) {
            let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_uploadid])
            if (file_res['rowCount'] > 0) {
                let imgBuff = file_res['rows'][0]['image'];
                res['rows'][0]['uploaded_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                res['rows'][0]['uploaded_filepath_image_type'] = file_res['rows'][0]['image_type'];
                res['rows'][0]['uploaded_filename'] = file_res['rows'][0]['file_name']
            }
        }
        if (num2 > 0) {
            let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [new_Sign_id])
            if (file_res['rowCount'] > 0) {
                let imgBuff = file_res['rows'][0]['image'];
                res['rows'][0]['new_signature_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                res['rows'][0]['new_signature_image_type'] = file_res['rows'][0]['image_type'];
                res['rows'][0]['new_signature_filename'] = file_res['rows'][0]['file_name']


            }
        }

        return res['rows'];
    }
    return null;
}


submitForAuthoriseSignatoryUpdate = async (data) => {
    let resdata = await pool.query(`update amfi_distributer_master_approved_history set "signatory_filepath" =$2, modified_date=$3 ,modified_by=$4 where pan_no=$1 and "application_reference_no"=$5`, [data.pan_no, data.signatory_filepath, 'now()', data.user_id, data.application_reference_no])
    if (resdata['rowCount'] > 0) {
        let res = await updateSubmitForAuthorise(data);
        return res;
    }
    return null;
}


authoriseSignatory = async (data) => {
    let res = await pool.query(`update amfi_distributer_master_approved set "signatory_filepath" =$2, modified_date=$3 ,modified_by=$4 where pan_no=$1`, [data.pan_no, data.signatory_filepath, 'now()', data.user_id])

    if (res['rowCount'] > 0) {
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}

getAuthoriseCategoryUpdated = async (data) => {
    let res = await pool.query(`select to_char(A.appl_date,'YYYY-MM-DD') AS date_of_submission,B.arn_number,A.pan_no,A.appl_uploads,A."source",B."corporation_category",B.dd_cheque_number ,B.dd_cheque_date ,B.drawn_on_bank_branch ,B.amount ,B."document_checklist" ,B.address1 ,B.address2 ,B.address3 ,B.city ,B.pincode ,B.state ,B.telephone_number ,B."account_Number" ,B.ifsc ,B.name_of_bank ,B.branch ,B.micr ,B.account_type ,B.name_of_the_distributer ,B.registration_number ,B.date_of_incorporation,B.mfs_with_which_empanelled,B.occupation_details  from tbl_chng_req_hist A,amfi_distributer_master_approved_history B where A.application_reference_no=$1 and A.pan_no =B.pan_no and A.status =true and A."application_reference_no"=B."application_reference_no"`, [data.application_reference_no])

    if (res['rowCount'] > 0) {
        let file_uploadid = res['rows'][0]['appl_uploads'];
        res['rows'][0]['uploaded_filepath_base64'] = null;
        var num1 = parseInt(file_uploadid) || 0;
        if (num1 > 0) {
            let file_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [file_uploadid])
            if (file_res['rowCount'] > 0) {
                let imgBuff = file_res['rows'][0]['image'];
                res['rows'][0]['uploaded_filepath_base64'] = imgBuff == null ? null : imgBuff.toString('base64');
                res['rows'][0]['uploaded_filepath_image_type'] = file_res['rows'][0]['image_type'];
                res['rows'][0]['uploaded_filename'] = file_res['rows'][0]['file_name']
            }
        }

        res['rows'][0]['kyd_list'] = [];
        let kyd_res = await pool.query(`select *, to_char("dob",'YYYY-MM-DD')as dob from tbl_kyd_details_history where pan_no =$1`, [res['rows'][0]['pan_no']])

        if (kyd_res['rowCount'] > 0) {
            res['rows'][0]['kyd_list'] = kyd_res['rows']
        }


        return res['rows'];
    }
    return null;
}
submitForAuthoriseCategoryUpdate = async (data) => {

    let resdata = await pool.query(`update amfi_distributer_master_approved_history set modified_date=$3 ,modified_by=$4,dd_cheque_number=$5 ,dd_cheque_date=$6 ,drawn_on_bank_branch=$7 ,amount=$8 ,document_checklist=$9,address1=$10 ,address2=$11 ,address3=$12 ,city=$13 ,pincode=$14,state=$15 ,telephone_number=$16 ,"account_Number"=$17 ,ifsc=$18 ,name_of_bank =$19,branch=$20 ,micr=$21 ,account_type=$22,name_of_the_distributer =$23,registration_number=$24 ,date_of_incorporation=$25,mfs_with_which_empanelled=$26,occupation_details=$27,corporation_category=$28 where pan_no=$1 and "application_reference_no"=$2`, [data.pan_no, data.application_reference_no, 'now()', data.user_id, data.dd_cheque_number, data.dd_cheque_date, data.drawn_on_bank_branch, data.amount, data.document_checklist, data.address1, data.address2, data.address3, data.city, data.pincode, data.state, data.telephone_no, data.account_Number, data.ifsc, data.name_of_bank, data.branch, data.micr, data.account_type, data.name_of_the_distributer, data.registration_number, data.date_of_incorporation, data.mfs_with_which_empanelled, data.occupation_details, data.corporation_category])

    if (resdata['rowCount'] > 0) {
        if ('kyd_list' in data) {
            await pool.query(`delete from tbl_kyd_details_history where "pan_no"=$1`, [data.pan_no])
            for (let i = 0; i < data['kyd_list'].length; i++) {
                let element = data['kyd_list'][i]

                await pool.query(`INSERT INTO tbl_kyd_details_history
        (pan_no, arn_id, distributer_name, fathers_name, kyd_pan_no, applicant_type, gender, dob, door_flat_no, appartment, street_name, city, pincode, state, telephone_no, bank_name, branch, account_number, micr_neft, account_type, empanelled, occupation) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)`, [data['pan_no'], element['arn_id'], element['distributer_name'], element['fathers_name'], element['kyd_pan_no'], element['applicant_type'], element['gender'], element['dob'], element['door_flat_no'], element['appartment'], element['street_name'], element['city'], element['pincode'], element['state'], element['telephone_no'], element['bank_name'], element['branch'], element['account_number'], element['micr_neft'], element['account_type'], element['empanelled'], element['occupation']]);
            }
        }
        let res = await updateSubmitForAuthorise(data);
        return res;
    }
    return null;
}

authoriseCategory = async (data) => {

    let res = await pool.query(`update amfi_distributer_master_approved set modified_date=$2 ,modified_by=$3,dd_cheque_number=$4 ,dd_cheque_date=$5 ,drawn_on_bank_branch=$6 ,amount=$7 ,document_checklist=$8,address1=$9 ,address2=$10 ,address3=$11 ,city=$12 ,pincode=$13,state=$14 ,telephone_number=$15 ,"account_Number"=$16 ,ifsc=$17 ,name_of_bank =$18,branch=$19 ,micr=$20 ,account_type=$21 where pan_no=$1`, [data.pan_no, 'now()', data.user_id, data.dd_cheque_number, data.dd_cheque_date, data.drawn_on_bank_branch, data.amount, data.document_checklist, data.address1, data.address2, data.address3, data.city, data.pincode, data.state, data.telephone_no, data.account_Number, data.ifsc, data.name_of_bank, data.branch, data.micr, data.account_type])

    if (res['rowCount'] > 0) {

        await pool.query(`update amfi_corporate_master_approved set name_of_the_distributer=$2 ,registration_number=$3 ,date_of_incorporation=$4,mfs_with_which_empanelled=$5,occupation_details=$6,corporation_category=$7 where pan_no=$1`, [data.pan_no, data.name_of_the_distributer, data.registration_number, data.date_of_incorporation, data.mfs_with_which_empanelled, data.occupation_details, data.corporation_category])


        if ('kyd_list' in data) {
            await pool.query(`delete from tbl_kyd_details where "pan_no"=$1`, [data.pan_no])
            for (let i = 0; i < data['kyd_list'].length; i++) {
                let element = data['kyd_list'][i]

                await pool.query(`INSERT INTO tbl_kyd_details
        (pan_no, arn_id, distributer_name, fathers_name, kyd_pan_no, applicant_type, gender, dob, door_flat_no, appartment, street_name, city, pincode, state, telephone_no, bank_name, branch, account_number, micr_neft, account_type, empanelled, occupation) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)`, [data['pan_no'], element['arn_id'], element['distributer_name'], element['fathers_name'], element['kyd_pan_no'], element['applicant_type'], element['gender'], element['dob'], element['door_flat_no'], element['appartment'], element['street_name'], element['city'], element['pincode'], element['state'], element['telephone_no'], element['bank_name'], element['branch'], element['account_number'], element['micr_neft'], element['account_type'], element['empanelled'], element['occupation']]);
            }
        }
        await updateChangeReqHistryAuthorised(data);
        return data.application_reference_no;
    }

    return null;
}

updateAssignedChangeRequest = async () => {
    let select_data = await pool.query(`SELECT * FROM tbl_chng_req_hist WHERE "modified_date" <= NOW() - INTERVAL '10 minutes' and req_status_code in ('ASSIGNED_BO1','ASSIGNED_BO2')`)
    if (select_data['rowCount'] > 0) {

        let req_status = ''
        let req_status_code = ''
        let bo1_verified = null;
        let bo2_verified = null;
        for (let i = 0; i < select_data['rows'].length; i++) {
            if (select_data['rows'][i]['req_status_code'] == 'ASSIGNED_BO1') {
                req_status = 'Start Entry'
                req_status_code = 'START_ENTRY'
                bo1_verified = null;
                bo2_verified = null;
            }
            else if (select_data['rows'][i]['req_status_code'] == 'ASSIGNED_BO2') {
                req_status = 'Authorise';
                req_status_code = 'AUTHORISE';
                bo1_verified = select_data['rows'][i]['bo1_verified'];
                bo2_verified = null
            }
            await pool.query(`UPDATE tbl_chng_req_hist SET 
           "modified_date"=$1,"req_status"=$2,"bo1_verified"=$3,"req_status_code"=$4,"bo2_verified"=$5 where   "pan_no"=$6 and application_reference_no=$7`, ['now()', req_status, bo1_verified, req_status_code, bo2_verified, select_data['rows'][i]['pan_no'], select_data['rows'][i]['application_reference_no']])

        }
    }
}

updateAssignedNigoRequest = async () => {
    let select_data = await pool.query(`select *  from tbl_reg_ren_nigo where "modified_date" <= NOW() - INTERVAL '10 minutes' and req_status_code in ('ASSIGNED_BO1','ASSIGNED_BO2') `)
    if (select_data['rowCount'] > 0) {
        let req_status = ''
        let req_status_code = ''
        let bo1_verified = null;
        let bo2_verified = null;
        for (let i = 0; i < select_data['rows'].length; i++) {

            if (select_data['rows'][i]['req_status_code'] == 'ASSIGNED_BO1') {
                req_status = 'Start Entry'
                req_status_code = 'START_ENTRY'
                bo1_verified = null;
                bo2_verified = null;
            }
            else if (select_data['rows'][i]['req_status_code'] == 'ASSIGNED_BO2') {
                req_status = 'Authorise';
                req_status_code = 'AUTHORISE';
                bo1_verified = select_data['rows'][i]['bo1_verified'];
                bo2_verified = null
            }

            await pool.query(`UPDATE tbl_reg_ren_nigo SET 
        "modified_date"=$2, "modified_by"=$3,"req_status"=$4,"bo1_verified"=$5,"req_status_code"=$7,"bo2_verified"=$8 where "nigo_ref" =$1 and "pan_no"=$6 returning "nigo_ref"`, [select_data['rows'][i]['application_reference_no'], 'now()', null, req_status, bo1_verified, select_data['rows'][i]['pan_no'], req_status_code, bo2_verified])
        }
    }
}

insertRegRenHistory = async (data) => {
    await pool.query(`INSERT INTO tbl_reg_ren_hist
(pan_no, sys_appl_no, req_type, appl_date, appl_uploads, req_status, "source", created_by, created_date, modified_by, modified_date)
VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
`, [data.pan_no, data.application_reference_no, data.req_type, 'now()', data.appl_uploads, data.req_status, data.source, data.user_id, 'now()', data.user_id, 'now()'])
}

updateRegRenHistory = async (data) => {
    let appl_uploads = '';
    let user_id = null;
    if ('appl_uploads' in data) {
        appl_uploads = data.appl_uploads;
    }
    if ('user_id' in data) {
        user_id = data['user_id'];
    }
    await pool.query(`update tbl_reg_ren_hist
    set req_status=$3,appl_uploads=$6, modified_by=$4, modified_date=$5 where "pan_no"=$1 and "sys_appl_no"=$2
    `, [data.pan_no, data.application_reference_no, data.req_status, user_id, 'now()', appl_uploads])
}


module.exports = {
    getState,
    saveOfflineRegister,
    getDocumentCheckListByType,
    loginFO,
    getOfflineRegisterDataById,
    submitOfflineRegister,
    getAllARNList,
    updatePriority,
    updateFo1Assign,
    getOfflineApplicantDatasById,
    submitForAuthorisation,
    updateFo2Assign,
    getUploadedDocumentById,
    loginBO,
    getAuthorisationList,
    searchByArnNoApproved,
    searchByEUINNoApproved,
    saveOfflineRenewal,
    loginFOBO,
    getRequestTypes,
    saveRequestedUpdate,
    getRejectReason,
    getGender,
    getOfflineUpdateById,
    submitOfflineUpdate,
    getOfflineUpdateQueueList,
    offlineUpdatedataBoAssign,
    getFinancialYear,
    getAuthoriseSelfDeclareUpdated,
    authoriseSelfDeclaration,
    getAuthoriseSignatureUpdated,
    authoriseSignature,
    getAuthoriseBasicDetailsUpdated,
    authoriseBasicDetails,
    getAuthoriseBankDetailsUpdated,
    authoriseBankDetails,
    getAuthoriseContactsUpdated,
    authoriseContacts,
    getAuthoriseGSTDetailsUpdated,
    authoriseGSTDetails,
    getAuthorisephotoUpdated,
    authorisePhoto,
    getAuthoriseOptionUpdated,
    authoriseOption,
    getAuthoriseMappingUpdated,
    authoriseMapping,
    searchNigoDetails,
    submitNigoApplicationByFo,
    offlineUpdatedataBo2Assign,
    submitForAuthoriseSelfdeclareUpdate,
    saveApproveToApprovehistory,
    updateSubmitForAuthorise,
    submitForAuthoriseBasicDetailUpdate,
    submitForAuthoriseSignatureUpdate,
    submitForAuthoriseBankDetailsUpdate,
    submitForAuthoriseContactsUpdate,
    submitForAuthoriseGstUpdate,
    submitForAuthorisePhotoUpdate,
    submitForAuthoriseOptionUpdate,
    submitForAuthoriseMappingUpdate,
    getOfflineUpdateAuthoriseList,
    getNigoAuthorisationList,
    getNigoList,
    nigoBo1Assign,
    nigoBo2Assign,
    authoriseRegisterRenewal,
    isChangeRequestExists,
    rejectRegisterRenewal,
    rejectUpdates,
    rejectRegisterRenewalToNigo,
    rejectUpdatesToNigo,
    registrationActivate,
    getNigoApplicantDetails,
    submitNigoForAuthorisation,
    authoriseNigoApplication,
    updateNigoApproved,
    searchDetailsByPanNoForNigo,
    cancelAssignedRegisration,
    cancelAssignedUpdate,
    cancelAssignedNigo,
    getAuthoriseDuplicateCardUpdated,
    submitForAuthoriseDupCardUpdated,
    authoriseDupCardUpdated,
    getCardPrintingList,
    payForIssueDuplicate,
    getCardIssueStatus,
    updateFOBOtoken,
    logoutFOBO,
    checkUserNameExists,
    getAuthoriseSignatoryUpdated,
    submitForAuthoriseSignatoryUpdate,
    authoriseSignatory,
    getAuthoriseCategoryUpdated,
    submitForAuthoriseCategoryUpdate,
    authoriseCategory,
    updateAssignedChangeRequest,
    updateAssignedNigoRequest,
    insertRegRenHistory,
    updateRegRenHistory
}