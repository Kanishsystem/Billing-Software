const pool = require("../../config/db");
const helper = require("../services/helper.service");

getEUINProfileSummary = async (data) => {
    let res = await pool.query(`select A."id",A."arn_id",A."name_of_organisation",A."euin_number",A."first_name",A."last_name",A."pan_no",to_char(A."date_of_birth",'YYYY-MM-DD') as  date_of_birth,A."address1",A."address2",A."address3",A."city",A."pincode",A."state",A."mobile_no",A."email_id",to_char(A.validity_to ,'YYYY-MM-DD') AS validity_to,A."certificate_number" as "nism_certificate_no" from amfi_distributer_master_approved A where A."pan_no"=$1 and A."application_type"='EUIN'`, [data.pan_no])

    if (res['rowCount'] > 0) {
        let pen_res = await pool.query(`select "renewal_type" from amfi_distributer_master_pending where "pan_no"=$1`, [data.pan_no])

        if (pen_res['rowCount'] > 0) {
            if (pen_res['rows'][0]['renewal_type'] = 'RENEWAL') {
                res['rows'][0]['status'] = 'Renewal'
            }
        }
        else {
            let d1 = new Date(res['rows'][0]['validity_to'])
            let d2 = new Date();

            let mondiff = await monthDiff(d1, d2);
            if (mondiff > 6) {
                res['rows'][0]['status'] = 'Active';
            }
            else if (mondiff < 6 && mondiff > 1) {
                res['rows'][0]['status'] = 'Expires in ' + mondiff + ' Months';
            }
            else {
                let daydiff = await daysDiff(d1, d2);
                res['rows'][0]['status'] = 'Expires in ' + daydiff + ' days';

            }
        }
        return res['rows'];
    }
    else {
        let res = await pool.query(`select A."id",A."arn_id",A."name_of_organisation",A."euin_number",A."first_name",A."last_name",A."pan_no",to_char(A."date_of_birth",'YYYY-MM-DD') as  date_of_birth,A."address1",A."address2",A."address3",A."city",A."pincode",A."state",A."mobile_no",A."email_id",to_char(A.validity_to ,'YYYY-MM-DD') AS validity_to,A."certificate_number" as "nism_certificate_no" from amfi_distributer_master_pending A where A."pan_no"=$1 and  A."application_type"='EUIN'`, [data.pan_no])

        if (res['rowCount'] > 0) {
            res['rows'][0]['status'] = 'Pending';
            return res['rows'];
        }
        return null;
    }
}

getARNDetailsByEUINId = async (data) => {
    let res = await pool.query(`select "pan_no","arn_id","name_of_organisation","company_address1" ,"company_address2" ,"company_address3" ,"company_city", "company_state", "company_pincode"  from amfi_distributer_master_approved  where application_type ='EUIN' and euin_number =$1`, [data.euin_number])
    if (res['rowCount'] > 0) {
        res['rows'][0]['status'] = 'Active'
        let map_res = await pool.query(`select "new_arn","old_arn" from map_hist where "pan_no"=$1 and "status"=true`, [res['rows'][0]['pan_no']])
        if (map_res['rowCount'] > 0) {
            if (res['rows'][0]['arn_id'] == '') {
                res['rows'][0]['status'] = 'Mapping Request Pending with ' + map_res['rows'][0]['new_arn'];
            }
            else {
                res['rows'][0]['status'] = 'Demapping Request Pending with ' + map_res['rows'][0]['old_arn'];
            }
        }
        return res['rows'];
    }
    return null;
}

updatNewEmployerForEUIN = async (data) => {

    let update_approved = await pool.query(`update amfi_distributer_master_approved set "company_address1"=$1 ,"company_address2"=$2 ,"company_address3"=$3 ,"company_city"=$4, "company_state"=$5, "company_pincode"=$6 where "pan_no"=$7`, [data.company_address1, data.company_address2, data.company_address3, data.company_city, data.company_state, data.company_pincode, data.pan_no])

    await pool.query(`update map_hist set "status"=false where "pan_no"=$1`, [data.pan_no])

    let maphis_insert = await pool.query(`INSERT INTO map_hist
    ( pan_no, brkcod, old_arn, new_arn, old_appr_rej_date, new_apprv_rej_date, old_rem, new_rem, created_by,  modified_by, modified_date,"source")
    VALUES($1,$2,$3, $4,$5,$6,$7,$8, $9, $10, $11,$12) returning "id"`, [data.pan_no, '', data.old_arn, data.new_arn, null, null, data.remarks, '', data.user_id, data.user_id, 'now()', 'Online'])

    if (maphis_insert['rowCount'] > 0) {
        return maphis_insert['rows'][0]['id']
    }

    return null;
}

sentForRenewalByEUINId = async (data) => {
    let pending_res_data = await pool.query(`select *  from amfi_distributer_master_approved  where "pan_no"=$1`, [data.pan_no])
    if (pending_res_data['rowCount'] > 0) {
        let pend_res = pending_res_data['rows'][0]
        let application_reference_no = ''

        let pending_res_data = await pool.query(`select *  from amfi_distributer_master_pending  where "pan_no"=$1`, [data.pan_no])

        if (pending_res_data['rowCount'] > 0) {
            return null;
        }
        else {

            let date_of_passing_test = null;
            let certificate_number = '';
            let validity_from = null;
            let validity_to = null;


            if ('validity_from' in data) {
                validity_from = data['validity_from'];
            }
            if ('validity_to' in data) {
                validity_to = data['validity_to'];
            }

            let nism_res = await pool.query(`select  to_char("nism_certificate_date",'YYYY-MM-DD') as date_of_passing_test,"nism_certificate_no" as certificate_number,to_char("validity_from",'YYYY-MM-DD') as date_of_cpe_from,to_char("validity_to",'YYYY-MM-DD') AS date_of_cpe_to  from tbl_user_nism_details  where  "pan_no"=$2 order by "id" desc`, [data['pan_no']])


            if (nism_res['rowCount'] > 0) {
                date_of_passing_test = nism_res['rows'][0]['date_of_passing_test']
                certificate_number = nism_res['rows'][0]['certificate_number']
                // validity_from = nism_res['rows'][0]['date_of_cpe_from']
                // validity_to = nism_res['rows'][0]['date_of_cpe_to']
            }
            // let select_counter = await pool.query(`select * from amfi_counter`)
            // if (select_counter['rowCount'] > 0) {
            //     let applicount = select_counter['rows'][0]['application_reference_count'] + 1
            //     application_reference_no = 'APP-REF' + applicount
            //     await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
            // }
            application_reference_no = await helper.generateApplicationNumber()
            let current_action_code = 'PENDING'
            let current_action = 'Pending'
            let req_type = 'ARN_REN'
            if (pend_res['application_type'] == 'EUIN') {
                req_type = 'EUIN_REN'
                current_action_code = 'COMPLETED'
                current_action = 'Completed'
            }

            let insert_pending = `INSERT INTO amfi_distributer_master_pending( first_name, middle_name, last_name, gender, date_of_birth, pan_no, gstn, "whether_kyd_Compliant", certificate_number, date_of_passing_test, address1, address2, address3, city, pincode, state, country, telephone_number, fax, mobile_no, email_id, qualification, university, year_of_passing, name_of_bank, branch, bank_city, "account_Number", ifsc, account_type, micr, dd_cheque_number, dd_cheque_date, amount, drawn_on_bank_branch, signature, place, sign_date, undertaking_consent, kyd_source, cpe_certificate_number, date_of_cpe_from, distributor_category, arn_id, name_of_organisation, utr_no, type_of_distributor, distributer_master_status, created_by, modified_by, modified_date, application_type, date_of_cpe_to, bank_proof_filepath, pancard_filepath, adharcard_filepath, photo_filepath, signature_filepath, registration_type, date_of_appointment, designation, description_of_responsibilities, company_address1, company_address2, company_address3, company_pincode, company_city, company_state, arn_number, euin_number, gst_filepath, application_reference_no, document_checklist, address_proof_filepath, nism_certificate_filepath, kyd_acknowledge_filepath, priority, current_action, fo1_verified, fo2_verified, gst_verified, gst_verified_by, renewal_type,photo_thumbnail,category_of_corporation,"validity_from", "validity_to","current_action_code")VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42,$43,$44,$45,$46,$47,$48,$49,$50,$51,$52,$53,$54,$55,$56,$57,$58,$59,$60,$61,$62,$63,$64,$65,$66,$67,$68,$69,$70,$71,$72,$73,$74,$75,$76,$77,$78,$79,$80,$81,$82,$83,$84,$85,$86,$87,$88) returning "id","application_reference_no"`

            let dis_ins = await pool.query(insert_pending, [pend_res['first_name'], pend_res['middle_name'], pend_res['last_name'], pend_res['gender'], pend_res['date_of_birth'], pend_res['pan_no'], pend_res['gstn'], pend_res['whether_kyd_Compliant'], certificate_number, date_of_passing_test, pend_res['address1'], pend_res['address2'], pend_res['address3'], pend_res['city'], pend_res['pincode'], pend_res['state'], pend_res['country'], pend_res['telephone_number'], pend_res['fax'], pend_res['mobile_no'], pend_res['email_id'], pend_res['qualification'], pend_res['university'], pend_res['year_of_passing'], pend_res['name_of_bank'], pend_res['branch'], pend_res['bank_city'], pend_res['account_Number'], pend_res['ifsc'], pend_res['account_type'], pend_res['micr'], pend_res['dd_cheque_number'], pend_res['dd_cheque_date'], pend_res['amount'], pend_res['drawn_on_bank_branch'], pend_res['signature'], pend_res['place'], pend_res['sign_date'], pend_res['undertaking_consent'], pend_res['kyd_source'], pend_res['cpe_certificate_number'], pend_res['date_of_cpe_from'], pend_res['distributor_category'], pend_res['arn_id'], pend_res['name_of_organisation'], pend_res['utr_no'], pend_res['type_of_distributor'], 'Pending', data.user_id, data.user_id, 'now()', pend_res['application_type'], pend_res['date_of_cpe_to'], pend_res['bank_proof_filepath'], pend_res['pancard_filepath'], pend_res['adharcard_filepath'], pend_res['photo_filepath'], pend_res['signature_filepath'], 'ONLINE', pend_res['date_of_appointment'], pend_res['designation'], pend_res['description_of_responsibilities'], pend_res['company_address1'], pend_res['company_address2'], pend_res['company_address3'], pend_res['company_pincode'], pend_res['company_city'], pend_res['company_state'], pend_res['arn_number'], pend_res['euin_number'], pend_res['gst_filepath'], application_reference_no, pend_res['document_checklist'], pend_res['address_proof_filepath'], pend_res['nism_certificate_filepath'], pend_res['kyd_acknowledge_filepath'], pend_res['priority'], current_action, pend_res['fo1_verified'], pend_res['fo2_verified'], pend_res['gst_verified'], pend_res['gst_verified_by'], 'RENEWAL', pend_res['photo_thumbnail'], pend_res['category_of_corporation'], validity_from, validity_to, current_action_code])


            if (dis_ins['rowCount'] > 0) {
                let reqData = {
                    "pan_no": data['pan_no'],
                    "application_reference_no": application_reference_no,
                    "req_type": req_type,
                    "appl_uploads": '',
                    "req_status": current_action,
                    "source": 'ONLINE',
                    "user_id": null
                }
                await insertRegRenHistory(reqData)
                return dis_ins['rows'][0];
            }
        }
        return null;

    }
}

module.exports = {
    getEUINProfileSummary,
    getARNDetailsByEUINId,
    updatNewEmployerForEUIN,
    sentForRenewalByEUINId
}