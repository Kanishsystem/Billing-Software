const pool = require("../../config/db");

searchByAdmin = async (reqObj) => {
    let pan_no = '';
    let arn_number = '';
    let euin_number = '';
    let mobile_no = '';
    let email_id = '';
    if ('pan_no' in reqObj) {
        if (reqObj['pan_no'] !== null || reqObj['pan_no'] !== undefined) {
            pan_no = reqObj['pan_no'];
        }
    }
    if ('arn_number' in reqObj) {
        if (reqObj['arn_number'] !== null || reqObj['arn_number'] !== undefined) {
            arn_number = reqObj['arn_number'];
        }
    }

    if ('euin_number' in reqObj) {
        if (reqObj['euin_number'] !== null || reqObj['euin_number'] !== undefined) {
            euin_number = reqObj['euin_number'];
        }
    }

    if ('mobile_no' in reqObj) {
        if (reqObj['mobile_no'] !== null || reqObj['mobile_no'] !== undefined) {
            mobile_no = reqObj['mobile_no'];
        }
    }

    if ('email_id' in reqObj) {
        if (reqObj['email_id'] !== null || reqObj['email_id'] !== undefined) {
            email_id = reqObj['email_id'];
        }
    }

    let res = await pool.query(`select arn_number ,euin_number ,mobile_no ,email_id,user_id,pan_no from amfi_distributer_master_approved where "pan_no" like '%${pan_no}%' and  arn_number like '%${arn_number}%' and euin_number like '%${euin_number}%' and mobile_no like '%${mobile_no}%' and  email_id like '%${email_id}%'`)



    if (res['rowCount'] > 0) {
        return res;
    }
    return null;
}



getAdmintProfileSummaryById = async (data) => {
    let res = await pool.query(`select A."id", A."arn_number",A."first_name",A."last_name",A."pan_no",to_char(A."date_of_birth",'YYYY-MM-DD') as  date_of_birth,A."address1",A."address2",A."address3",A."city",A."pincode",A."state",A."mobile_no",A."email_id",to_char(A.validity_to ,'YYYY-MM-DD') AS validity_to from amfi_distributer_master_approved A where A."pan_no"=$1`, [data.pan_no])
    if (res['rowCount'] > 0) {
        let d1 = new Date(res['rows'][0]['validity_to'])
        let d2 = new Date();

        let mondiff = await monthDiff(d1, d2);
        if (mondiff > 6) {
            res['rows'][0]['status'] = 'Active';
        }
        else if (mondiff < 6 && mondiff > 1) {
            res['rows'][0]['status'] = 'Expires in ' + mondiff + ' Months';
        }
        else {
            let daydiff = await daysDiff(d1, d2);
            res['rows'][0]['status'] = 'Expires in ' + daydiff + ' days';

        }
        return res['rows'];
    }
    return null;
}

monthDiff = async (dt1, dt2) => {
    var diffMonth = (dt2.getTime() - dt1.getTime()) / 1000;
    diffMonth /= (60 * 60 * 24 * 7 * 4);
    return Math.abs(Math.round(diffMonth));
}

daysDiff = async (dt1, dt2) => {
    var diffTime = (dt2.getTime() - dt1.getTime());
    var daysDiff = diffTime / (1000 * 3600 * 24);
    return Math.abs(Math.round(daysDiff));

}


getAdminActiveBankDetailsById = async (data) => {
    let res = await pool.query(`select "id", "account_Number" ,"account_type","name_of_bank","branch","bank_city","ifsc","bank_proof_filepath","pan_no"  from amfi_distributer_master_approved where "pan_no"=$1`, [data.pan_no])
    if (res['rowCount'] > 0) {
        let bankproof_id = res['rows'][0]['bank_proof_filepath'];
        res['rows'][0]['bank_proof_filepath_base64'] = null;
        res['rows'][0]['bank_proof_filepath_image_type'] = '';
        res['rows'][0]['bank_proof_filename'] = '';
        var num1 = parseInt(bankproof_id) || 0;
        if (num1 > 0) {
            let bankproof_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [bankproof_id])
            if (bankproof_res['rowCount'] > 0) {
                let imgBuff = bankproof_res['rows'][0]['image'];
                res['rows'][0]['bank_proof_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                res['rows'][0]['bank_proof_filepath_image_type'] = bankproof_res['rows'][0]['image_type'];
                res['rows'][0]['bank_proof_filename'] = bankproof_res['rows'][0]['file_name']

                //                res['rows'][0]['bank_proof_filepath_base64'] = bankproof_res['rows'][0]['image'];

            }
        }
        return res['rows'];
    }
    return null;
}

getAdminGSTInfoById = async (data) => {
    let res = await pool.query(`select "id", "gstn","gst_filepath","gst_verified","gst_verified_by","pan_no"  from amfi_distributer_master_approved where "pan_no"=$1`, [data.pan_no])
    if (res['rowCount'] > 0) {

        let gst_id = res['rows'][0]['gst_filepath'];
        res['rows'][0]['gst_filepath_base64_image_type'] = '';
        res['rows'][0]['gst_filename'] = '';
        res['rows'][0]['gst_filepath_base64'] = null;
        var num1 = parseInt(gst_id) || 0;
        if (num1 > 0) {
            let gst_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [gst_id])
            if (gst_res['rowCount'] > 0) {
                let imgBuff = gst_res['rows'][0]['image'];
                res['rows'][0]['gst_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');
                res['rows'][0]['gst_filepath_base64_image_type'] = gst_res['rows'][0]['image_type'];
                res['rows'][0]['gst_filename'] = gst_res['rows'][0]['file_name'];

                //                res['rows'][0]['gst_filepath_base64'] = gst_res['rows'][0]['image'];

            }
        }
        return res['rows'];
    }
    return null;
}

getAdminProfilePictureById = async (data) => {
    let resObj = {}
    let res = await pool.query(` select "id", "photo_filepath" from amfi_distributer_master_approved where "pan_no"=$1`, [data.pan_no])
    if (res['rowCount'] > 0) {
        let photo_id = res['rows'][0]['photo_filepath'];
        if (photo_id != null) {
            let photo_res = await pool.query(`select * from amfi_file where "id"=$1 
            `, [photo_id])
            if (photo_res['rowCount'] > 0) {
                resObj['photo_filepath'] = photo_id;

                let imgBuff = photo_res['rows'][0]['image'];
                resObj['photo_filepath_base64'] = imgBuff == null ? null : 'data:image/png;base64,' + imgBuff.toString('base64');;
                resObj['photo_filepath_base64_image_type'] = photo_res['rows'][0]['image_type'];
                resObj['photo_filename'] = photo_res['rows'][0]['file_name'];

                //                resObj['photo_filepath_base64'] = photo_res['rows'][0]['image'];

            }
        }
        return resObj;
    }
    return null;
}


getViewAllEUINAdmin = async (data) => {
    let arr1 = []
    let arr2 = []
    let res_approved = await pool.query(`select "id","first_name" ,"middle_name" ,"last_name" ,"pan_no","distributer_master_status","euin_number","arn_id","photo_filepath","photo_thumbnail" from amfi_distributer_master_approved where "application_type" ='EUIN' and "arn_id"=$1`, [data.arn_number])

    if (res_approved['rowCount'] > 0) {
        arr1 = res_approved['rows'];
    }

    let res_pending = await pool.query(`select "id","first_name" ,"middle_name" ,"last_name" ,"pan_no","distributer_master_status","arn_id","photo_filepath","photo_thumbnail","euin_number" from amfi_distributer_master_pending where "application_type" ='EUIN' and "arn_id"=$1`, [data.arn_number])

    if (res_pending['rowCount'] > 0) {
        arr2 = res_pending['rows'];
    }
    var arr3 = [...arr1, ...arr2];

    return arr3;
}


getMappingEUINListAdmin = async (data) => {
    let res = await pool.query(`select B."id",B."first_name" ,B."middle_name" ,B."last_name" ,A."pan_no",B."designation" ,to_char(A."created_date",'YYYY-MM-DD') as applied_on,"branch" ,"company_city","mobile_no","email_id",B."distributer_master_status",B."euin_number"   from map_hist A,amfi_distributer_master_approved B where A."new_arn"=$1 and B."application_type" ='EUIN' and A."pan_no"=B."pan_no" and B.arn_id='' and A."status"=true `, [data.arn_number])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getDeMappingEUINListAdmin = async (data) => {
    let res = await pool.query(`select B."id",B."first_name" ,B."middle_name" ,B."last_name" ,A."pan_no",B."designation" ,to_char(A."created_date",'YYYY-MM-DD') as applied_on,"branch" ,"company_city","mobile_no","email_id",B."distributer_master_status",B."euin_number"   from map_hist A,amfi_distributer_master_approved B where A.old_arn=$1 and B."application_type" ='EUIN' and A."pan_no"=B."pan_no" and  B.arn_id!='' and A."status"=true`, [data.arn_number])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getRegisterRenewalEUINAdmin = async (data) => {
    let res = await pool.query(`select "id","first_name" ,"middle_name" ,"last_name" ,"pan_no","designation" ,"renewal_type" ,"mobile_no","email_id","application_reference_no"  from amfi_distributer_master_pending where "application_type" ='EUIN'  and "arn_id"=$1 and "current_action_code"='COMPLETED'`, [data.arn_number])

    if (res['rowCount'] > 0) {
        return res['rows'];
    }

    return null;
}

getProductCategoriesOptionAdmin = async (data) => {
    let res = await pool.query(`select "id","op_code","op_desc"  from tbl_optins_master where "status"=true`)

    if (res['rowCount'] > 0) {
        let opincode = []
        let opin_res = await pool.query(`select "opin_codes" from tbl_user_opin where "pan_no"=$1`, [data.pan_no])

        if (opin_res['rowCount'] > 0) {
            opincode = opin_res['rows'][0]['opin_codes'].split(',')
        }

        for (let i = 0; i < res['rows'].length; i++) {
            res['rows'][i]['checked'] = false;
            for (let j = 0; j < opincode.length; j++) {
                if (res['rows'][i]['op_code'] == opincode[j]) {
                    res['rows'][i]['checked'] = true;
                }
            }
        }
        return res['rows'];

    }
    return null;
}

getUpdatesHistory = async (data) => {
    let select_data = await pool.query(`select created_date ,req_type ,"source" ,key_value_old ,key_value_new ,appl_uploads  from tbl_chng_req_hist where (created_date, created_date) OVERLAPS ($1::DATE, $2::DATE)`, [data.from_date, data.to_date])
    if (select_data['rowCount'] > 0) {
        return select_data['rows'];
    }
    return null;

}
getRegRenHistory = async (data) => {
    let select_data = await pool.query(`select created_date as application_date ,req_type ,"source" ,req_status,pan_no,sys_appl_no from tbl_reg_ren_hist where (created_date, created_date) OVERLAPS ($1::DATE, $2::DATE)`, [data.from_date, data.to_date])
    if (select_data['rowCount'] > 0) {
        let res = select_data['rows'];
        for (let i = 0; i < res.length; i++) {
            res[i]['trxn_date'] = '';
            res[i]['amount'] = '';
            res[i]['status_reason'] = '';
            let select_tranctn = await pool.query(`select trxn_date ,amount ,status_reason from tbl_payments_sts where pan_no=$1 and sys_appl_no=$2 and psp_trxn_rem=$3`, [res[i]['pan_no'], res[i]['sys_appl_no'], res[i]['req_type']])

            if (select_tranctn['rowCount'] > 0) {
                res[i]['trxn_date'] = select_tranctn['rows'][0]['trxn_date'];
                res[i]['amount'] = select_tranctn['rows'][0]['amount'];
                res[i]['status_reason'] = select_tranctn['rows'][0]['status_reason'];
            }
        }
        return res;
    }
    return null;

}
getMappingHistory = async (data) => {
    let select_data = await pool.query(`select A.created_date ,A.old_arn ,A.new_arn ,A.old_appr_rej_date ,A.new_apprv_rej_date,A."source",B.arn_id  from map_hist A ,amfi_distributer_master_approved B where A.pan_no =B.pan_no and (A.created_date, A.created_date) OVERLAPS ($1::DATE, $2::DATE)`, [data.from_date, data.to_date])

    if (select_data['rowCount'] > 0) {
        for (let i = 0; i < select_data['rows'].length; i++) {
            if (select_data['rows'][i]['arn_id'] != '') {
                select_data['rows'][i]['Status'] = 'Approved'
            }
            else {
                select_data['rows'][i]['Status'] = 'Not Approved'

            }
        }
        return select_data['rows'];
    }

    return null;
}
getDeMappingHistory = async (data) => {

    let select_data = await pool.query(`select A.created_date,A.pan_no ,B.first_name ,B.middle_name ,B.last_name ,B.euin_number  from map_hist A,amfi_distributer_master_approved B where A.pan_no =B.pan_no and (A.created_date, A.created_date) OVERLAPS ($1::DATE, $2::DATE) and A.old_appr_rej_date !=null;`, [data.from_date, data.to_date])

    //2022-04-18
    if (select_data['rowCount'] > 0) {
        return select_data['rows'];
    }

    return null;
    //select createddate,panno,from  maphist name and euin no from dismasterappr

    //where createddate<ffom date and  > todate and old_appr_rej_date!=null
}

getIssueDuplicateReqStatus = async (data) => {
    let select_data = await pool.query(`select req_status ,req_status_code from tbl_chng_req_hist where req_type ='DUP' and pan_no =$1 order by created_date desc`, [data.pan_no])

    if (select_data['rowCount'] > 0) {
        let resObj = {}
        if (select_data['rows'][0]['req_status_code'] == 'COMPLETED') {
            resObj['status'] = 'Completed'
        }
        else {
            resObj['status'] = 'Pending'
        }

        return resObj;
    }
    return null;

}

searchByNismPan = async (data) => {
    let res = await pool.query(`select distributer_name ,pan_no  from tbl_user_nism_details where status =true and  pan_no like '%${data.pan_no}%'`
    )

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

getInvalidType = async (data) => {
    let res = await pool.query(`select invalid_type ,invalid_desc  from tbl_amfi_invalid_type where status =true `)

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

getInvalidAuthority = async (data) => {
    let res = await pool.query(`select  invalid_authority from tbl_amfi_invalid_authority where status =true`)

    if (res['rowCount'] > 0) {
        return res['rows'];
    }
    return null;
}

saveInvalidDetails = async (data) => {
    let res = await pool.query(`INSERT INTO tbl_amfi_invalid_details
    ( pan_no, arn_number, euin_number, invalid_type, invalid_remarks, invalid_entry_date, invalid_create_user, invalid_from, invalid_to, invalid_authority,  created_by,  modified_by, modified_date)VALUES( $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)returning "sl_no"`, [data.pan_no, data.arn_number, data.euin_number, data.invalid_type, data.invalid_remarks, 'now()', data.invalid_create_user, data.invalid_from, data.invalid_to, data.invalid_authority, data.user_id, data.user_id, 'now()'])

    if (res['rowCount'] > 0) {
        return res['rows'][0]['sl_no'];
    }
    return null;
}

module.exports = {
    searchByAdmin,
    getAdmintProfileSummaryById,
    getAdminActiveBankDetailsById,
    getAdminGSTInfoById,
    getAdminProfilePictureById,
    getUpdatesHistory,
    getRegRenHistory,
    getMappingHistory,
    getDeMappingHistory,
    getViewAllEUINAdmin,
    getMappingEUINListAdmin,
    getDeMappingEUINListAdmin,
    getRegisterRenewalEUINAdmin,
    getProductCategoriesOptionAdmin,
    getIssueDuplicateReqStatus,
    searchByNismPan,
    getInvalidType,
    getInvalidAuthority,
    saveInvalidDetails
}