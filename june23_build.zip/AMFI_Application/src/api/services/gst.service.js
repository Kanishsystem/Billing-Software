const pool = require("../../config/db");

saveGstDetails = async (data) => {
    let res = await pool.query(`INSERT INTO amfi_gst
        (pan_no, gst_number, gst_file, gst_state,  created_by, status, status_code,modified_by, modified_date)
        VALUES($1, $2, $3, $4, $5, $6, $7,$8 ,$9)returning "id"`, [data.pan_no, data.gst_number, data.gst_file, data.gst_state, data.user_id, '', '', data.user_id, 'now()'])

    if (res['rowCount'] > 0) {
        return res['rows'][0]['id'];
    }

    return null;
}
updateGstDetails = async (data) => {
    let res = await pool.query(`update amfi_gst
         set  gst_number=$2, gst_file=$3, gst_state=$4,  created_by=$5, status=$6, status_code=$7,modified_by=$8, modified_date=$9 where pan_no=$1 and "gst_number"=$10 returning "id"`, [data.pan_no, data.gst_number, data.gst_file, data.gst_state, data.user_id, '', '', data.user_id, 'now()', data.old_gstnumber])

    if (res['rowCount'] > 0) {
        return res['rows'][0]['id'];
    }

    return null;
}

removeGstDetails = async (data) => {
    let res = await pool.query(`update amfi_gst
         set "action"=false, modified_by=$3, modified_date=$4 where pan_no=$1 and "gst_number"=$2 returning "id"`, [data.pan_no, data.gst_number, data.user_id, 'now()'])

    if (res['rowCount'] > 0) {
        return res['rows'][0]['id'];
    }

    return null;
}

testFileMerge = async (data) => {
    
}

module.exports = {
    saveGstDetails,
    updateGstDetails,
    removeGstDetails,
    testFileMerge
}