const pool = require("../../config/db");
const file_uploader = require("../../common/file_uploader");
const encryptionDecryption = require('../../common/encrypt_decrypt');

upload_file = async (data) => {
    if (data.image == null || data.image == '') {
        return null;
    }

    var base64Data;
    var base64Arr = data.image.split(',');
    if (base64Arr.length == 2) {
        base64Data = base64Arr[1]
    }
    else if (base64Arr.length == 1) {
        base64Data = data.image;
    } else {
        base64Data = "";
    }
    let imgBuff = new Buffer.from(base64Data, 'base64');


    let res = await pool.query(`INSERT INTO amfi_file
    (file_name, image_type, amc_code, folio_msgid, image_date, image, editor_id, xy_cor, tagged_image, ref_no, status, created_by,  modified_by, modified_date)
    VALUES( $1,$2, '', '', $3, $4, '', '', '', '', $5, $7,$8, $6)RETURNING id`, [data.file_name, data.image_type, 'now()', imgBuff, true, 'now()', null, null]
    )

    if (res['rowCount'] > 0) {
        return res['rows'][0]['id'];
    }
    return null;
}

base64ToThumbnail = async (id) => {
    let res = await pool.query(`select * from amfi_file where "id"=$1`, [id])

    if (res['rowCount'] > 0) {
        let imgBuff = res['rows'][0]['image'];
        let base64str = imgBuff == '' ? null : imgBuff.toString('base64');
        let tumbnailstr = await file_uploader.base64ToThumbnail(base64str);
        return tumbnailstr;
    }
    return null;
}

generateApplicationNumber = async () => {
    let application_reference_no = ''
    let select_counter = await pool.query(`select * from amfi_counter`)
    if (select_counter['rowCount'] > 0) {
        let applicount = select_counter['rows'][0]['application_reference_count'] + 1
        application_reference_no = 'APP-REF' + applicount
        await pool.query(`update amfi_counter set "application_reference_count"='${applicount}'`)
        return application_reference_no;
    }
    return null;
}

generateTicketNumber = async () => {
    let ticket_no = 1000;
    let select_counter = await pool.query(`select * from amfi_counter`)
    if (select_counter['rowCount'] > 0) {
        ticket_no = select_counter['rows'][0]['griv_ticket_counter'] + 1
        await pool.query(`update amfi_counter set "griv_ticket_counter"='${ticket_no}'`)
        return ticket_no;
    }
    return null;
}

saveAuditLogs = async (request, response, method) => {
    let encrypt_request = encryptionDecryption.encrypt(JSON.stringify(request));
    let encrypt_response = encryptionDecryption.encrypt(JSON.stringify(response));
    await pool.query(`INSERT INTO amfi_audit_logs
    ( encrypted_request, encryted_response, decrypted_request, decrypted_response, created_by, method_name)VALUES($1,$2,$3,$4,$5,$6)`, [encrypt_request, encrypt_response, request, response, null, method])

}

saveErrorAuditLogs = async (request, response, method) => {
    // let encrypt_request = encryptionDecryption.encrypt(JSON.stringify(request));
    //let encrypt_response = encryptionDecryption.encrypt(JSON.stringify(response));
    await pool.query(`INSERT INTO amfi_audit_logs
    ( encrypted_request, encryted_response, decrypted_request, decrypted_response, created_by, method_name)VALUES($1,$2,$3,$4,$5,$6)`, [method, '', request, response, null, 'TESTERRORLOG'])

}

removeActiveSession = async (user_name) => {
    let res = await pool.query(`select "uuid" from amfi_user_session where "user_name"=$1`, [user_name])
    if (res['rowCount'] > 0) {
        let uuid = res['rows'][0]['uuid'];
        pool.query(`delete from amfi_user_session where  "user_name"=$1`, [user_name])
        //update token empty
        return uuid;
    }
    return null;

}

module.exports = {
    upload_file,
    base64ToThumbnail,
    generateApplicationNumber,
    generateTicketNumber,
    saveAuditLogs,
    removeActiveSession,
    saveErrorAuditLogs
}