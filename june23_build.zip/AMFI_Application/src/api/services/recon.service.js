const moment = require('moment');
const recon_enc_dec = require('../../common/recon_encrypt_decrypt');
const crypto = require("crypto");
const https = require('https');
const pool = require('../../config/db');
const helperService = require("../services/helper.service");
// require('dotenv').config();
const envObj = require('../../config/env.config');


reconGetApplicationData = async () => {
    let host = envObj.RECON_GETAPPDATAHOST;
    let endpoint = '/rocapi/v1/appdata';
    let headers = {
        'content-type': 'application/json',
        'clientid': 'AMFI',
        'signature': await signatureCreation(),
        'datetimestamp': moment().format('yyyyMMddHHmmss')
    };

    let body = {
        'clientid': 'AMFI',
        'filetype': 'TRANSACTION',
        'fromdate': '01/02/2021',
        'todate': '05/02/2021'
    }
    //encrypt the request body 
    let encryptedBody = await recon_enc_dec.EncryptionandDecryption('E', JSON.stringify(body))

    let reqbody = {
        'req': encryptedBody
    }
    var options = {
        method: 'POST',
        body: reqbody,
        json: true,
        url: host,
        headers: headers
    };
    let int_res = await curlRequest(options)

    let res = await recon_enc_dec.EncryptionandDecryption('D', int_res['res'])

}
reconApiImportData = async (pan_no) => {
    try {
        await helperService.saveErrorAuditLogs(pan_no, '', 'RECON1')
        let dd_cheque_number = '';
        let dd_cheque_date = null;
        let amount = 0;
        let drawn_on_bank_branch = '';
        let UniqueTxnID = crypto.randomBytes(16).toString("hex");
        let name_of_bank = '';
        let selected_data = await pool.query(`select dd_cheque_number ,dd_cheque_date ,amount ,drawn_on_bank_branch,name_of_bank ,branch ,"account_Number" ,account_type   from amfi_distributer_master_pending 
    where "pan_no"=$1`, [pan_no])

        if (selected_data['rowCount'] > 0) {
            await helperService.saveErrorAuditLogs(pan_no, '', 'RECON2')

            dd_cheque_number = selected_data['rows'][0]['dd_cheque_number']
            dd_cheque_date = selected_data['rows'][0]['dd_cheque_date']
            amount = selected_data['rows'][0]['amount']
            drawn_on_bank_branch = selected_data['rows'][0]['drawn_on_bank_branch']
            name_of_bank = selected_data['rows'][0]['name_of_bank']
        }
        let host = envObj.RECON_IMPORTDATAHOST;
        let endpoint = '/rocapi/v1/importdata';
        let headers = {
            'content-type': 'application/json',
            'clientid': 'AMFI',
            'signature': await signatureCreation(),
            'datetimestamp': moment().format('yyyyMMddHHmmss')
        };

        let body = {
            'clientid': 'AMFI',
            'filetype': 'TRANSACTION',
            'mappingid': 'TRANSACTION_POSTED',
            'setupid': 'TRANSACTION_POSTED',
            "data": [{
                "reqrefno": "002",
                "policynumber": "OP1234567",
                "InvestAmount": "1000.00",
                "NIGO": "", "ARN": "", "TAX_STATUS_CODE": "", "DD_No": dd_cheque_number, "Bank_Name": name_of_bank, "AMOUNT": amount, "DD_Date": dd_cheque_date, "Inward_date": "", "Name": "", "Status": "", "Intimation": "", "PAN_NO": pan_no, "TAX_NO": 0, "OCCUPATION_CODE": "", "INSTRM_NO": "", "FOLIO_NO": UniqueTxnID, "ARN_EMP_CODE": "", "ALTERNATE_FOLIO_NO": "", "ALTERNATE_BROKER_DEALER_NO": "", "INVESTOR_FIRST_NAME": "", "ADDRESS1": "", "ADDRESS2": "", "ADDRESS3": "", "CITY": "", "PINCODE": "", "PHONE_RES": "", "PHONE_OFF": "", "MOBILE_NO": "", "EMAIL": "", "SCHEME_CODE": "", "TRADE_DATE_TIME": "22/04/2022", "POSTED_DATE": "22/04/2022", "LOCATION_CODE": "", "LOCATION_NAME": "", "PAYIN_SLIP_NO": "", "UNITS": 0, "VALUE": 0, "TRXN_CHARGES": 0, "TRXN_TYPE": "", "TRXN_NO": "", "USER_TRXNNO": "", "PAYMENT_MECHANISM": "", "INSTRM_DATE": "", "BANK": "", "BANK_CHARGES": 0, "CLR_FLAG": "", "CLR_DATE": "", "DEPOSIT_DATE": "", "APPLICATION_NO": "", "AUTO_TRXN_NO": "", "IPOREGNO": "", "BROK_DLR_CODE": "", "USER_CODE": "1000", "BANK_NAME": name_of_bank, "TRXN_DESC_SUFFIX": "", "TDP_REMARKS": "", "DT_REMARKS": "", "PFOLIO_NO": ""
            }]
        }

        let encryptedBody = await recon_enc_dec.EncryptionandDecryption('E', JSON.stringify(body))

        let reqbody = {
            'req': encryptedBody
        }


        var options = {
            method: 'POST',
            body: reqbody,
            json: true,
            url: host,
            headers: headers
        };

        let int_res = await curlRequest(options)
        await helperService.saveErrorAuditLogs(pan_no, int_res, 'RECON3')

        let res = JSON.parse(await recon_enc_dec.EncryptionandDecryption('D', int_res['res']))

        let auth_status = res['errorcode']
        let status_reason = res['data'][0]['resmessage']
        let proposed_txn_status = res['message']
        await helperService.saveErrorAuditLogs(pan_no, res, 'RECON4')

        let sys_appl_no = '';
        let select_appno = await pool.query(`select application_reference_no,application_type  ,renewal_type  from amfi_distributer_master_pending where pan_no =$1
        `, [pan_no])

        let req_type = '';
        if (select_appno['rowCount'] > 0) {
            sys_appl_no = select_appno['rows'][0]['application_reference_no'];
            let application_type = select_appno['rows'][0]['application_type'];
            let renewal_type = select_appno['rows'][0]['renewal_type'];

            if (application_type == 'ARN') {
                if (renewal_type == 'REGISTRATION') {
                    req_type = 'ARN_REG'
                }
                else {
                    req_type = 'ARN_REN'
                }
            }
            else {
                if (renewal_type == 'REGISTRATION') {
                    req_type = 'EUIN_REG'
                }
                else {
                    req_type = 'EUIN_REN'
                }
            }
        }

        await pool.query(`INSERT INTO tbl_payments_sts
    ( pan_no, sys_appl_no, trxn_date, psp_id, amount, psp_trxn_ref, payment_status, psp_trxn_rem,  created_by, modified_by, modified_date, auth_status, status_reason, proposed_txn_status)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`, [pan_no, sys_appl_no, 'now()', '', amount, UniqueTxnID, '', req_type, null, null, 'now()', auth_status, status_reason, proposed_txn_status])

        if (auth_status == 'RC111') {
            await helperService.saveErrorAuditLogs(pan_no, auth_status, 'RECON5')

            return true;
        }
        return false;
    }
    catch (err) {
        console.log("error=============>", err)
    }
}

signatureCreation = async () => {
    let client_id = 'AMFI';
    let secret_key = 'vFT8xdnxYJMpv+43ip4MFftZyma5dOBhNJXkK4bOLFs='
    let hmac_key = 'QU1GSWhtYWM='
    let data = client_id + "::" + secret_key + "::" + moment().format('yyyyMMddHHmmss')
    let hash = crypto.createHmac('sha256', hmac_key)
        .update(data)
        .digest('hex');

    return hash;
}

curlRequest = async (options) => {
    var request = require('request');
    return new Promise((resolve, reject) => {
        request(options, function callback(error, response, body) {
            if (error) {
                let newErr = "CURL Request failed for " + error;
                return reject(newErr);
            } else {
                resolve(body)
            }
        });
    })
}



module.exports = {
    reconGetApplicationData,
    reconApiImportData,
    signatureCreation
}


