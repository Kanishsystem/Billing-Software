const crypto = require("crypto");
const pool = require("../../config/db");
const envObj = require('../../config/env.config');
const registrationService = require('../services/registration.service')
// require('dotenv').config();
const moment = require("moment");
const helperService = require('../services/helper.service');


createOnlinePayment = async (reqObj) => {
    let resObj = {}
    const url = envObj.BILLDESK_URL;
    let flag = true;
    let UniqueTxnID = '';
    while (flag) {
        UniqueTxnID = crypto.randomBytes(16).toString("hex");
        let checkUnique = await checkTransactionExists(UniqueTxnID);
        if (checkUnique == false) {
            flag = false;
        }
    }
    let MerchantID = envObj.BILLDESK_MERCHANTID;
    let TxnAmount = parseFloat(reqObj.cost).toFixed(2);
    let CurrencyType = 'INR';
    let TypeField1 = envObj.BILLDESK_TYPEFIELD1;
    let SecurityID = envObj.BILLDESK_SECURITYID;
    let TypeField2 = envObj.BILLDESK_TYPEFIELD2
    let RU = envObj.application_url + `/payment/saveOnlinePaymentTransaction`
    const NA = 'NA'

    let reqData = MerchantID + "|" + UniqueTxnID + "|" + NA + "|" + TxnAmount + "|" + NA + "|" + NA + "|" + NA + "|" + CurrencyType + "|" + NA + "|" + TypeField1 + "|" + SecurityID + "|" + NA + "|" + NA + "|" + TypeField2 + "|" + NA + "|" + NA + "|" + NA + "|" + NA + "|" + NA + "|" + NA + "|" + NA + "|" + RU


    const secret = envObj.BILLDESK_SECRET;
    const hash = crypto.createHmac(envObj.BILLDESK_ALGORITHM, secret)
        .update(reqData)
        .digest('hex');

    let response = reqData + '|' + hash.toString().toUpperCase();

    let sys_appl_no = '';
    let select_appno = await pool.query(`select application_reference_no  from amfi_distributer_master_pending where pan_no =$1
    `, [reqObj.pan_no])

    if (select_appno['rowCount'] > 0) {
        sys_appl_no = select_appno['rows'][0]['application_reference_no'];
    }

    await pool.query(`INSERT INTO tbl_payments_sts
    ( pan_no, sys_appl_no, trxn_date, psp_id, amount, psp_trxn_ref, payment_status, psp_trxn_rem,  created_by, modified_by, modified_date, auth_status, status_reason, proposed_txn_status)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`, [reqObj.pan_no, sys_appl_no, 'now()', '', reqObj.cost, UniqueTxnID, '', reqObj.req_type, null, null, 'now()', '', '', ''])

    return response;

}

checkTransactionExists = async (UniqueTxnID) => {
    let res = await pool.query(`select * from tbl_payments_sts where psp_trxn_ref=$1`, [UniqueTxnID])

    if (res['rowCount'] > 0) {
        return true;
    }
    return false;
}

saveOnlinePaymentTransaction = async (reqObj) => {
    let data = reqObj.split('|');
    let UniqueTxnID = data[1];
    let auth_status = data[14];
    let status_reason = '';
    let proposed_txn_status = '';
    let payment_status = '';
    if (auth_status == '0300') {
        let select_data = await pool.query(`select pan_no,psp_trxn_rem,psp_trxn_rem from tbl_payments_sts where "psp_trxn_ref"=$1`, [UniqueTxnID])
        if (select_data['rowCount'] > 0) {
            let data = {
                "pan_no": select_data['rows'][0]['pan_no']
            }
            if (select_data['rows'][0]['psp_trxn_rem'] == 'ARN_REG' || select_data['rows'][0]['psp_trxn_rem'] == 'EUIN_REG' || select_data['rows'][0]['psp_trxn_rem'] == 'ARN_REN' || select_data['rows'][0]['psp_trxn_rem'] == 'EUIN_REN') {
                registrationService.updatePayment(data);

            }
        }
        status_reason = 'Success';
        proposed_txn_status = 'Successful Transaction';
        payment_status = 'S';
    }
    else if (auth_status == '0399') {
        status_reason = 'Invalid Authentication at Bank';
        proposed_txn_status = 'Failure Transaction';
        payment_status = 'F';
    }
    else if (auth_status == 'NA') {
        status_reason = 'Invalid Input in the Request Message';
        proposed_txn_status = 'Failure Transaction';
        payment_status = 'F';

    }
    else if (auth_status == '0002') {
        status_reason = 'BillDesk is waiting for Response from Bank';
        proposed_txn_status = 'Pending Transaction';
        payment_status = 'P';

    }
    else if (auth_status == '0001') {
        status_reason = 'Error at BillDesk';
        proposed_txn_status = 'Failure Transaction';
        payment_status = 'F';
    }
    await pool.query(`update tbl_payments_sts set "auth_status"=$2,"status_reason"=$3,"proposed_txn_status"=$4,"payment_status"=$5 where "psp_trxn_ref"=$1`, [UniqueTxnID, auth_status, status_reason, proposed_txn_status, payment_status])


    return { "auth_status": auth_status, "status_reason": status_reason, "proposed_txn_status": proposed_txn_status, "payment_status": payment_status };

}

billdeskCallbackTxnStatusUpdate = async () => {
    try {
        let resObj = {}
        const host = "https://uat.billdesk.com/pgidsk/PGIQueryController";

        let select_data = await pool.query(`select psp_trxn_ref ,pan_no ,sys_appl_no  from tbl_payments_sts where payment_status ='P'
    `)

        if (select_data['rowCount'] > 0) {

            for (let i = 0; i < select_data['rows'].length; i++) {
                let RequestType = 0122;
                let MerchantID = envObj.BILLDESK_MERCHANTID;
                let UniqueTxnID = select_data['rows'][i]['psp_trxn_ref'];
                let currentdate = moment().format('yyyymmdd24hhmmss')

                let reqData = RequestType + "|" + MerchantID + "|" + UniqueTxnID + "|" + currentdate

                const secret = envObj.BILLDESK_SECRET;
                const hash = crypto.createHmac(envObj.BILLDESK_ALGORITHM, secret)
                    .update(reqData)
                    .digest('hex');

                let response = reqData + '|' + hash.toString().toUpperCase();

                let headers = {
                    'content-type': 'application/json',
                };

                var options = {
                    method: 'POST',
                    msg: response,
                    // json: true,
                    url: host,
                    headers: headers
                };

                let int_res = await curlRequest(options);
                helperService.saveAuditLogs(options, int_res, 'BILLDESKCALLBACK')
            }
        }
        return null;

    } catch (error) {
        console.log(error)
    }
}

curlRequest = async (options) => {
    var request = require('request');
    return new Promise((resolve, reject) => {
        request(options, function callback(error, response, body) {
            if (error) {
                let newErr = "CURL Request failed for " + error;
                return reject(newErr);
            } else {
                resolve(body)
            }
        });
    })
}

module.exports = {
    createOnlinePayment,
    checkTransactionExists,
    saveOnlinePaymentTransaction,
    billdeskCallbackTxnStatusUpdate
}

