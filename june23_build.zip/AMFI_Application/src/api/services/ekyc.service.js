const _encdec = require("../../ekyc/ekyc_encryption_decryption");
// require('dotenv').config();
const crypto = require('crypto');
const envObj = require('../../config/env.config');
const pool = require("../../config/db");
const helperService = require("../services/helper.service");


verifyAadhar = async (reqObj) => {
    let source = '';
    if ('source' in reqObj) {
        source = reqObj.source;
    }
    var kyc_data = reqObj.pan_no + "|" + reqObj.email_id + "|" + reqObj.mobile_no + "|" + envObj.AADHAAR_APPLICATION_ID + "|" +
        envObj.AADHAAR_USER_ID + "|" + envObj.AADHAAR_PASSWORD + "|" + envObj.AADHAAR_INTERMEDIARY_ID + "|" + envObj.AADHAAR_RETURN_DATA_STRUCTURE;

    var hash = crypto.createHash(envObj.AADHAAR_ALGORITHM);

    data = hash.update(kyc_data, 'uft8');
    gen_hash = data.digest('hex');
    aesKey = await _encdec.getAESKey();
    let aesKeyEncrypted = await _encdec.encryptAESKeyUsingPublicKeyForAdhaar(aesKey);
    requestData = await _encdec.encdec('E', aesKey, kyc_data);
    var hashvalue = await _encdec.encdec('E', aesKey, gen_hash);  //Same as above function
    var finalObj = aesKeyEncrypted + "|" + requestData + "|" + hashvalue;
    let url = envObj.application_url + `/ekyc/saveAadharResponse`
    if (finalObj) {
        const responseData = {
            "aadhar_url": `${envObj.AADHAAR_KYC}`,
            // "redirect_url": `${envObj.SUBSCRIBER_SERVICE_EXTERNAL}/api/v1/subscriber/third-party/save-aadhar-details?source=${reqObj.source}&logId=${logData && logData.ref_id ? logData.ref_id : ''}`,
            "redirect_url": url,
            "kyc_data": finalObj,
            "sess_id": JSON.stringify({ "request_category": "REGISTRATION", "source": source }),
            "ekyctype": "I",
            "Plkyc_type": "INVESTOR"
        }
        return responseData
    }
    return null
}



getEncryptedResult = async (data) => {
    try {
        var splitData = data;
        var ref = splitData.split('|')
        var key = ref[0];
        var data1 = ref[1];
        var hash = ref[2];
        let aesKeyEncrypted = Buffer.from(key, "base64");
        let data2 = Buffer.from(data1, "base64");
        let hash2 = Buffer.from(data1, "base64");
        aesKey = await _encdec.getAESKey();
        decAesKey = await _encdec.decryptAESKeyUsingPrivateKeyForAadhar(aesKeyEncrypted);
        requestData = await _encdec.encdec('D', decAesKey, data2);
        var hashvalue = await _encdec.encdec('D', decAesKey, hash2);
        return requestData;
    } catch (error) {
        throw error;
    }
}

saveMfkycData = async (data) => {
    try {

        var splitData = data;
        var ref = splitData.split('|')
        var key = ref[0];
        var data1 = ref[1];
        var hash = ref[2];

        let aesKeyEncrypted = Buffer.from(key, "base64");
        let data2 = Buffer.from(data1, "base64");
        let hash2 = Buffer.from(data1, "base64");
        aesKey = await _encdec.getAESKey();
        decAesKey = await _encdec.decryptAESKeyUsingPrivateKeyForAadhar(aesKeyEncrypted);
        requestData = await _encdec.encdec('D', decAesKey, data2);
        var hashvalue = await _encdec.encdec('D', decAesKey, hash2);

        let resData = requestData.split('|');

        let pan_name = resData[3];
        let pan_no = resData[2];
        let father_name = resData[6];
        let dob = resData[7];
        let email_id = resData[8];
        let mobile_no = resData[9];
        let aadhar_name = resData[12];
        let gender = resData[40];
        let marital_status = resData[42];
        let natinality = resData[24];
        // let resd_status = resData[8];
        let address1 = resData[17];
        let address2 = resData[18];
        let address3 = resData[11];
        let city = resData[20];
        let state = resData[22];
        let pincode = resData[19];
        let address_type = resData[19];
        let account_Number = resData[52];
        let ifsc = resData[49];
        let account_type = resData[53];
        let name_of_bank = resData[51]
        let branch = resData[54];
        let bank_city = resData[55];

        if (gender == 'MALE') {
            gender = 'M';
        }
        else {
            gender = 'F';
        }

        await pool.query(`UPDATE amfi_distributer_master_pending SET "first_name"=$2,"date_of_birth" = $3,"gender" = $4,"address1"=$5,"address2"=$6,"address3"=$7,"city"=$8,"pincode"=$9,"state"= $10,"email_id"=$11,"mobile_no"=$12,"account_Number"=$13,ifsc=$14,"account_type"=$15,"name_of_bank"=$16,"branch"=$17,"bank_city"=$18 where "pan_no"=$1`, [pan_no, aadhar_name, dob, gender, address1, address2, address3, city, pincode, state, email_id, mobile_no, account_Number, ifsc, account_type, name_of_bank, branch, bank_city])

        return requestData;
    } catch (error) {
        console.log("error===========>", error)
        throw error;
    }
}

updateEkycFiles = async (data) => {
    console.log("data===========>", data.pan_no)
    let panid = null;
    let signid = null;
    let aadharid = null;
    if (data.pan_base64 != null || data.pan_base64 != '') {
        let req_data = {
            "file_name": data['pan_no'] + "_" + 'pan' + "_" + Date.now() + "." + data.pan_filetype,
            "image_type": data.pan_filetype,
            "image": data.pan_base64
        }

        panid = await helperService.upload_file(req_data);
    }
    if (data.aadhar_base64 != null || data.aadhar_base64 != '') {
        let req_data = {
            "file_name": data['pan_no'] + "_" + 'aadhar' + "_" + Date.now() + "." + data.aadhar_filetype,
            "image_type": data.aadhar_filetype,
            "image": data.aadhar_base64
        }

        aadharid = await helperService.upload_file(req_data);
    }
    if (data.signature_base64 != null || data.signature_base64 != '') {
        let req_data = {
            "file_name": data['pan_no'] + "_" + 'pan' + "signature" + Date.now() + "." + data.signature_filetype,
            "image_type": data.signature_filetype,
            "image": data.signature_base64
        }

        signid = await helperService.upload_file(req_data);
    }
    if (data.photo_base64 != null || data.photo_base64 != '') {
        let req_data = {
            "file_name": data['pan_no'] + "_" + 'photo' + "_" + Date.now() + "." + data.photo_filetype,
            "image_type": data.photo_filetype,
            "image": data.photo_base64
        }

        photoid = await helperService.upload_file(req_data);
    }
    let res = await pool.query(`update amfi_distributer_master_pending set pancard_filepath=$2 ,adharcard_filepath=$3 ,signature_filepath=$4 ,photo_filepath=$5 where pan_no=$1 returning "pan_no"`, [data.pan_no, panid, aadharid, signid, photoid])

    if (res['rowCount'] > 0) {
        return data.pan_no;
    }

    return null;
}

updateEkycFiles1 = async (data) => {
    var splitData = data;
    var ref = splitData.split('|')
    var key = ref[0];
    var data1 = ref[1];
    var hash = ref[2];

    let aesKeyEncrypted = Buffer.from(key, "base64");
    let data2 = Buffer.from(data1, "base64");
    let hash2 = Buffer.from(data1, "base64");
    aesKey = await _encdec.getAESKey();
    decAesKey = await _encdec.decryptAESKeyUsingPrivateKeyForAadhar(aesKeyEncrypted);
    requestData = await _encdec.encdec('D', decAesKey, data2);
    var hashvalue = await _encdec.encdec('D', decAesKey, hash2);
    console.log("data=============>", data)
    let resData = requestData.split('|');

    // API User ID | API Password | Session ID | Base64 ID Proof Image | Base64 Address Proof Image | Base64 Correspondence Proof Image | Base64 Cheque Image | Base64 Investor Image or Investor Photo in Aadhaar | Base64 Investor Video | Base64 Investor Signature Image | e-Signed PDF Document

    let id_proof_base64 = resData[3]
    let address_proof = resData[4]
    let aadhar_base64 = resData[7]
    let signature_base64 = resData[9]

}

module.exports = {
    verifyAadhar,
    getEncryptedResult,
    saveMfkycData,
    updateEkycFiles,
    updateEkycFiles1
}