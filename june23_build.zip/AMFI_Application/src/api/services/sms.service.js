
const message_sender = require('../../common/message_sender');
const pool = require("../../config/db");

sendOtpMobileRegistration = async (pan_no, mobile_no) => {
    // let sixdigitOtp = Math.floor(100000 + Math.random() * 900000);
    let otpmobile = '123456'; //common.random number generator 6 digit
    let msg = "Hi AMFI ur otp " + otpmobile;
    let no_of_attempts = 0;

    await message_sender.sendMessage(msg, mobile_no);

    let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [pan_no])
    if (res['rowCount'] > 0) {
        await pool.query(`update amfi_mobile_email_otp set "mobile_otp"=$1,"mobile_no"=$2,"lastmobile_otp_senttime"=$3,"modified_date"=$5,"no_of_attempts"=$6 where "pan_no"=$4`, [otpmobile, mobile_no, 'now()', pan_no, 'now()', no_of_attempts])
    }
    else {
        await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, [mobile_no, '', otpmobile, '', 'now()', 'now()', no_of_attempts, true, null, null, 'now()', pan_no])
    }

    //save to database
    //otp , email 
}


sendOtpMobileResume = async (pan_no, mobile_no) => {
    // let sixdigitOtp = Math.floor(100000 + Math.random() * 900000);
    let otpmobile = '123456'; //common.random number generator 6 digit
    let msg = "Hi AMFI ur otp " + otpmobile;
    let no_of_attempts = 0;

    await message_sender.sendMessage(msg, mobile_no);

    let res = await pool.query(`select * from amfi_mobile_email_otp where "pan_no"=$1`, [pan_no])
    if (res['rowCount'] > 0) {
        await pool.query(`update amfi_mobile_email_otp set "mobile_otp"=$1,"mobile_no"=$2,"lastmobile_otp_senttime"=$3,"modified_date"=$5,"no_of_attempts"=$6 where "pan_no"=$4`, [otpmobile, mobile_no, 'now()', pan_no, 'now()', no_of_attempts])
    }
    else {
        await pool.query(`INSERT INTO  amfi_mobile_email_otp("mobile_no","email_id","mobile_otp","email_otp","lastemail_otp_senttime","lastmobile_otp_senttime","no_of_attempts","status","created_by","modified_by","modified_date","pan_no")Values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, [mobile_no, '', otpmobile, '', 'now()', 'now()', no_of_attempts, true, null, null, 'now()', pan_no])
    }

    //save to database
    //otp , email 
}

module.exports = {
    sendOtpMobileRegistration,
    sendOtpMobileResume
}