
let responseData = {
    message: String,
    status: Number,
    data: [],
    id: Number,
    record_count: Number
}
module.exports = responseData;