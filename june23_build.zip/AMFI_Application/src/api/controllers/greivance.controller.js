let responseData = require('../models/responsemodel');
let greivanceService = require('../services/greivance.service');

getGreivanceCategory = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await greivanceService.getGreivanceCategory(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getGreivanceSubCategory = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await greivanceService.getGreivanceSubCategory(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

raiseGreivanceRequest = async (reqObj) => {
    try {
        responseData.data = [];
        responseData.id = 0;
        if (reqObj.pan_no == '' || reqObj.pan_no == null) {
            responseData.message = 'Please Enter all the required Data';
            responseData.status = 500;
            return responseData;
        }

        let res = await greivanceService.raiseGreivanceRequest(reqObj);
        reqObj.ticket_no = res.ticket_no;
        responseData.id = res.id;
        responseData.data = reqObj;
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        responseData.data = []
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

searchAllGreivanceDetailsByFO = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await greivanceService.searchAllGreivanceDetailsByFO(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        responseData.reqObj = reqObj;
        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getGreivanceDetailsById = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await greivanceService.getGreivanceDetailsById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
getGreivanceQueue = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await greivanceService.getGreivanceQueue(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

addGreivanceResponses = async (reqObj) => {
    try {
        responseData.data = [];
        responseData.id = 0;
        if (reqObj.pan_no == '' || reqObj.pan_no == null) {
            responseData.message = 'Please Enter all the required Data';
            responseData.status = 500;
            return responseData;
        }

        let res = await greivanceService.addGreivanceResponses(reqObj);
        reqObj.ticket_no = res.ticket_no;
        responseData.id = res.id;
        responseData.data = reqObj;
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        responseData.data = []
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getGreivanceMessages = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await greivanceService.getGreivanceMessages(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getGreivanceMessageDetailsForArn = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await greivanceService.getGreivanceMessageDetailsForArn(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

greivanceCloseTicket = async (reqObj) => {
    try {
        responseData.data = [];
        responseData.id = 0;
        if (reqObj.pan_no == '' || reqObj.pan_no == null) {
            responseData.message = 'Please Enter all the required Data';
            responseData.status = 500;
            return responseData;
        }

        let res = await greivanceService.greivanceCloseTicket(reqObj);
        reqObj.ticket_no = res.ticket_no;
        responseData.id = res.id;
        responseData.data = reqObj;
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        responseData.data = []
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
greivanceMessageMarkAsRead = async (reqObj) => {
    try {
        responseData.id = await greivanceService.greivanceMessageMarkAsRead(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

resolveTicketByUser = async (reqObj) => {
    try {
        responseData.id = await greivanceService.resolveTicketByUser(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

deleteGreivanceMessage = async (reqObj) => {
    try {
        responseData.id = await greivanceService.deleteGreivanceMessage(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

deleteAllGreivanceMessage = async (reqObj) => {
    try {
        responseData.id = await greivanceService.deleteAllGreivanceMessage(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}


module.exports = {
    getGreivanceCategory,
    getGreivanceSubCategory,
    raiseGreivanceRequest,
    searchAllGreivanceDetailsByFO,
    getGreivanceDetailsById,
    getGreivanceQueue,
    addGreivanceResponses,
    getGreivanceMessages,
    getGreivanceMessageDetailsForArn,
    greivanceCloseTicket,
    greivanceMessageMarkAsRead,
    resolveTicketByUser,
    deleteGreivanceMessage,
    deleteAllGreivanceMessage
}