let responseData = require('../models/responsemodel')
let offlineregisterService = require('../services/offlineregister.service')
let registrationService = require('../services/registration.service')
let authservice = require('../../common/auth');
let reconService = require('../services/recon.service');
let helperService = require('../services/helper.service')

getState = async () => {
    try {
        responseData.data = await offlineregisterService.getState();
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}



saveOfflineRegister = async (reqObj) => {
    try {
        responseData.data = [];
        responseData.id = 0;

        if (reqObj.application_type == '' || reqObj.pan_no == '' || reqObj.application_type == null || reqObj.pan_no == null) {
            responseData.message = 'Please Enter all the required Data';
            responseData.status = 500;
            return responseData;
        }
        if (await registrationService.checkInvalidDetails(reqObj)) {
            responseData.message = 'PAN Number is Invalid';
            responseData.status = 500;
            return responseData;
        }

        if (reqObj.category_of_corporation != 'COR') {
            if (reqObj.application_type == 'ARN') {

                //verification pan 4th Character in pending table
                if (await registrationService.pan4thcharacter(reqObj.pan_no)) {
                    responseData.message = 'Entered PAN cannot be registered for category : “Selected Category”. Click here to see why!';
                    responseData.status = 500;
                    return responseData;
                }

            }
            // verification pan no in Nism table
            if (await registrationService.panExistsInNism(reqObj.pan_no)) {
                responseData.message = 'Pan no does not exist in nism';
                responseData.status = 500;
                return responseData;
            }

            if (await registrationService.panExpireInNism(reqObj.pan_no)) {
                responseData.message = 'For the entered PAN, your NISM certificate has expired. Please ensure your NISM certificate is valid before submitting the request';
                responseData.status = 500;
                return responseData;
            }
        }



        // verification pan no in pending table
        if (await registrationService.panExistsInPending(reqObj.pan_no)) {
            responseData.message = 'Requested PAN is already registered and Pending';
            responseData.status = 500;
            return responseData;
        }
        // verification pan no in activated table
        if (await registrationService.panExistsInActivated(reqObj.pan_no)) {
            responseData.message = 'Requested PAN is already registered and active';
            responseData.status = 500;
            return responseData;
        }

        let res = await offlineregisterService.saveOfflineRegister(reqObj);
        reqObj.application_reference_no = res.application_reference_no;
        responseData.id = res.id;
        responseData.data = reqObj;
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;

}

getDocumentCheckListByType = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getDocumentCheckListByType(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

loginFO = async (reqObj) => {
    let responseobj = {}
    try {
        responseobj.data = await offlineregisterService.loginFO(reqObj);
        responseobj.message = 'login Success';
        responseobj.status = 200;
        responseobj.id = 0;

        if (responseobj.data == null) {
            responseobj.data = reqObj;
            responseobj.status = 422;
            responseobj.message = "login failed"
        }
        else {
            responseobj.token = await authservice.generateAuthToken(responseobj.data[0].user_id, responseobj.data[0].user_name, '');
            await offlineregisterService.updateFOBOtoken(responseobj.data[0].user_id, responseobj.data[0].user_name, responseobj.token);
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseobj.message = msg;
        responseobj.status = 500;
    }
    return responseobj;
}

getOfflineRegisterDataById = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getOfflineRegisterDataById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitOfflineRegister = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.submitOfflineRegister(reqObj);
        responseData.message = 'Application Submitted Successfully';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAllARNList = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAllARNList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updatePriority = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.updatePriority(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateFo1Assign = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.updateFo1Assign(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getOfflineApplicantDatasById = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getOfflineApplicantDatasById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthorisation = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthorisation(reqObj, 'Authorise', 'AUTHORISE');
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateFo2Assign = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.updateFo2Assign(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == false) {
            responseData.status = 500;
            responseData.message = "Same Person Canot do the Verification"
            responseData.id = 0;
        }
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getUploadedDocumentById = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getUploadedDocumentById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null || Object.values(responseData.data).length == 0) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

loginBO = async (reqObj) => {
    let responseobj = {}
    try {
        responseobj.data = await offlineregisterService.loginBO(reqObj);
        responseobj.message = 'login Success';
        responseobj.status = 200;
        responseobj.id = 0;

        if (responseobj.data == null) {
            responseobj.data = reqObj;
            responseobj.status = 422;
            responseobj.message = "login failed"
        }
        else {
            responseobj.token = await authservice.generateAuthToken(responseobj.data[0].user_id, responseobj.data[0].user_name, '');
            await offlineregisterService.updateFOBOtoken(responseobj.data[0].user_id, responseobj.data[0].user_name, responseobj.token);
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseobj.message = msg;
        responseobj.status = 500;
    }
    return responseobj;
}

getAuthorisationList = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthorisationList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}



saveOfflineRenewal = async (reqObj) => {
    try {
        responseData.data = [];
        responseData.id = 0;

        if (reqObj.renewal_type == '' || reqObj.pan_no == '' || reqObj.renewal_type == null || reqObj.pan_no == null) {
            responseData.message = 'Please Enter all the required Data';
            responseData.status = 500;
            return responseData;
        }

        if (await registrationService.checkInvalidDetails(reqObj)) {
            responseData.message = 'PAN Number is Invalid';
            responseData.status = 500;
            return responseData;
        }

        if (reqObj.renewal_type == 'ARN') {

            //verification pan 4th Character in pending table
            // if (await registrationService.pan4thcharacter(reqObj.pan_no)) {
            //     responseData.message = 'Entered PAN cannot be registered for category : “Selected Category”. Click here to see why!';
            //     responseData.status = 500;
            //     return responseData;
            // }


            if (!await registrationService.arnExistsInActivated(reqObj.arn_number)) {
                responseData.message = 'ARN number is not Active';
                responseData.status = 500;
                return responseData;
            }

            if (!await registrationService.euinExistsInActivated(reqObj.euin_number)) {
                responseData.message = 'EUIN number is not Active';
                responseData.status = 500;
                return responseData;
            }
        }
        else if (reqObj.renewal_type == 'EUIN') {
            if (!await registrationService.euinExistsInActivated(reqObj.euin_number)) {
                responseData.message = 'EUIN number is not Active';
                responseData.status = 500;
                return responseData;
            }

        }


        // verification pan no in Nism table
        // if (await registrationService.panExistsInNism(reqObj.pan_no)) {
        //     responseData.message = 'Pan no does not exist in nism';
        //     responseData.status = 500;
        //     return responseData;
        // }

        // if (await registrationService.panExpireInNism(reqObj.pan_no)) {
        //     responseData.message = 'For the entered PAN, your NISM certificate has expired. Please ensure your NISM certificate is valid before submitting the request';
        //     responseData.status = 500;
        //     return responseData;
        // }

        if (await registrationService.checkNismCertificateDate(reqObj.pan_no)) {
            responseData.message = "Please update the latest NISM details to proceed";
            responseData.status = 500;
            return responseData;
        }
        // verification pan no in pending table
        // if (await registrationService.panExistsInPending(reqObj.pan_no)) {
        //     responseData.message = 'Requested PAN is already renewed and Pending';
        //     responseData.status = 500;
        //     return responseData;
        // }
        // verification pan no in activated table
        if (!await registrationService.panExistsInActivated(reqObj.pan_no)) {
            responseData.message = 'Requested PAN Does Not registered and active';
            responseData.status = 500;
            return responseData;
        }

        // if (await registrationService.checkEuinExistsForCorpARN(reqObj)) {
        //     responseData.message = 'Please register an EUIN who is having a valid ARN validity to proceed further';
        //     responseData.status = 500;
        //     return responseData;
        // }

        let validres = await registrationService.checkandGetValidFromandToDate(reqObj)
        if (validres == null) {
            responseData.message = 'Please register an EUIN who is having a valid ARN validity to proceed further';
            responseData.status = 500;
            return responseData;
        }
        else {
            reqObj['validity_from'] = validres.validity_from;
            reqObj['validity_to'] = validres.validity_to;

        }

        let res = await offlineregisterService.saveOfflineRenewal(reqObj);
        reqObj.application_reference_no = res.application_reference_no;
        responseData.id = res.id;
        responseData.data = reqObj;
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;

}

searchByArnNoApproved = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.searchByArnNoApproved(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
        else {
            responseData.id = responseData.data.id;
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

searchByEUINNoApproved = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.searchByEUINNoApproved(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
        else {
            responseData.id = responseData.data.id;
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

loginFOBO = async (reqObj) => {
    let responseobj = {}
    const { user_name, password, systemCode } = reqObj;

    if (!(user_name && password && systemCode)) {
        responseData.data = reqObj;
        responseData.id = 0
        responseData.status = 400;
        responseData.message = "All input is required"
        return responseData;
    }
    try {
        let session_flag = await registrationService.getUserSession(reqObj)
        responseobj.activeSessionStatus = session_flag;
        if (session_flag) {
            responseobj.data = reqObj;
            responseobj.status = 200;
            responseobj.message = "Session already Active";
            return responseobj;
        }

        let checkUser = await offlineregisterService.checkUserNameExists(reqObj);

        if (!checkUser) {
            responseobj.data = reqObj;
            responseobj.status = 500;
            responseobj.message = "Username Does not Exists";
            return responseobj;
        }
        responseobj.data = await offlineregisterService.loginFOBO(reqObj);
        responseobj.message = 'login Success';
        responseobj.status = 200;
        responseobj.id = 0;

        if (responseobj.data == null) {
            responseobj.data = reqObj;
            responseobj.status = 500;
            responseobj.message = "Login failed Invalid Password"
        }
        else {
            responseobj.token = await authservice.generateAuthToken(responseobj.data[0].user_id, responseobj.data[0].user_name, '');
            await offlineregisterService.updateFOBOtoken(responseobj.data[0].user_id, responseobj.data[0].user_name, responseobj.token);
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseobj.message = msg;
        responseobj.status = 500;
    }
    return responseobj;
}

getRequestTypes = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getRequestTypes(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

saveRequestedUpdate = async (reqObj) => {
    try {
        responseData.data = [];
        responseData.id = 0;
        if (reqObj.application_type == '' || reqObj.pan_no == '' || reqObj.application_type == null || reqObj.pan_no == null) {
            responseData.message = 'Please Enter all the required Data';
            responseData.status = 500;
            return responseData;
        }

        if (reqObj.application_type == 'ARN') {

            //verification pan 4th Character in pending table
            // if (await registrationService.pan4thcharacter(reqObj.pan_no)) {
            //     responseData.message = 'Entered PAN cannot be registered for category : “Selected Category”. Click here to see why!';
            //     responseData.status = 500;
            //     return responseData;
            // }


            if (!await registrationService.arnExistsInActivated(reqObj.arn_number)) {
                responseData.message = 'ARN number is not Active';
                responseData.status = 500;
                return responseData;
            }
            /*
                        if (!await registrationService.euinExistsInActivated(reqObj.euin_number)) {
                            responseData.message = 'EUIN number is not Active';
                            responseData.status = 500;
                            return responseData;
                        }
            */
        }
        else if (reqObj.application_type == 'EUIN') {
            if (!await registrationService.euinExistsInActivated(reqObj.euin_number)) {
                responseData.message = 'EUIN number is not Active';
                responseData.status = 500;
                return responseData;
            }

        }


        // verification pan no in Nism table
        // if (await registrationService.panExistsInNism(reqObj.pan_no)) {
        //     responseData.message = 'Pan no does not exist in nism';
        //     responseData.status = 500;
        //     return responseData;
        // }

        // if (await registrationService.panExpireInNism(reqObj.pan_no)) {
        //     responseData.message = 'For the entered PAN, your NISM certificate has expired. Please ensure your NISM certificate is valid before submitting the request';
        //     responseData.status = 500;
        //     return responseData;
        // }
        if (!await registrationService.panExistsInActivated(reqObj.pan_no)) {
            responseData.message = 'Requested PAN Does Not registered and active';
            responseData.status = 500;
            return responseData;
        }
        let already_reqexists = await offlineregisterService.isChangeRequestExists(reqObj.pan_no, reqObj.req_type);
        if (already_reqexists) {
            responseData.id = 0;
            responseData.data = [];
            responseData.message = 'Request Already Exists';
            responseData.status = 422;
            return responseData;
        }
        let res = await offlineregisterService.saveRequestedUpdate(reqObj);
        reqObj.application_reference_no = res.application_reference_no;
        responseData.id = res.id;
        responseData.data = reqObj;
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        responseData.data = []
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getRejectReason = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getRejectReason(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getGender = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getGender(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getOfflineUpdateById = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getOfflineUpdateById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitOfflineUpdate = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.submitOfflineUpdate(reqObj);
        responseData.message = 'Application Submitted Successfully';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getOfflineUpdateQueueList = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getOfflineUpdateQueueList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

offlineUpdatedataBoAssign = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.offlineUpdatedataBoAssign(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getFinancialYear = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getFinancialYear(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseSelfDeclareUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseSelfDeclareUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseSelfDeclaration = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseSelfDeclaration(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseSignatureUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseSignatureUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseSignature = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseSignature(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseBasicDetailsUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseBasicDetailsUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseBasicDetails = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseBasicDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseBankDetailsUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseBankDetailsUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseBankDetails = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseBankDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseContactsUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseContactsUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseContacts = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseContacts(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseGSTDetailsUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseGSTDetailsUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseGSTDetails = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseGSTDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthorisephotoUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthorisephotoUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authorisePhoto = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authorisePhoto(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseOptionUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseOptionUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseOption = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseOption(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseMappingUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseMappingUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseMapping = async (reqObj) => {
    try {
        if (reqObj.old_arn == '' || reqObj.old_arn == null || reqObj.new_arn == '' || reqObj.new_arn == null) {
            responseData.status = 422;
            responseData.message = "Please Check request Payload"
            responseData.data = [];
            responseData.id = 0;
            return responseData;
        }
        responseData.id = await offlineregisterService.authoriseMapping(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getNigoList = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getNigoList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

searchNigoDetails = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.searchNigoDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitNigoApplicationByFo = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.submitNigoApplicationByFo(reqObj);
        responseData.message = 'Application Submitted Successfully';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

offlineUpdatedataBo2Assign = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.offlineUpdatedataBo2Assign(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == false) {
            responseData.status = 500;
            responseData.message = "Same Person Canot do the Verification"
            responseData.id = 0;
        }
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseSelfdeclareUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseSelfdeclareUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseSignatureUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseSignatureUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseBasicDetailUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseBasicDetailUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseBankDetailsUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseBankDetailsUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseContactsUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseContactsUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseGstUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseGstUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthorisePhotoUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthorisePhotoUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseOptionUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseOptionUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseMappingUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseMappingUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getOfflineUpdateAuthoriseList = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getOfflineUpdateAuthoriseList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getNigoAuthorisationList = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getNigoAuthorisationList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

nigoBo1Assign = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.nigoBo1Assign(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.id = 0;
        responseData.data = [];
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

nigoBo2Assign = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.nigoBo2Assign(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == false) {
            responseData.status = 500;
            responseData.message = "Same Person Canot do the Verification"
            responseData.id = 0;
        }
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseRegisterRenewal = async (reqObj) => {
    try {
        await helperService.saveErrorAuditLogs(reqObj, '', 'AUTHCONTRL1')

        let data = await offlineregisterService.authoriseRegisterRenewal(reqObj);
        await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL2')

        if (data == null) {
            await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL3')
            responseData.status = 422;
            responseData.message = "Data Not Found"
            responseData.data = [];
            responseData.id = 0;
            return responseData;
        }
        let application_type = data['application_type'];
        let registration_type = data['registration_type'];
        let renewal_type = data['renewal_type'];

        if (renewal_type == 'REGISTRATION') {
            await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL4')
            if (application_type == 'ARN') {
                await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL5')

                if (registration_type == 'ONLINE') {
                    await offlineregisterService.submitForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL6')

                    await offlineregisterService.registrationActivate(reqObj)
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL7')

                }
                else if (registration_type == 'OFFLINE') {
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL8')

                    await offlineregisterService.submitForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL9')

                    //data push to recon ddno,dddate,uniquetransationn,panno
                    //paymentsts pan_no transaction date,payment

                    if (await reconService.reconApiImportData(reqObj.pan_no)) {
                        await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL10')

                        await offlineregisterService.registrationActivate(reqObj)

                    }

                }
            }
            else if (application_type == 'EUIN') {
                await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL11')

                if (registration_type == 'ONLINE') {
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL12')

                    await offlineregisterService.submitForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL13')

                    //not here
                }
                else if (registration_type == 'OFFLINE') {
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL14')

                    await offlineregisterService.submitForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL15')

                    if (await reconService.reconApiImportData(reqObj.pan_no)) {
                        await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL16')

                        await offlineregisterService.registrationActivate(reqObj)
                        await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL17')


                    }
                    // await offlineregisterService.registrationActivate(reqObj)

                }
            }

        }
        else if (renewal_type == 'RENEWAL') {
            await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL18')

            if (application_type == 'ARN') {
                await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL19')

                if (registration_type == 'ONLINE') {
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL20')

                    await offlineregisterService.submitForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL21')

                    await offlineregisterService.registrationActivate(reqObj)
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL22')


                }
                else if (registration_type == 'OFFLINE') {
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL23')

                    await offlineregisterService.submitForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL24')

                    await offlineregisterService.registrationActivate(reqObj)
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL25')


                }
            }
            else if (application_type == 'EUIN') {
                await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL26')

                if (registration_type == 'ONLINE') {
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL27')

                    await offlineregisterService.submitForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL28')

                    // await registrationActivate(reqObj)

                }
                else if (registration_type == 'OFFLINE') {
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL29')

                    await offlineregisterService.submitForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL30')

                    await offlineregisterService.registrationActivate(reqObj)
                    await helperService.saveErrorAuditLogs(reqObj, data, 'AUTHCONTRL31')


                }
            }
        }
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        responseData.data = reqObj;
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

rejectRegisterRenewal = async (reqObj) => {
    responseData.data = [];
    responseData.id = 0;
    try {
        responseData.id = await offlineregisterService.rejectRegisterRenewal(reqObj);
        responseData.message = 'Application Rejected Successfully.';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

rejectUpdates = async (reqObj) => {
    responseData.data = [];
    responseData.id = 0;
    try {
        responseData.id = await offlineregisterService.rejectUpdates(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

rejectRegisterRenewalToNigo = async (reqObj) => {
    try {
        if (reqObj.pan_no == '' || reqObj.pan_no == null || reqObj.pan_no == 'null' || reqObj.application_reference_no == '' || reqObj.application_reference_no == null || reqObj.application_reference_no == 'null') {
            responseData.message = 'Please Send all the required Data';
            responseData.status = 500;
            responseData.data = reqObj;
            return responseData;

        }
        else {
            responseData.id = await offlineregisterService.rejectRegisterRenewalToNigo(reqObj);
            responseData.data = reqObj;
            responseData.message = 'Success';
            responseData.status = 200;
        }

    }
    catch (ex) {
        responseData.id = 0;
        responseData.data = [];
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;

}

rejectUpdatesToNigo = async (reqObj) => {
    try {
        if (reqObj.pan_no == '' || reqObj.pan_no == null || reqObj.pan_no == 'null') {
            responseData.message = 'Please Send all the required Data';
            responseData.status = 500;
            responseData.data = reqObj;
            return responseData;

        }
        else {
            responseData.id = await offlineregisterService.rejectUpdatesToNigo(reqObj);
            responseData.data = reqObj;
            responseData.message = 'Success';
            responseData.status = 200;
        }

    }
    catch (ex) {
        responseData.id = 0;
        responseData.data = [];
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;

}

getNigoApplicantDetails = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getNigoApplicantDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitNigoForAuthorisation = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Authorise', 'AUTHORISE');
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseNigoApplication = async (reqObj) => {
    try {
        let data = await offlineregisterService.authoriseNigoApplication(reqObj);
        if (data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
            responseData.data = [];
            responseData.id = 0;
            return responseData;
        }
        if (data['nigoTypedata']['register_type'] == 'REGRENEWAL') {
            let application_type = data['dis_pendingdata']['application_type'];
            let registration_type = data['dis_pendingdata']['registration_type'];
            let renewal_type = data['dis_pendingdata']['renewal_type'];
            if (renewal_type == 'REGISTRATION') {
                if (application_type == 'ARN') {
                    if (registration_type == 'ONLINE') {
                        await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                        await offlineregisterService.registrationActivate(data['dis_pendingdata'])
                    }
                    else if (registration_type == 'OFFLINE') {
                        await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                        await offlineregisterService.registrationActivate(data['dis_pendingdata'])

                    }
                }
                else if (application_type == 'EUIN') {
                    if (registration_type == 'ONLINE') {
                        await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                        //not here
                    }
                    else if (registration_type == 'OFFLINE') {
                        await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                        await offlineregisterService.registrationActivate(data['dis_pendingdata'])

                    }
                }

            }
            else if (renewal_type == 'RENEWAL') {
                if (application_type == 'ARN') {
                    if (registration_type == 'ONLINE') {
                        await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                        await offlineregisterService.registrationActivate(data['dis_pendingdata'])

                    }
                    else if (registration_type == 'OFFLINE') {
                        await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                        await offlineregisterService.registrationActivate(data['dis_pendingdata'])

                    }
                }
                else if (application_type == 'EUIN') {
                    if (registration_type == 'ONLINE') {
                        await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                        // await registrationActivate(reqObj)

                    }
                    else if (registration_type == 'OFFLINE') {
                        await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Completed', 'COMPLETED');
                        await offlineregisterService.registrationActivate(data['dis_pendingdata'])

                    }
                }
            }
        }
        else {
            await offlineregisterService.submitNigoForAuthorisation(reqObj, 'Completed', 'COMPLETED');
            await offlineregisterService.updateNigoApproved(reqObj, 'Completed', 'COMPLETED')

        }
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        responseData.id = reqObj.application_reference_no;

    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

searchDetailsByPanNoForNigo = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.searchDetailsByPanNoForNigo(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

cancelAssignedRegisration = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.cancelAssignedRegisration(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

cancelAssignedUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.cancelAssignedUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

cancelAssignedNigo = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.cancelAssignedNigo(reqObj, 'Authorise', 'AUTHORISE');
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseDuplicateCardUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseDuplicateCardUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseDupCardUpdated = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseDupCardUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseDupCardUpdated = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseDupCardUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
getCardPrintingList = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getCardPrintingList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

payForIssueDuplicate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.payForIssueDuplicate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getCardIssueStatus = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.getCardIssueStatus(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

logoutFOBO = async (reqObj) => {
    responseData.data = [];
    responseData.id = 0;
    try {
        responseData.id = await offlineregisterService.logoutFOBO(reqObj);
        responseData.message = 'Logout Success';
        responseData.status = 200;
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        responseData.data = reqObj;
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseSignatoryUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseSignatoryUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseSignatoryUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseSignatoryUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseSignatory = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseSignatory(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAuthoriseCategoryUpdated = async (reqObj) => {
    try {
        responseData.data = await offlineregisterService.getAuthoriseCategoryUpdated(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

submitForAuthoriseCategoryUpdate = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.submitForAuthoriseCategoryUpdate(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

authoriseCategory = async (reqObj) => {
    try {
        responseData.id = await offlineregisterService.authoriseCategory(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];
        if (responseData.id == null) {
            responseData.status = 422;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
module.exports = {
    getState,
    saveOfflineRegister,
    getDocumentCheckListByType,
    loginFO,
    getOfflineRegisterDataById,
    submitOfflineRegister,
    getAllARNList,
    updatePriority,
    updateFo1Assign,
    getOfflineApplicantDatasById,
    submitForAuthorisation,
    updateFo2Assign,
    getUploadedDocumentById,
    loginBO,
    getAuthorisationList,
    saveOfflineRenewal,
    searchByArnNoApproved,
    searchByEUINNoApproved,
    loginFOBO,
    getRequestTypes,
    saveRequestedUpdate,
    getRejectReason,
    getGender,
    getOfflineUpdateById,
    submitOfflineUpdate,
    getOfflineUpdateQueueList,
    offlineUpdatedataBoAssign,
    getFinancialYear,
    getAuthoriseSelfDeclareUpdated,
    authoriseSelfDeclaration,
    getAuthoriseSignatureUpdated,
    authoriseSignature,
    getAuthoriseBasicDetailsUpdated,
    authoriseBasicDetails,
    getAuthoriseBankDetailsUpdated,
    authoriseBankDetails,
    getAuthoriseContactsUpdated,
    authoriseContacts,
    getAuthoriseGSTDetailsUpdated,
    authoriseGSTDetails,
    getAuthorisephotoUpdated,
    authorisePhoto,
    getAuthoriseOptionUpdated,
    authoriseOption,
    getAuthoriseMappingUpdated,
    authoriseMapping,
    rejectRegisterRenewalToNigo,
    getNigoList,
    searchNigoDetails,
    submitNigoApplicationByFo,
    offlineUpdatedataBo2Assign,
    submitForAuthoriseSignatureUpdate,
    submitForAuthoriseBasicDetailUpdate,
    submitForAuthoriseBankDetailsUpdate,
    submitForAuthoriseContactsUpdate,
    submitForAuthoriseGstUpdate,
    submitForAuthorisePhotoUpdate,
    submitForAuthoriseOptionUpdate,
    submitForAuthoriseMappingUpdate,
    getOfflineUpdateAuthoriseList,
    submitForAuthoriseSelfdeclareUpdate,
    getNigoAuthorisationList,
    nigoBo1Assign,
    nigoBo2Assign,
    authoriseRegisterRenewal,
    rejectRegisterRenewal,
    rejectUpdates,
    rejectUpdatesToNigo,
    getNigoApplicantDetails,
    submitNigoForAuthorisation,
    authoriseNigoApplication,
    searchDetailsByPanNoForNigo,
    cancelAssignedRegisration,
    cancelAssignedUpdate,
    cancelAssignedNigo,
    getAuthoriseDuplicateCardUpdated,
    submitForAuthoriseDupCardUpdated,
    authoriseDupCardUpdated,
    getCardPrintingList,
    payForIssueDuplicate,
    getCardIssueStatus,
    getCardIssueStatus,
    logoutFOBO,
    getAuthoriseSignatoryUpdated,
    submitForAuthoriseSignatoryUpdate,
    authoriseSignatory,
    getAuthoriseCategoryUpdated,
    submitForAuthoriseCategoryUpdate,
    authoriseCategory
}