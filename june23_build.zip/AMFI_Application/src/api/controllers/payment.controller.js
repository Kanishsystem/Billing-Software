const paymentService = require('../services/payment.service')
let responseData = require('../models/responsemodel')


createOnlinePayment = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await paymentService.createOnlinePayment(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

saveOnlinePaymentTransaction = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await paymentService.saveOnlinePaymentTransaction(reqObj);
        responseData.id = 0;
        if (responseData.data.auth_status == '0300') {
            responseData.message = 'Success';
            responseData.status = 200;
        }
        else if (responseData.data.auth_status == '0002') {
            responseData.message = 'Pending';
            responseData.status = 201;
        }
        else {
            responseData.message = 'Failed';
            responseData.status = 201;
        }

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

billdeskCallbackTxnStatusUpdate = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await paymentService.billdeskCallbackTxnStatusUpdate();
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}


module.exports = {
    createOnlinePayment,
    saveOnlinePaymentTransaction,
    billdeskCallbackTxnStatusUpdate
}