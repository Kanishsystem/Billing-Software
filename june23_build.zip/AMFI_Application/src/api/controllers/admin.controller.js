const adminService = require('../services/admin.service');
let responseData = require('../models/responsemodel');


searchByAdmin = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await adminService.searchByAdmin(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAdmintProfileSummaryById = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await adminService.getAdmintProfileSummaryById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAdminActiveBankDetailsById = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await adminService.getAdminActiveBankDetailsById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAdminGSTInfoById = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await adminService.getAdminGSTInfoById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAdminProfilePictureById = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await adminService.getAdminProfilePictureById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getUpdatesHistory = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await adminService.getUpdatesHistory(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getRegRenHistory = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await adminService.getRegRenHistory(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getMappingHistory = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await adminService.getMappingHistory(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getDeMappingHistory = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await adminService.getDeMappingHistory(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getViewAllEUINAdmin = async (reqObj) => {
    try {
        responseData.data = await adminService.getViewAllEUINAdmin(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data.length == 0) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getMappingEUINListAdmin = async (reqObj) => {
    try {
        responseData.data = await adminService.getMappingEUINListAdmin(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getDeMappingEUINListAdmin = async (reqObj) => {
    try {
        responseData.data = await adminService.getDeMappingEUINListAdmin(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getRegisterRenewalEUINAdmin = async (reqObj) => {
    try {
        responseData.data = await adminService.getRegisterRenewalEUINAdmin(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getProductCategoriesOptionAdmin = async (reqObj) => {
    try {
        responseData.data = await adminService.getProductCategoriesOptionAdmin(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getIssueDuplicateReqStatus = async (reqObj) => {
    try {
        responseData.data = await adminService.getIssueDuplicateReqStatus(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

searchByNismPan = async (reqObj) => {
    try {
        responseData.data = await adminService.searchByNismPan(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getInvalidType = async (reqObj) => {
    try {
        responseData.data = await adminService.getInvalidType(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getInvalidAuthority = async (reqObj) => {
    try {
        responseData.data = await adminService.getInvalidAuthority(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

saveInvalidDetails = async (reqObj) => {
    try {
        responseData.id = await adminService.saveInvalidDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = reqObj;
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
module.exports = {
    searchByAdmin,
    getAdmintProfileSummaryById,
    getAdminActiveBankDetailsById,
    getAdminGSTInfoById,
    getAdminProfilePictureById,
    getUpdatesHistory,
    getRegRenHistory,
    getMappingHistory,
    getDeMappingHistory,
    getViewAllEUINAdmin,
    getMappingEUINListAdmin,
    getDeMappingEUINListAdmin,
    getRegisterRenewalEUINAdmin,
    getProductCategoriesOptionAdmin,
    getIssueDuplicateReqStatus,
    searchByNismPan,
    getInvalidType,
    getInvalidAuthority,
    saveInvalidDetails
}
