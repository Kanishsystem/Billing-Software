const registrationService = require('../services/registration.service')
const encryptionDecryption = require('../../common/encrypt_decrypt')
let responseData = require('../models/responsemodel')
const moment = require("moment");
const req = require('express/lib/request');
let authservice = require('../../common/auth');
const emailService = require('../services/email.service');
const smsService = require('../services/sms.service');

getDistributerPendingDataById = async (reqObj) => {
    try {
        responseData.data = await registrationService.getDistributerPendingDataById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getARNCategoryDropdwn = async () => {
    responseData.data = [];
    responseData.id = 0;
    try {
        responseData.data = await registrationService.getARNCategoryDropdwn();
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

saveRegisterOnAMFI = async (reqObj) => {

    try {
        responseData.data = [];
        responseData.id = 0;

        if (reqObj.application_type == '' || reqObj.pan_no == '') {
            responseData.message = 'Please Enter all the required Data';
            responseData.status = 500;
            return responseData;
        }


        if (await registrationService.checkInvalidDetails(reqObj)) {
            responseData.message = 'PAN Number is Invalid';
            responseData.status = 500;
            return responseData;
        }

        if (reqObj.category_of_corporation != 'COR') {
            if (reqObj.application_type == 'ARN') {
                //verification pan 4th Character in pending table
                if (await registrationService.pan4thcharacter(reqObj.pan_no)) {
                    responseData.message = 'Entered PAN cannot be registered for category : “Selected Category”. Click here to see why!';
                    responseData.status = 500;
                    return responseData;
                }
            }
            // verification pan no in Nism table
            if (await registrationService.panExistsInNism(reqObj.pan_no)) {
                responseData.message = 'Pan no does not exist in nism';
                responseData.status = 500;
                return responseData;
            }

            if (await registrationService.panExpireInNism(reqObj.pan_no)) {
                responseData.message = 'For the entered PAN, your NISM certificate has expired. Please ensure your NISM certificate is valid before submitting the request';
                responseData.status = 500;
                return responseData;
            }
        }


        // verification pan no in pending table
        if (await registrationService.panExistsInPending(reqObj.pan_no)) {
            responseData.message = 'Requested PAN is already registered and Pending';
            responseData.status = 500;
            return responseData;
        }
        // verification pan no in activated table
        if (await registrationService.panExistsInActivated(reqObj.pan_no)) {
            responseData.message = 'Requested PAN is already registered and active';
            responseData.status = 500;
            return responseData;
        }

        // verification email Id in pending table
        // if (await registrationService.emailExistsInPending(reqObj.email_id)) {
        //     responseData.message = 'Email id is already used in an Pending account';
        //     responseData.status = 500;
        //     return responseData;
        // }
        // verification email Id in activated table
        // if (await registrationService.emailExistsInActivated(reqObj.email_id)) {
        //     responseData.message = 'Email id is already used in an activated account';
        //     responseData.status = 500;
        //     return responseData;
        // }


        // verification mobile no in pending table
        // if (await registrationService.mobileNoExistsInPending(reqObj.mobile_no)) {
        //     responseData.message = 'Mobile No is already used in an Pending account';
        //     responseData.status = 500;
        //     return responseData;
        // }
        // verification mobile no in activated table
        // if (await registrationService.mobileNoExistsInActivated(reqObj.mobile_no)) {
        //     responseData.message = 'Mobile No is already used in an activated account';
        //     responseData.status = 500;
        //     return responseData;
        // }
        responseData.id = await registrationService.saveRegisterOnAMFI(reqObj);

        // await registrationService.sendOtp(reqObj);
        await emailService.sendOtpEmailRegister(reqObj.pan_no, reqObj.email_id, reqObj.application_type);
        await smsService.sendOtpMobileRegistration(reqObj.pan_no, reqObj.mobile_no);
        responseData.data = reqObj;
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;

}

updatePersonalDetails = async (reqObj) => {
    try {
        responseData.id = await registrationService.updatePersonalDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateCertificationDetails = async (reqObj) => {
    try {
        responseData.id = await registrationService.updateCertificationDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
updateBankDetails = async (reqObj) => {
    try {
        responseData.id = await registrationService.updateBankDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}


updateDocuments = async (reqObj) => {
    try {
        responseData.id = await registrationService.updateDocuments(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}


verifyMobileNoOtp = async (reqObj) => {
    try {
        if (await registrationService.verifyMobileNoOtp(reqObj)) {
            responseData.message = 'Success'
            responseData.status = 200;
        }
        else {
            responseData.message = "InValid Mobile OTP"
            responseData.status = 500;
        }
        responseData.data = []
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

verifyEmailOtp = async (reqObj) => {
    try {
        if (await registrationService.verifyEmailOtp(reqObj)) {
            responseData.message = 'Success'
            responseData.status = 200;
        }
        else {
            responseData.message = "InValid Email OTP"
            responseData.status = 500;
        }
        responseData.data = []
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
getDetailsByPincode = async (reqObj) => {
    try {
        responseData.data = await registrationService.getDetailsByPincode(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getBankDetailsByIFSCcode = async (reqObj) => {
    try {
        responseData.data = await registrationService.getBankDetailsByIFSCcode(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getPersonalDetailsById = async (reqObj) => {
    try {
        responseData.data = await registrationService.getPersonalDetailsById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getCertificationDetailsById = async (reqObj) => {
    try {
        responseData.data = await registrationService.getCertificationDetailsById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getBankDetailsById = async (reqObj) => {
    try {
        responseData.data = await registrationService.getBankDetailsById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

resendMobileOtp = async (reqObj) => {
    try {
        let res = await registrationService.resendMobileOtp(reqObj);
        responseData.message = 'OTP Resent Succesfully';
        responseData.status = 200;
        responseData.data = []
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

resendEmailOtp = async (reqObj) => {
    try {
        await registrationService.resendEmailOtp(reqObj);
        responseData.message = 'OTP Resent Succesfully';
        responseData.status = 200;
        responseData.data = []
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateRegistrationType = async (reqObj) => {
    try {
        responseData.id = await registrationService.updateRegistrationType(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateCompanyDetails = async (reqObj) => {
    try {
        responseData.id = await registrationService.updateCompanyDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getCompanyDetailsById = async (reqObj) => {
    try {
        responseData.data = await registrationService.getCompanyDetailsById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getDetailsByARNId = async (reqObj) => {
    try {
        responseData.data = await registrationService.getDetailsByARNId(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

registrationActivate = async (reqObj) => {
    try {
        responseData.data = await registrationService.registrationActivate(reqObj);
        responseData.id = reqObj.id;
        responseData.message = 'Success';
        responseData.status = 200;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getDocumentsById = async (reqObj) => {
    try {
        responseData.data = await registrationService.getDocumentsById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null || Object.values(responseData.data).length == 0) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
loginARNEUIN = async (reqObj) => {
    let responseobj = {}
    const { user_name, password, systemCode } = reqObj;

    if (!(user_name && password && systemCode)) {
        responseData.data = reqObj;
        responseData.id = 0
        responseData.status = 400;
        responseData.message = "All input is required"
        return responseData;
    }
    try {
        let session_flag = await registrationService.getUserSession(reqObj)
        responseobj.activeSessionStatus = session_flag;
        if (session_flag) {
            responseobj.data = reqObj;
            responseobj.status = 200;
            responseobj.message = "Session already Active";
            return responseobj;
        }

        if (await registrationService.checkInvalidDetailsForLogin(reqObj)) {
            responseData.message = 'Invalid User';
            responseData.status = 500;
            return responseData;
        }

        responseobj.data = await registrationService.loginARNEUIN(reqObj);
        responseobj.message = 'login Success';
        responseobj.status = 200;
        if (responseobj.data == null) {
            responseobj.data = reqObj;
            responseobj.status = 201;
            responseobj.message = "login failed"
        }
        else {
            responseobj.id = responseobj.data.user_id;
            responseobj.token = await authservice.generateAuthToken(responseobj.data.user_id, responseobj.data.user_name, responseobj.data.pan_no);
            await registrationService.updateARNEUINtoken(responseobj.data.user_id, responseobj.data.user_name, responseobj.data.pan_no, responseobj.token)

        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseobj.message = msg;
        responseobj.status = 500;
    }
    return responseobj;
}

resumeByPanNo = async (reqObj) => {
    try {
        let data = await registrationService.getdataByPanNo(reqObj);
        responseData.data = [];
        if (data != null) {
            reqObj.mobile_no = data['dis_res'][0]['mobile_no'];
            reqObj.email_id = data['dis_res'][0]['email_id'];
            responseData.data = data['dis_res'][0]
            if (data['cop_res'].length > 0) {
                let current_date = moment().format('YYYY-MM-DD');
                let created_Date = moment(data['dis_res'][0]['created_date']).format('YYYY-MM-DD');
                let current_time_obj = new Date(current_date).getTime();
                let created_time_obj = new Date(created_Date).getTime();
                let diff_millisecs = current_time_obj - created_time_obj;
                let value = diff_millisecs / 86400000;
                if (value <= data['cop_res'][0]['reg_req_resume_days']) {
                    // await registrationService.sendOtp(reqObj);
                    await emailService.sendOtpEmailResume(reqObj.pan_no, reqObj.email_id);
                    await smsService.sendOtpMobileResume(reqObj.pan_no, reqObj.mobile_no);
                    responseData.message = 'OTP Sent Successfully';
                    responseData.status = 200;
                    responseData.id = data['dis_res'][0]['id'];
                }
                else {
                    await registrationService.deleteAfterResumeDays(data['dis_res'][0]['id'])
                    responseData.message = "PAN No entered do not match with AMFI records, kindly enter correct details to resume"
                    responseData.status = 201;
                    responseData.id = 0;
                }
            }
            else {
                await emailService.sendOtpEmailResume(reqObj.pan_no, reqObj.email_id);
                await smsService.sendOtpMobileResume(reqObj.pan_no, reqObj.mobile_no);
                // await registrationService.sendOtp(reqObj);
                responseData.message = 'OTP Sent Successfully';
                responseData.status = 200;
                responseData.id = data['dis_res'][0]['id'];
            }
        }
        else {
            responseData.status = 201;
            responseData.message = "PAN No entered do not match with AMFI records, kindly enter correct details to resume"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getAccountTypeById = async (reqObj) => {
    try {
        responseData.data = await registrationService.getAccountTypeById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getPaymentAmountById = async (reqObj) => {
    try {
        responseData.data = await registrationService.getPaymentAmountById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getDeclarationById = async (reqObj) => {
    try {
        responseData.data = await registrationService.getDeclarationById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getFilebase64ByID = async (reqObj) => {
    try {
        responseData.data = await registrationService.getFilebase64ByID(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = reqObj.id;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getDropDownData = async (reqObj) => {
    try {
        responseData.data = await registrationService.getDropDownData(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

verifyOtp = async (reqObj) => {
    try {
        let count = await registrationService.getNoOfAttemptCount(reqObj);
        if (count == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        else if (count >= 3) {
            responseData.status = 500;
            responseData.message = "Exceeds Maximum Attempts"
        }
        else {
            if (await registrationService.verifyOtp(reqObj)) {
                responseData.message = 'Success'
                responseData.status = 200;
            }
            else {
                responseData.message = "InValid OTP"
                responseData.status = 500;
            }
        }

        responseData.data = []
        responseData.id = 0;

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

forgotUserId = async (reqObj) => {
    try {
        responseData.id = await registrationService.forgotUserId(reqObj);
        responseData.message = 'User Id Sent in Email Succesfully';
        responseData.status = 200;
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        responseData.data = []

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

forgotPasswordSendOtp = async (reqObj) => {
    try {
        let res = await registrationService.forgotPasswordSendOtp(reqObj);
        responseData.message = 'OTP sent Succesfully';
        responseData.status = 200;
        if (res == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        reqObj.pan_no = res;
        responseData.data = reqObj;
        responseData.id = 0;
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

forgotPasswordVerifyOtp = async (reqObj) => {
    try {
        if (await registrationService.forgotPasswordVerifyOtp(reqObj)) {
            responseData.message = 'Success'
            responseData.status = 200;
        }
        else {
            responseData.message = "InValid OTP"
            responseData.status = 500;
        }
        responseData.data = []
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

changePassword = async (reqObj) => {
    try {
        responseData.id = await registrationService.changePassword(reqObj);
        responseData.message = 'Password Changed Succesfully';
        responseData.status = 200;
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        responseData.data = []

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
updateRegistrationReview = async (reqObj) => {
    try {
        let res = await registrationService.updateRegistrationReview(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        if (res == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        reqObj.registration_type = res;
        responseData.data = reqObj;
        responseData.id = 0;
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updatePayment = async (reqObj) => {
    responseData.data = [];
    responseData.id = 0;
    try {
        responseData.id = await registrationService.updatePayment(reqObj);
        responseData.message = "We have received your application number" + " " + responseData.id.application_reference_no + " " + "You will receive a confirmation of the same in your registered email and mobile number";
        responseData.status = 200;
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        responseData.data = reqObj;
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

logoutARNEUIN = async (reqObj) => {
    responseData.data = [];
    responseData.id = 0;
    try {
        responseData.id = await registrationService.logoutARNEUIN(reqObj);
        responseData.message = 'Logout Success';
        responseData.status = 200;
        if (responseData.id == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        responseData.data = reqObj;
    }
    catch (ex) {
        responseData.data = [];
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
module.exports = {
    getDistributerPendingDataById,
    getARNCategoryDropdwn,
    saveRegisterOnAMFI,
    updatePersonalDetails,
    updateCertificationDetails,
    updateBankDetails,
    updateDocuments,
    verifyMobileNoOtp,
    verifyEmailOtp,
    getDetailsByPincode,
    getBankDetailsByIFSCcode,
    getPersonalDetailsById,
    getCertificationDetailsById,
    getBankDetailsById,
    resendMobileOtp,
    resendEmailOtp,
    updateRegistrationType,
    updateCompanyDetails,
    getCompanyDetailsById,
    getDetailsByARNId,
    registrationActivate,
    getDocumentsById,
    loginARNEUIN,
    resumeByPanNo,
    getAccountTypeById,
    getPaymentAmountById,
    getDeclarationById,
    getFilebase64ByID,
    getDropDownData,
    verifyOtp,
    forgotUserId,
    forgotPasswordSendOtp,
    forgotPasswordVerifyOtp,
    changePassword,
    updateRegistrationReview,
    updatePayment,
    logoutARNEUIN
};
