let responseData = require('../models/responsemodel')
let helperService = require('../services/helper.service')


upload_file = async (reqObj) => {
    try {
        responseData.id = await helperService.upload_file(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

test_file = async () => {
    try {
        responseData.id = await helperService.test_file();
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

module.exports = {
    upload_file,
    test_file
}