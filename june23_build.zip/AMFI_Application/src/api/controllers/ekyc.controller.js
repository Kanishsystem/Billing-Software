const ekycService = require('../services/ekyc.service')
let responseData = require('../models/responsemodel')


verifyAadhar = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await ekycService.verifyAadhar(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

saveAadharResponse = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        let decryptedData = await ekycService.getEncryptedResult(reqObj.result);
        responseData.id = 0;
        responseData.data = decryptedData;
        let resArray = decryptedData.split('|');
        if (resArray != null && resArray.length > 0) {
            if (resArray[0] == 'Y') {
                if ('MFKYC' in reqObj) {
                    await ekycService.saveMfkycData(reqObj.MFKYC)
                }
                responseData.message = 'Success';
                responseData.status = 200;
            }
            else {
                if (resArray.length >= 3) {
                    responseData.message = resArray[3];
                }
                else {
                    responseData.message = 'Error';
                }
                responseData.status = 201;
            }
        }

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateEkycFiles = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await ekycService.updateEkycFiles1(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

module.exports = {
    verifyAadhar,
    saveAadharResponse,
    updateEkycFiles
}