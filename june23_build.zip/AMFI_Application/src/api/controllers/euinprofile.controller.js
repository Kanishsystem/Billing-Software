const euinProfileService = require('../services/euinprofile.service')
let responseData = require('../models/responsemodel')
let registrationService = require('../services/registration.service')
let offlineregisterService = require('../services/offlineregister.service');

getEUINProfileSummary = async (reqObj) => {
    try {
        responseData.data = await euinProfileService.getEUINProfileSummary(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        else {
            responseData['data'][0]['isSentForUpdate'] = await offlineregisterService.isChangeRequestExists(responseData['data'][0]['pan_no'], 'BD')
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getARNDetailsByEUINId = async (reqObj) => {
    try {
        responseData.data = await euinProfileService.getARNDetailsByEUINId(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updatNewEmployerForEUIN = async (reqObj) => {
    try {
        if (reqObj.old_arn == '' || reqObj.old_arn == null || reqObj.new_arn == '' || reqObj.new_arn == null) {
            responseData.status = 201;
            responseData.message = "Please Check request Payload"
            responseData.data = [];
            responseData.id = 0;
            return responseData;
        }
        responseData.id = await euinProfileService.updatNewEmployerForEUIN(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

sentForRenewalByEUINId = async (reqObj) => {
    try {
        if (reqObj.pan_no == '' || reqObj.pan_no == null || reqObj.euin_number == '' || reqObj.euin_number == null) {
            responseData.message = 'Please Enter all the required Data';
            responseData.status = 500;
            return responseData;
        }
        if (await registrationService.checkInvalidDetails(reqObj)) {
            responseData.message = 'PAN Number is Invalid';
            responseData.status = 500;
            return responseData;
        }
        if (!await registrationService.euinExistsInActivated(reqObj.euin_number)) {
            responseData.message = 'EUIN number is not Active';
            responseData.status = 500;
            return responseData;
        }

        // verification pan no in Nism table
        // if (await registrationService.panExistsInNism(reqObj.pan_no)) {
        //     responseData.message = 'Pan no does not exist in nism';
        //     responseData.status = 500;
        //     return responseData;
        // }

        // if (await registrationService.panExpireInNism(reqObj.pan_no)) {
        //     responseData.message = 'For the entered PAN, your NISM certificate has expired. Please ensure your NISM certificate is valid before submitting the request';
        //     responseData.status = 500;
        //     return responseData;
        // }


        if (await registrationService.checkNismCertificateDate(reqObj.pan_no)) {
            responseData.message = "Please update the latest NISM details to proceed";
            responseData.status = 500;
            return responseData;
        }
        // verification pan no in pending table
        if (await registrationService.panExistsInPending(reqObj.pan_no)) {
            responseData.message = 'Requested PAN is already renewed and Pending';
            responseData.status = 500;
            return responseData;
        }
        // verification pan no in activated table
        if (!await registrationService.panExistsInActivated(reqObj.pan_no)) {
            responseData.message = 'Requested PAN Does Not registered and active';
            responseData.status = 500;
            return responseData;
        }

        let validres = await registrationService.checkandGetValidFromandToDate(reqObj)
        if (validres == null) {
            responseData.message = 'Please register an EUIN who is having a valid ARN validity to proceed further';
            responseData.status = 500;
            return responseData;
        }
        else {
            reqObj['validity_from'] = validres.validity_from;
            reqObj['validity_to'] = validres.validity_to;

        }
        let res = await euinProfileService.sentForRenewalByEUINId(reqObj);
        responseData.id = res.id;
        reqObj['application_reference_no'] = res.application_reference_no;
        responseData.data = reqObj;
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
module.exports = {
    getEUINProfileSummary,
    getARNDetailsByEUINId,
    updatNewEmployerForEUIN,
    sentForRenewalByEUINId
}