const arnProfileService = require('../services/arnprofile.service');
let responseData = require('../models/responsemodel');
let offlineregisterService = require('../services/offlineregister.service');
let euinProfileService = require('../services/euinprofile.service');

getProfileSummaryById = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await arnProfileService.getProfileSummaryById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

        if (responseData.data == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        else {
            responseData['data'][0]['isSentForUpdate'] = await offlineregisterService.isChangeRequestExists(responseData['data'][0]['pan_no'], 'BD')
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getActiveBankDetailsById = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await arnProfileService.getActiveBankDetailsById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        else {
            responseData['data'][0]['isSentForUpdate'] = await offlineregisterService.isChangeRequestExists(responseData['data'][0]['pan_no'], 'BANK')
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getGSTInfoById = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await arnProfileService.getGSTInfoById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
        else {
            responseData['data'][0]['isSentForUpdate'] = await offlineregisterService.isChangeRequestExists(responseData['data'][0]['pan_no'], 'GST')
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getProfilePictureById = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.data = await arnProfileService.getProfilePictureById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}



updateActiveProfileAddress = async (reqObj) => {
    try {
        let already_reqexists = await offlineregisterService.isChangeRequestExists(reqObj.pan_no, 'BD');
        if (already_reqexists) {
            responseData.id = 0;
            responseData.data = [];
            responseData.message = 'Request Already Exists';
            responseData.status = 201;
            return responseData;

        }
        responseData.id = await arnProfileService.updateActiveProfileAddress(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateActiveBankDetails = async (reqObj) => {
    try {
        let already_reqexists = await offlineregisterService.isChangeRequestExists(reqObj.pan_no, 'BANK');
        if (already_reqexists) {
            responseData.id = 0;
            responseData.data = [];
            responseData.message = 'Request Already Exists';
            responseData.status = 201;
            return responseData;

        }
        responseData.id = await arnProfileService.updateActiveBankDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateGSTInfo = async (reqObj) => {
    try {
        if (reqObj.pan_no == '' || reqObj.pan_no == null) {
            responseData.id = 0;
            responseData.data = [];
            responseData.message = 'Invalid Payload';
            responseData.status = 201;
            return responseData;
        }
        let already_reqexists = await offlineregisterService.isChangeRequestExists(reqObj.pan_no, 'GST');
        if (already_reqexists) {
            responseData.id = 0;
            responseData.data = [];
            responseData.message = 'Request Already Exists';
            responseData.status = 201;
            return responseData;
        }
        responseData.id = await arnProfileService.updateGSTInfo(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateProfilePicture = async (reqObj) => {
    try {
        responseData.id = await arnProfileService.updateProfilePicture(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = []

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getARNRenewal = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.getARNRenewal(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

sendMobileNoChangeOtpForProfile = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.sendMobileNoChangeOtpForProfile(reqObj);
        responseData.message = 'OTP Sent Successfully';
        responseData.status = 200;
        responseData.id = 0;
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

sendEmailChangeOtpForProfile = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.sendEmailChangeOtpForProfile(reqObj);
        responseData.message = 'OTP Sent Successfully';
        responseData.status = 200;
        responseData.id = 0;
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

resendEmailChangeOtpForProfile = async (reqObj) => {
    try {
        await arnProfileService.resendEmailChangeOtpForProfile(reqObj);
        responseData.message = 'OTP Resent Succesfully';
        responseData.status = 200;
        responseData.data = []
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

resendMobileNoChangeOtpForProfile = async (reqObj) => {
    try {
        await arnProfileService.resendMobileNoChangeOtpForProfile(reqObj);
        responseData.message = 'OTP Resent Succesfully';
        responseData.status = 200;
        responseData.data = []
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

verifyEmailAndUpdateEMail = async (reqObj) => {
    try {
        if (await arnProfileService.verifyEmailAndUpdateEMail(reqObj)) {
            responseData.message = 'Success'
            responseData.status = 200;
        }
        else {
            responseData.message = "InValid Email OTP"
            responseData.status = 500;
        }
        responseData.data = []
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

VerifyMobileAndUpdateMobile = async (reqObj) => {
    try {
        if (await arnProfileService.VerifyMobileAndUpdateMobile(reqObj)) {
            responseData.message = 'Success'
            responseData.status = 200;
        }
        else {
            responseData.message = "InValid Mobile OTP"
            responseData.status = 500;
        }
        responseData.data = []
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getMappingEUINList = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.getMappingEUINList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getDeMappingEUINList = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.getDeMappingEUINList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getViewAllEUIN = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.getViewAllEUIN(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data.length == 0) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getEUINRenewalList = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.getEUINRenewalList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getRegistrationPaymentList = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.getRegistrationPaymentList(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getProductCategoriesOption = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.getProductCategoriesOption(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

saveProductCategoriesOption = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.id = await arnProfileService.saveProductCategoriesOption(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
viewMappingEUINApplicationById = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.viewMappingEUINApplicationById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

removeDeMappingEUIN = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.removeDeMappingEUIN(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

approveMappingEUIN = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.approveMappingEUIN(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getARNRenewalDetailsById = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.getARNRenewalDetailsById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;
        if (responseData.data == null) {
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}
rejectMappingById = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.rejectMappingById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

rejectDeMappingById = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.rejectDeMappingById(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

getselfDeclarationByCode = async (reqObj) => {
    try {
        responseData.data = await arnProfileService.getselfDeclarationByCode(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.id = 0;

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

verifyEmailAndsubmitDeclaration = async (reqObj) => {
    try {
        if (await arnProfileService.verifyEmailAndsubmitDeclaration(reqObj)) {
            responseData.message = 'Success'
            responseData.status = 200;
        }
        else {
            responseData.message = "InValid  OTP"
            responseData.status = 500;
        }
        responseData.data = []
        responseData.id = 0;

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

verifyMobileAndsubmitDeclaration = async (reqObj) => {
    try {
        if (await arnProfileService.verifyMobileAndsubmitDeclaration(reqObj)) {
            responseData.message = 'Success'
            responseData.status = 200;
        }
        else {
            responseData.message = "InValid  OTP"
            responseData.status = 500;
        }
        responseData.data = []
        responseData.id = 0;

    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

sentForRenewalByARNId = async (reqObj) => {
    try {
        if (reqObj.pan_no == '' || reqObj.pan_no == null || reqObj.arn_number == '' || reqObj.arn_number == null) {
            responseData.message = 'Please Enter all the required Data';
            responseData.status = 500;
            return responseData;
        }

        if (await registrationService.checkInvalidDetails(reqObj)) {
            responseData.message = 'PAN Number is Invalid';
            responseData.status = 500;
            return responseData;
        }
        // if (!await registrationService.euinExistsInActivated(reqObj.euin_number)) {
        //     responseData.message = 'EUIN number is not Active';
        //     responseData.status = 500;
        //     return responseData;
        // }

        // verification pan no in Nism table
        // if (await registrationService.panExistsInNism(reqObj.pan_no)) {
        //     responseData.message = 'Pan no does not exist in nism';
        //     responseData.status = 500;
        //     return responseData;
        // }

        // if (await registrationService.panExpireInNism(reqObj.pan_no)) {
        //     responseData.message = 'For the entered PAN, your NISM certificate has expired. Please ensure your NISM certificate is valid before submitting the request';
        //     responseData.status = 500;
        //     return responseData;
        // }

        if (await registrationService.checkNismCertificateDate(reqObj.pan_no)) {
            responseData.message = "Please update the latest NISM details to proceed";
            responseData.status = 500;
            return responseData;
        }
        // verification pan no in pending table
        if (await registrationService.panExistsInPending(reqObj.pan_no)) {
            responseData.message = 'Requested PAN is already renewed and Pending';
            responseData.status = 500;
            return responseData;
        }
        // verification pan no in activated table
        if (!await registrationService.panExistsInActivated(reqObj.pan_no)) {
            responseData.message = 'Requested PAN Does Not registered and active';
            responseData.status = 500;
            return responseData;
        }

        let validres = await registrationService.checkandGetValidFromandToDate(reqObj)
        if (validres == null) {
            responseData.message = 'Please register an EUIN who is having a valid ARN validity to proceed further';
            responseData.status = 500;
            return responseData;
        }
        else {
            reqObj['validity_from'] = validres.validity_from;
            reqObj['validity_to'] = validres.validity_to;

        }
        let res = await euinProfileService.sentForRenewalByEUINId(reqObj);
        responseData.id = res.id;
        reqObj['application_reference_no'] = res.application_reference_no;
        responseData.data = reqObj;
        responseData.message = 'Success';
        responseData.status = 200;
    }
    catch (ex) {
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

module.exports = {
    getProfileSummaryById,
    getActiveBankDetailsById,
    getGSTInfoById,
    getProfilePictureById,
    updateActiveProfileAddress,
    updateActiveBankDetails,
    updateGSTInfo,
    updateProfilePicture,
    getARNRenewal,
    sendMobileNoChangeOtpForProfile,
    sendEmailChangeOtpForProfile,
    resendEmailChangeOtpForProfile,
    resendMobileNoChangeOtpForProfile,
    verifyEmailAndUpdateEMail,
    VerifyMobileAndUpdateMobile,
    getMappingEUINList,
    getDeMappingEUINList,
    getViewAllEUIN,
    getEUINRenewalList,
    getRegistrationPaymentList,
    getProductCategoriesOption,
    saveProductCategoriesOption,
    viewMappingEUINApplicationById,
    removeDeMappingEUIN,
    approveMappingEUIN,
    getARNRenewalDetailsById,
    rejectMappingById,
    rejectDeMappingById,
    getselfDeclarationByCode,
    verifyEmailAndsubmitDeclaration,
    verifyMobileAndsubmitDeclaration,
    sentForRenewalByARNId
}
