let responseData = require('../models/responsemodel');
let gstService = require('../services/gst.service');

saveGstDetails = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.id = await gstService.saveGstDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];

        if (responseData.id == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

updateGstDetails = async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.id = await gstService.updateGstDetails(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];

        if (responseData.id == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

testFileMerge= async (reqObj) => {
    responseData.data = []
    responseData.id = 0;
    try {
        responseData.id = await gstService.testFileMerge(reqObj);
        responseData.message = 'Success';
        responseData.status = 200;
        responseData.data = [];

        if (responseData.id == null) {
            responseData.data = []
            responseData.id = 0;
            responseData.status = 201;
            responseData.message = "Data Not Found"
        }
    }
    catch (ex) {
        responseData.data = []
        responseData.id = 0;
        let msg = "Error found , Below are the error :" + ex.message;
        responseData.message = msg;
        responseData.status = 500;
    }
    return responseData;
}

module.exports = {
    saveGstDetails,
    updateGstDetails,
    testFileMerge
}