const Pool = require("pg").Pool;
const envObj = require('./env.config.js');

if (envObj.env == 'dev1') {
    var dbObj = {
        user: 'cams',
        host: '172.16.16.52',
        database: 'amfi_revamp',
        password: 'cams$4321',
        port: '5432',
        schema: 'uatamfi'
    }
}
else if (envObj.env == 'dev2') {
    var dbObj = {
        user: 'cams',
        host: '172.16.16.52',
        database: 'postgres',
        password: 'cams$4321',
        port: '5432'
    }
}
else if (envObj.env == 'uat') {
    var dbObj = {
        user: 'amfi_mf',
        host: '192.168.23.132',
        database: 'amfinew',
        password: '',
        port: '5432'
    }
}
const pool = new Pool(dbObj);


module.exports = pool;
