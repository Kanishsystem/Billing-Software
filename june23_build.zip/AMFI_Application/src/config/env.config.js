module.exports = {
    //dev
    // env: 'dev2',
    // application_url: 'https://amfi-cams.tthconsulting.com',
    // application_onlineurl: 'https://amfi-online.tthconsulting.com',

    //uat
    env: 'uat',
    application_url: 'https://amfirevampuat.camsonline.com',
    application_onlineurl: 'https://amfirevampuat.camsonline.com/amfi-online',



    // env: 'uat',
    TOKEN_KEY: 'ahbsjkfbasjkfbjkas',

    //please replace email here

    email_id: 'donotreply@camsonline.com',

    //please replace password here
    email_password: 'test;',

    //please replace port here
    email_port: 2525,

    //please replace host here

    email_host: 'smtp.gmail.com',



    //amfiapplication

    AMFI_APPLICATION_KEY: 'my_secret_password_for_test_1234',
    AMFI_APPLICATION_IV: 'FB391CAAE5CD8FF47C55211ED8636D213C95F233B615D4E56CB7CD6B051D01DF356E1C45ED7AABAB5F9BCBB9EED6355B',
    AMFI_APPLICATION_ALGORITHM: 'aes-256-cbc',


    //ekyc

    AADHAAR_APPLICATION_ID: '12345',
    AADHAAR_USER_ID: 'AMFI_EKYC',
    AADHAAR_PASSWORD: 'Dnjhiw$83xei',
    AADHAAR_INTERMEDIARY_ID: 'A',
    AADHAAR_RETURN_DATA_STRUCTURE: 'MFKYC4',
    AADHAAR_SESSION_ID: '123',
    AADHAAR_KYC: 'https://ekycuat.camsonline.com/Home/Home',
    SUBSCRIBER_SERVICE_EXTERNAL: '',
    AADHAAR_ALGORITHM: 'sha256',


    //recon
    RECON_GETAPPDATAHOST: 'https://recondynamixuat.camsonline.com/rocapi/v1/appdata',
    RECON_IMPORTDATAHOST: 'https://recondynamixuat.camsonline.com/rocapi/v1/importdata',
    RECON_ENC_DEC_IV: '2020vectorrdxaes',
    RECON_ENC_DEC_KEY: '2020AES05RdxKey15',
    RECON_ENC_DEC_ALGORITHM: 'sha256',


    //billdesk

    BILLDESK_URL: 'https://uat.billdesk.com/pgidsk/PGIMerchantPayment',
    BILLDESK_MERCHANTID: 'BDSKUATY',
    BILLDESK_TYPEFIELD1: 'R',
    BILLDESK_SECURITYID: 'bdskuaty',
    BILLDESK_TYPEFIELD2: 'F',
    BILLDESK_ALGORITHM: 'sha256',
    BILLDESK_SECRET: 'G3eAmyVkAzKp8jFq0fqPEqxF4agynvtJ'



}
