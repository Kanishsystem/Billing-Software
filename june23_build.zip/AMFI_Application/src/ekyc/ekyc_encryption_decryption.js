const _crypto = require('crypto');
const _fs = require('fs');
const _nodersa = require('node-rsa');
const path = require('path')
var _xmljson = require('xmljson');
const _forge = require('node-forge');

let xmlParser = require('xml2json');


//import path from 'path';
module.exports = {
    getAESKey: function () {
        return new Promise(async function (resolve, reject) {
            var keystr = "";
            var ivstr = "";
            try {
                await _crypto.randomBytes(32, async function (err, buffer) {
                    keystr = buffer.toString("base64");

                    await _crypto.randomBytes(16, function (err, buffer) {
                        ivstr = buffer.toString("base64");

                        return resolve(ivstr + "|" + keystr);
                    });
                });
            } catch (error) {
                reject(error.message);
            } finally {
                keystr = null;
                ivstr = null;
            }
        });

    },
    encryptAESKeyUsingPublicKeyForAdhaar: function (AESKey) {
        return new Promise(async function (resolve, reject) {
            var key;
            var xml_string;
            var rsa;
            var xmlobj;
            var modulus;
            var exponent;
            try {
                key = new _nodersa();

                xml_string = _fs.readFileSync(path.resolve(__dirname, 'ENC_CAMS_20221208_XML.XML'), "utf8");//need to give publik key with the formate of xml
                rsa = JSON.parse(xmlParser.toJson(xml_string));
                modulus = new Buffer.from(rsa.RSAKeyValue.Modulus, "base64");
                exponent = new Buffer.from(rsa.RSAKeyValue.Exponent, "base64");

                key.setOptions({
                    encryptionScheme: 'pkcs1'
                });
                key.importKey({
                    n: modulus,
                    e: exponent
                }, 'components-public');

                encrypted = key.encrypt(AESKey, "base64");
                return resolve(encrypted);
            } catch (error) {
                reject(error);
            } finally {
                key = null;
                xml_string = null;
                rsa = null;
                xmlobj = null;
                modulus = null;
                exponent = null;
            }
        });
    },

    encdec: function (Mode, AESKey, encryptingText) {


        return new Promise(function (resolve, reject) {

            var keyText = AESKey.split("|")[1];
            var ivText = AESKey.split("|")[0];

            var CipherDecipher;
            var EncDecValue;
            var keyBuffer;
            var ivBuffer;
            let self = this;
            try {
                keyText = Buffer.from(keyText, "base64");
                ivText = Buffer.from(ivText, "base64");

                keyBuffer = Buffer.from(keyText, "utf-8");
                ivBuffer = new Buffer.from(ivText, "utf8");

                if (Mode == 'E') {
                    CipherDecipher = _crypto.createCipheriv('aes-256-cbc', keyBuffer, ivBuffer);
                    EncDecValue = (CipherDecipher.update(encryptingText, "utf8", "base64") + CipherDecipher.final("base64"));
                    return resolve(EncDecValue);
                } else if (Mode == 'D') {
                    CipherDecipher = _crypto.createDecipheriv('aes-256-cbc', keyBuffer, ivBuffer);
                    EncDecValue = (CipherDecipher.update(encryptingText, "base64", "utf8") + CipherDecipher.final("utf8"));
                    return resolve(EncDecValue);

                }
            } catch (error) {
                reject(error);
            } finally {
                keyText = null;
                ivText = null;
                CipherDecipher = null;
                EncDecValue = null;
                keyBuffer = null;
                ivBuffer = null;
                common.funGCclear();
            }
        });
    },
    decryptAESKeyUsingPrivateKeyForAadhar: function (EncryptedAESKey) {
        return new Promise(function (resolve, reject) {
            var temp = "";
            var pwd = "";
            var pfx;
            var decrypted = "";
            var p12buffer = "";
            var asn;
            var p12;
            var privateKey;
            var cert;
            var certpem;
            var rsaPrivateKey;
            var privateKeyInfo;
            var pem;
            var key;
            try {
                //get password
                temp = _fs.readFileSync(path.resolve(__dirname, 'ekyc_password.txt'), "utf8");
                pwd = temp.split(":")[1];
                pfx = _fs.readFileSync(path.resolve(__dirname, 'eMudhra_ENC_PFX.pfx'));

                if (Buffer.isBuffer(pfx)) {
                    p12buffer = pfx.toString('base64');
                } else {
                    p12buffer = pfx;
                }

                asn = _forge.asn1.fromDer(_forge.util.decode64(p12buffer));

                p12 = _forge.pkcs12.pkcs12FromAsn1(asn, true, pwd);

                // load keypair and cert chain from safe content(s) 
                for (var sci = 0; sci < p12.safeContents.length; ++sci) {
                    var safeContents = p12.safeContents[sci];

                    for (var sbi = 0; sbi < safeContents.safeBags.length; ++sbi) {
                        var safeBag = safeContents.safeBags[sbi];

                        // this bag has a private key
                        if (safeBag.type === _forge.pki.oids.keyBag) {
                            //Found plain private key
                            privateKey = safeBag.key;
                        } else if (safeBag.type === _forge.pki.oids.pkcs8ShroudedKeyBag) {
                            // found encrypted private key
                            privateKey = safeBag.key;
                        } else if (safeBag.type === _forge.pki.oids.certBag) {
                            // this bag has a certificate...
                            cert = safeBag.cert;
                        }
                    }
                }

                certpem = _forge.pki.certificateToPem(cert);

                // convert a Forge private key to an ASN.1 RSAPrivateKey
                rsaPrivateKey = _forge.pki.privateKeyToAsn1(privateKey);
                // wrap an RSAPrivateKey ASN.1 object in a PKCS#8 ASN.1 PrivateKeyInfo
                privateKeyInfo = _forge.pki.wrapRsaPrivateKey(rsaPrivateKey);
                // convert a PKCS#8 ASN.1 PrivateKeyInfo to PEM
                pem = _forge.pki.privateKeyInfoToPem(privateKeyInfo);

                key = new _nodersa(pem, 'pkcs8-private-pem', {
                    encryptionScheme: 'pkcs1',
                    padding: _crypto.constants.RSA_PKCS1_PADDING
                });

                decrypted = key.decrypt(EncryptedAESKey, 'utf8');
                return resolve(decrypted);
            } catch (error) {
                console.log(error)
                reject(error);
            } finally {
                temp = null;
                pwd = null;
                pfx = null;
                decrypted = null;
                p12buffer = null;
                asn = null;
                p12 = null;
                privateKey = null;
                cert = null;
                certpem = null;
                rsaPrivateKey = null;
                privateKeyInfo = null;
                pem = null;
                key = null;
                common.funGCclear();
            }
        });
    }
}