var express = require('express')
var app = express()
var bodyParser = require('body-parser');
var cors = require('cors')
app.use(cors());
let authservice = require('./src/common/auth');
const res = require('express/lib/response');
const encryptionDecryption = require('./src/common/encrypt_decrypt');
var routerApp = express.Router();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const helperService = require('./src/api/services/helper.service')
const jwt = require('jsonwebtoken');
const socketioJwt = require('socketio-jwt');
var multer = require('multer')
var upload = multer();

app.use(upload.array());


app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(
    bodyParser.json({ limit: '50mb' })

);

app.use(express.text())



const io = require("socket.io")(server, {
    origins: '*:*',

    // handlePreflightRequest: (req, res) => {
    //     res.writeHead(200, {
    //         "Access-Control-Allow-Origin": ["https://amfi-cams.tthconsulting.com", "http://localhost:4200", "https://amfi-online.tthconsulting.com", "*"],
    //         "Access-Control-Allow-Methods": "GET,POST",
    //         "Access-Control-Allow-Headers": "*",
    //         "Access-Control-Allow-Credentials": true
    //     });
    //     res.end();
    // }
});


app.use(bodyParser.urlencoded({ limit: '50mb', extended: true, parameterLimit: 1000000 }));
app.get('/', async function (req, res) {
    try {
        res.send("AMFI Application started")
    }
    catch (error) {
        console.log(error)
    }

});

app.use(async function (req, resp, next) {
    var ignoreUrl = [];
    ignoreUrl.push('/helper/getDecryptedData');
    ignoreUrl.push('/helper/getEncryptedData');
    ignoreUrl.push('/ekyc/saveAadharResponse');
    ignoreUrl.push('/payment/saveOnlinePaymentTransaction');
    ignoreUrl.push('/ekyc/updateEkycFiles');

    if (!ignoreUrl.includes(req.url)) {

        const { encryptedRequestResponse } = req.body;
        if (!(encryptedRequestResponse)) {
            let resObj = encryptionDecryption.encrypt(JSON.stringify({ status: 401, message: 'Invalid Request' }))
            return resp.status(400).send(resObj);
        }
        else {
            next();
        }
    }
    else {
        next();
    }
})

app.use(async function (req, resp, next) {
    var ignoreUrl = [];
    ignoreUrl.push('/helper/getDecryptedData');
    ignoreUrl.push('/helper/getEncryptedData');
    ignoreUrl.push('/offline/loginFOBO');
    ignoreUrl.push('/offline/loginBO');
    ignoreUrl.push('/offline/loginFO');
    ignoreUrl.push('/registration/loginARNEUIN');
    ignoreUrl.push('/registration/loginARNEUIN');
    ignoreUrl.push('/registration/loginARNEUIN');
    ignoreUrl.push('/registration/getDistributerPendingDataById');
    ignoreUrl.push('/registration/getARNCategoryDropdwn');
    ignoreUrl.push('/registration/saveRegisterOnAMFI');
    ignoreUrl.push('/registration/updatePersonalDetails');
    ignoreUrl.push('/registration/updateCertificationDetails');
    ignoreUrl.push('/registration/updateBankDetails');
    ignoreUrl.push('/registration/updateDocuments');
    ignoreUrl.push('/registration/verifyMobileNoOtp');
    ignoreUrl.push('/registration/verifyEmailOtp');
    ignoreUrl.push('/registration/getDetailsByPincode');
    ignoreUrl.push('/registration/getBankDetailsByIFSCcode');
    ignoreUrl.push('/registration/getPersonalDetailsById');
    ignoreUrl.push('/registration/getCertificationDetailsById');
    ignoreUrl.push('/registration/getBankDetailsById');
    ignoreUrl.push('/registration/resendMobileOtp');
    ignoreUrl.push('/registration/updateRegistrationType');
    ignoreUrl.push('/registration/updateCompanyDetails');
    ignoreUrl.push('/registration/getCompanyDetailsById');
    ignoreUrl.push('/registration/getDetailsByARNId');
    ignoreUrl.push('/registration/registrationActivate');
    ignoreUrl.push('/registration/getDocumentsById');
    ignoreUrl.push('/registration/loginARNEUIN');
    ignoreUrl.push('/registration/resumeByPanNo');
    ignoreUrl.push('/registration/getAccountTypeById');
    ignoreUrl.push('/registration/getPaymentAmountById');
    ignoreUrl.push('/registration/getDeclarationById');
    ignoreUrl.push('/registration/getFilebase64ByID');
    ignoreUrl.push('/registration/getDropDownData');
    ignoreUrl.push('/registration/verifyOtp');
    ignoreUrl.push('/registration/forgotUserId');
    ignoreUrl.push('/registration/forgotPasswordSendOtp');
    ignoreUrl.push('/registration/forgotPasswordVerifyOtp');
    ignoreUrl.push('/registration/changePassword');
    ignoreUrl.push('/registration/updateRegistrationReview');
    ignoreUrl.push('/registration/updatePayment');
    ignoreUrl.push('/helper/fileUploader');
    ignoreUrl.push('/registration/logoutARNEUIN');
    ignoreUrl.push('/offline/logoutFOBO');
    ignoreUrl.push('/offline/getFinancialYear');
    ignoreUrl.push('/ekyc/verifyAadhar');
    ignoreUrl.push('/ekyc/saveAadharResponse');
    ignoreUrl.push('/payment/createOnlinePayment');
    ignoreUrl.push('/payment/saveOnlinePaymentTransaction');
    ignoreUrl.push('/offline/getRequestTypes')
    ignoreUrl.push('/payment/billdeskCallbackTxnStatusUpdate');
    ignoreUrl.push('/ekyc/updateEkycFiles')
    ignoreUrl.push('/registration/resendEmailOtp')



    if (!ignoreUrl.includes(req.url)) {
        if (req.headers['authorization'] == undefined) {
            let resObj = encryptionDecryption.encrypt(JSON.stringify({ status: 403, message: 'A token is required for authentication' }))
            return resp.status(403).send(resObj);
        }

        let data = await authservice.verifyToken(req.headers['authorization']);
        if (data.auth) {
            next();
        } else {
            let resObj = encryptionDecryption.encrypt(JSON.stringify({ status: 401, message: 'Invalid Token' }))
            return resp.status(401).send(resObj);
        }
    } else {
        next();
    }

});

var requireObj = require('./src/api/routes/index')(routerApp, app);

io.on('connection', (socket) => {
    socket.on('removeActiveSession', async (msg) => {
        let res = await helperService.removeActiveSession(msg);
        io.emit('removeActiveSession', res);
    });

})
    .on('authenticated', (socket) => {
        socket.on('chat message', msg => {
            io.emit('chat message', msg);
        });
    });


server.listen(3000, () => {
    console.log("server start")
})




