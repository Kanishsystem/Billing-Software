<?php
 if(!isset($_SESSION["project"]) || $_SESSION["project"] !== true){
    header("location: index");
    exit;
}
require_once('Nav.php');
class  Upload{

    private  $db;
    private $err;
    public function __construct(){
      $this->db = Database::config();
    }

    private  function  storelogfile($data){
        $servername =  Form::post('servername');
        $upfname =  isset($_FILES['upfname']['name']) ? $_FILES['upfname']['name']  : "";
        $upftime =  date("Y-m-d h:i:sa");
        $uploaderr = true;
        if(isset($_FILES['upfname']['name']) &&  strlen($_FILES['upfname']['name']) > 1){
            $extension = substr(strrchr($_FILES['upfname']["name"], '.'), 1);
            if($extension != "log" &&  $extension != "text"){   
                echo  '<script>notifyError("Invalid File Format Only log and text are allowed")</script>';
                $uploaderr = false;
            }else{
                $target_file = BASE_DIR_DATA.DS.$_FILES['upfname']['name'];
                move_uploaded_file($_FILES["upfname"]["tmp_name"], $target_file);
                $uploaderr = true;
            }
        }
        $sub_name =   isset($_SESSION["username"]) ?   $_SESSION["username"] : "Parthiban";
        $sql = "INSERT INTO updetails(upftype,upfname,upftime,sub_name) values(:upftype,:upfname,:upftime,:sub_name)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":upftype", $servername, PDO::PARAM_STR);
        $stmt->bindParam(":upfname", $upfname, PDO::PARAM_STR);
        $stmt->bindParam(":upftime", $upftime, PDO::PARAM_STR);
        $stmt->bindParam(":sub_name", $sub_name, PDO::PARAM_STR);
        try{  
        if($uploaderr){
            $stmt->execute();
            $result =  $this->db->lastInsertId();
            return $result;
        }else{
            echo  '<script>notifyError("File Not Saved Please Reupload the File")</script>';
        }
        } catch (PDOException $e){
            echo  '<script>notifyError("'.$e->getMessage().'")</script>';
            return false;
        }
    }

    private function hsmreadfile(){
      //  $log_file = 'D:\xampp\htdocs\Project\log\logfileone.log';
        $log_file = isset($_FILES) ?  $_FILES['upfname']['tmp_name']  : "";
        $data = file($log_file, FILE_SKIP_EMPTY_LINES);
        $ldata = [];
        foreach($data as $fdata){
            $filedata   = explode(" ",$fdata);
            if(count($filedata) > 10){
                $obj =  new stdclass();
                $obj->hsmdate =  $filedata[5];
                $obj->hsmtime =  $filedata[2];
                $obj->servername  =  preg_replace("/[^a-zA-Z]+/", "",$filedata[4]);
                $obj->daemonname =  $filedata[2];
                $obj->daemonid  =  preg_replace("/[^0-9]+/", "",$filedata[4]);
                $obj->id  =  preg_replace("/[^a-zA-Z0-9]+/", "",$filedata[2]);
                $obj->msgtype =  preg_replace("/[^a-zA-Z]+/", "",$filedata[10]);
                $obj->servertype = $filedata[8]." ".preg_replace("/[^a-zA-Z]+/", "",$filedata[9]);
                $obj->remarks = "";
                for($i=11;$i < count($filedata) ;$i++){
                    $obj->remarks .= $filedata[$i]." ";
                }
            }else{
                for($i=0;$i < count($filedata) ;$i++){
                    $obj->remarks .= $filedata[$i]." ";
                }
            }
            $ldata[] =  $obj;            
        }
        return $ldata;
    }

    private function insertdata($insdata,$type){   
        foreach($insdata as $idata){
            $data  = is_array($idata) ?  $idata : (array)$idata; 
            if($type==5){
                $sql = "INSERT INTO hsmlog(hsmdate,hsmtime,servername,daemonname,daemonid,id,msgtype,servertype,remarks) values(:hsmdate,:hsmtime,:servername,:daemonname,:daemonid,:id,:msgtype,:servertype,:remarks)";
            }elseif($type==3){
                $sql = "INSERT INTO raserv(rdate,rtime,remarks) values(:rdate,:rtime,:remarks)";
            }elseif($type==6){
                $sql = "INSERT INTO seclog(secdate,sectime,servername,daemonname,daemonid,grp,usr,gname,uname,gid,uid,homename,shname,accname,ipaddr,portno,servicename,remarks)
                 values(:secdate,:sectime,:servername,:daemonname,:daemonid,:grp,:usr,:gname,:uname,:gid,:uid,:homename,:shname,:accname,:ipaddr,:portno,:servicename,:remarks)";
            }
            $stmt = $this->db->prepare($sql);
            try{  
            $stmt->execute($data);
            $result =  $this->db->lastInsertId();
            //return $result;
            }catch (PDOException $e){
                echo  $e->getMessage();
                echo  '<script>notifyError("'.$e->getMessage().'")</script>';
                return false;
            }
        }
        return true;
    }

    private function loginfilethree(){
          //$log_file = 'D:\xampp\htdocs\Project\log\logfilethree.log';
          $log_file = isset($_FILES) ?  $_FILES['upfname']['tmp_name']  : "";
          $data = file($log_file, FILE_SKIP_EMPTY_LINES);
         // var_dump($data);
           $ldata = [];
           foreach($data as $fdata){
               $filedata   = explode(" ",$fdata);
            //    if(count($filedata) == 5 || count($filedata) == 6){  
            //       var_dump($filedata);
                if(strlen($filedata[0])==10){
                    $obj =  new stdclass();
                     $obj->rdate =  $filedata[0];
                     $obj->rtime =  $filedata[1];
                     $obj->remarks  =  '';
                     for($i=2;$i < count($filedata) ;$i++){
                         $obj->remarks .= $filedata[$i]." ";
                     }
                     array_push($ldata,$obj);
                }elseif(count($filedata)==6 || count($filedata)==3){
                    $remarks = '';
                    if(strlen($filedata[0])==3){
                        $obj2 =  new stdclass();
                        $month  =  date('m', strtotime($filedata[1]));
                        $newdate =  $filedata[5]."-".$month."-".$filedata[2];
                        $obj2->rdate =  $newdate;
                        $obj2->rtime =  $filedata[3];
                    }elseif(strlen($filedata[0])==16){
                        for($i=0;$i < count($filedata);$i++ ){
                            $remarks .=  preg_replace("/[^a-zA-Z]+/", " ",$filedata[$i]);
                        }
                        $obj2->remarks = $remarks;
                    }
                    if(count((array)$obj2)==3){
                        array_push($ldata,$obj2);
                    }
                }elseif(count($filedata)==8){
                 //   var_dump($filedata);
                    if(strlen($filedata[0])==7){
                       $stdobj =  new stdclass();
                       $twoexp = explode("...",$filedata[3]);
                       $stdobj->rdate = $twoexp[1];
                       $stdobj->rtime = $filedata[4];
                       $stdobj->remarks = "";
                       for($i=5;$i < count($filedata);$i++ ){
                        $stdobj->remarks .=  $filedata[$i]." ";
                        }
                    }
                    array_push($ldata,$stdobj);
                }    
           } 
          // var_dump($ldata);
           return $ldata;
      }

      private function loginfilefive(){
       // $log_file = 'D:\xampp\htdocs\Project\log\logfilefive.log';
        $log_file = isset($_FILES) ?  $_FILES['upfname']['tmp_name']  : "";
        $data = file($log_file, FILE_SKIP_EMPTY_LINES);
        $ldata  = [];
         foreach($data as $fdata){
             $filedata   = explode(" ",$fdata);
             $getremarks ="";
             if(strlen($filedata[0])==3){
                $obj =  new stdclass();
                $month  =  date('m', strtotime($filedata[0]));
                $newdate =  date('Y')."-".$month."-".$filedata[1];
                $obj->secdate = $newdate;
                $obj->sectime = $filedata[2];
                $obj->servername = $filedata[3];
                $obj->daemonname = preg_replace("/[^a-zA-Z]+/", "",$filedata[4]);
                $obj->daemonid = preg_replace("/[^0-9]+/", "",$filedata[4]);
                $obj->grp = "Nil";
                $obj->usr = "Nil";
                $obj->gname ="Nil";
                $obj->uname ="Nil";
                $obj->gid ="Nil";
                $obj->uid ="Nil";
                for($i=5;$i < count($filedata);$i++ ){
                    $getremarks .=  $filedata[$i];
                }
                if(preg_match_all('/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/',$getremarks,$matches)){
                    $ipaddress =   $matches[0][0];
                }
                $splitremarks  = explode("port",$getremarks);
                $finduser  = explode("USER=",$getremarks);
                if(isset($finduser[1])){
                    $getaccname  = explode(";",$finduser[1]);
                }
                $findhost  = explode("PWD=",$getremarks);
                if(isset($findhost[1])){
                    $gethostname  = explode(";",$findhost[1]);
                }
                $findcommand  = explode("COMMAND=",$getremarks);
                if(isset($findcommand[1])){
                    $getcommend  = explode(";",$findcommand[1]);
                }
                //var_dump($finduser);
                $obj->homename =isset($gethostname[0]) ? $gethostname[0] : "Nil";
                $obj->shname  =isset($getcommend[0]) ? $getcommend[0] : "Nil";
                $obj->accname = isset($getaccname[0]) ?  $getaccname[0] : "Nil";
                $gethostname[0] = "Nil";$getcommend[0] = "Nil";$getaccname[0] = "Nil";
                $obj->ipaddr =isset($ipaddress) ?  $ipaddress : "Nil";
                $ipaddress = "Nil";
                $obj->portno =isset($splitremarks[1]) ?  preg_replace("/[^0-9]+/", "",$splitremarks[1])  : "Nil";
                $obj->servicename ="Nil";
                $obj->remarks = "";
                for($i=5;$i < count($filedata);$i++ ){
                    $obj->remarks .=  $filedata[$i]." ";
                }
                if(isset($finduser[1])){
                    $getaccname  = explode(";",$finduser[1]);
                    if(strlen($getaccname[0]) > 2){
                        $obj->remarks = "Nill";
                    }
                }
                }
                $ldata[] = $obj ;
         } 
         return $ldata; 
    }
  

    public function single_func($data,$pdata){
        switch($data){
            case $data =="Firewall" : 
                break;
            case $data =="Proxy" : 
                break;    
            case $data =="DNS" :
                $resultdata  = $this->loginfilethree();   
                $insresult  =  $this->insertdata($resultdata,3);
                if($insresult==true){
                    return $this->storelogfile($pdata);
                }
                break;  
            case $data =="CA" : 
                break;  
            case $data =="HSM" : 
                $resultdata  = $this->hsmreadfile();
                $insresult  =  $this->insertdata($resultdata,5);
                if($insresult==true){
                    return $this->storelogfile($pdata);
                }
                return 0;
            case $data =="OCSP" : 
                $resultdata  = $this->loginfilefive();
                $insresult  =  $this->insertdata($resultdata,6);
                if($insresult==true){
                    return $this->storelogfile($pdata);
                }
                return 0;
            default : 
            echo "Select Valid Option";  
                                   
        }
    }
}
$logupload  = new Upload();
$submitcheck = isset($_POST["uploadlog"])  ? true : false;
if($submitcheck){
    $data  = $_POST;
    unset($data['uploadlog']); 
    if(isset($data['servername']) && strlen($data['servername']) > 1 && isset($_FILES['upfname']['name']) && strlen($_FILES['upfname']['name']) > 1 && strlen($_SESSION["username"]) > 1 ){
        $result  =  $logupload->single_func($data['servername'],$data);
        if($result > 0){
            echo  '<script>notifySuccess("Log File Uploaded Successfully!")</script>';
        }
    }else{
        echo  '<script>notifyError("Please Fill The Form Credentials")</script>';
    }
  

}

?>
<p class="text-center m-5 h3">SERVER LOG ANALYSIS - UPLOAD</p>
<div class="container">
<div class="card">
  <div class="card-header">Upload Log File</div>
  <div class="card-body">
  <form class="form-inline" action="" method="POST" enctype="multipart/form-data">
    <div class="form-group col-md-4">
    <select class="custom-select" name="servername">
        <option value="0" selected disabled>Choose ...</option>
        <option value="Firewall">Firewall</option>
        <option value="Proxy">Proxy</option>
        <option value="DNS">DNS</option>
        <option value="CA">CA</option>
        <option value="HSM">HSM</option>
        <option value="OCSP">OCSP</option>
    </select>
    </div>
    <div class="custom-file col-md-4">
        <input type="file" class="custom-file-input" id="upfname" name="upfname">
        <label class="custom-file-label" for="upfname">Choose log file</label>
    </div>
    <div class=" col-md-4 text-center">
         <button class="btn btn-primary" type="submit" name="uploadlog">Upload</button>
    </div>
</form>
  </div>
</div>
</div>
