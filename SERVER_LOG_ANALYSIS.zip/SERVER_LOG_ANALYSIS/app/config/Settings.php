<?php
/**
 * 
 * Settings
 * 
 */

 class Settings {


/***
 * 
 * Project Title
 * 
 */
const PTITLE = "SERVER LOG ANALYSIS";    
/***
 * 
 * Project Name
 * 
 */
const PNAME = "Project";
/**
 * 
 * Footer
 * 
 * 
 */
const PFOOTER = "";
/**
 * 
 * Footer
 * 
 * 
 */
const THEME = "primary";

 }


?>